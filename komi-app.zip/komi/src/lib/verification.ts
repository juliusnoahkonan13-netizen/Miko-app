import { db } from "./db";
import { generateVerificationCode, hashVerificationCode } from "./auth";
import { sendEmail, verificationCodeEmail } from "./email";

const CODE_DURATION_MINUTES = 15;

/** Creates a real 6-digit code (hashed at rest) and sends it by email. */
export async function issueVerificationCode(userId: string, email: string, firstName: string) {
  const code = generateVerificationCode();

  await db.emailVerificationCode.create({
    data: {
      userId,
      codeHash: hashVerificationCode(code),
      expiresAt: new Date(Date.now() + CODE_DURATION_MINUTES * 60 * 1000)
    }
  });

  const { subject, html, text } = verificationCodeEmail(code, firstName);
  await sendEmail(email, subject, html, text);
}
