import { db } from "./db";
import type { NotificationType } from "@prisma/client";

/** Creates a real, persisted notification row. Push delivery hooks in once
 * a push provider (e.g. Firebase Cloud Messaging) is connected — see README. */
export async function notify(
  userId: string,
  type: NotificationType,
  title: string,
  body: string,
  linkUrl?: string
) {
  return db.notification.create({
    data: { userId, type, title, body, linkUrl }
  });
}
