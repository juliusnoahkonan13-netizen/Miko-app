import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AuthError } from "./auth";

/** Wraps a route handler so thrown AuthError/ZodError/etc become clean JSON responses. */
export function handleRoute(fn: () => Promise<NextResponse>): Promise<NextResponse> {
  return fn().catch((err) => {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    if (err instanceof ZodError) {
      return NextResponse.json(
        { error: "Données invalides.", details: err.flatten() },
        { status: 400 }
      );
    }
    console.error(err);
    return NextResponse.json({ error: "Erreur serveur." }, { status: 500 });
  });
}

export function slugify(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 60);
}

export async function uniqueSlug<T>(
  base: string,
  exists: (slug: string) => Promise<T | null>
): Promise<string> {
  const root = slugify(base) || "item";
  let slug = root;
  let i = 1;
  while (await exists(slug)) {
    slug = `${root}-${i++}`;
  }
  return slug;
}

export function generateQuoteNumber(): string {
  const y = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `DEVIS-KOMI-${y}-${rand}`;
}
