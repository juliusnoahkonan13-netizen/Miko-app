/**
 * Real email sending, pluggable by provider.
 *
 * Set RESEND_API_KEY (and optionally EMAIL_FROM) in your environment to send
 * real emails via Resend (https://resend.com — free tier available). Without
 * a key, this logs the email to the server console instead, so you can still
 * develop and test locally. Nothing about the verification logic itself is
 * fake — only the transport falls back to a log when unconfigured.
 */

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const EMAIL_FROM = process.env.EMAIL_FROM || "Komi <onboarding@resend.dev>";

export async function sendEmail(to: string, subject: string, html: string, text?: string) {
  if (!RESEND_API_KEY) {
    console.log(
      `[dev] Email non envoyé (RESEND_API_KEY manquant). À: ${to} | Sujet: ${subject}\n${text ?? html}`
    );
    return { delivered: false };
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ from: EMAIL_FROM, to, subject, html, text })
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    console.error(`Échec d'envoi d'email à ${to}: ${res.status} ${detail}`);
    return { delivered: false };
  }

  return { delivered: true };
}

export function verificationCodeEmail(code: string, firstName: string) {
  const subject = "Ton code de vérification Komi";
  const html = `
    <div style="font-family:sans-serif;max-width:480px;margin:0 auto;">
      <h2 style="color:#1B4F9C;">Bonjour ${firstName},</h2>
      <p>Voici ton code de vérification Komi :</p>
      <p style="font-size:28px;font-weight:700;letter-spacing:6px;color:#1B4F9C;">${code}</p>
      <p style="color:#666;font-size:14px;">Ce code expire dans 15 minutes. Si tu n'es pas à l'origine de cette demande, ignore cet email.</p>
    </div>`;
  const text = `Bonjour ${firstName},\n\nTon code de vérification Komi est : ${code}\nCe code expire dans 15 minutes.`;
  return { subject, html, text };
}
