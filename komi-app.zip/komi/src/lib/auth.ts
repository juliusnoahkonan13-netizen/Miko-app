import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { cookies } from "next/headers";
import { db } from "./db";
import type { Role, User } from "@prisma/client";

const JWT_SECRET = process.env.JWT_SECRET;
const SESSION_COOKIE = "komi_session";
const SESSION_DURATION_DAYS = 30;

if (!JWT_SECRET && process.env.NODE_ENV === "production") {
  // Fail loudly in production rather than silently signing tokens with an empty secret.
  throw new Error(
    "JWT_SECRET manquant. Définis-le dans tes variables d'environnement avant de déployer."
  );
}

const SECRET = JWT_SECRET ?? "dev-only-insecure-secret-change-me";

// --- Passwords ---------------------------------------------------------

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// --- Sessions ------------------------------------------------------------
// A JWT identifies the user; a matching row in `Session` (hashed token) lets
// us revoke sessions server-side on logout instead of relying on the JWT alone.

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createSession(userId: string, userAgent?: string) {
  const expiresAt = new Date(Date.now() + SESSION_DURATION_DAYS * 24 * 60 * 60 * 1000);
  const token = jwt.sign({ sub: userId }, SECRET, {
    expiresIn: `${SESSION_DURATION_DAYS}d`
  });

  await db.session.create({
    data: { userId, tokenHash: hashToken(token), userAgent, expiresAt }
  });

  cookies().set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt
  });

  return token;
}

export async function destroySession() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (token) {
    await db.session.deleteMany({ where: { tokenHash: hashToken(token) } }).catch(() => null);
  }
  cookies().delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!token) return null;

  let payload: { sub: string };
  try {
    payload = jwt.verify(token, SECRET) as { sub: string };
  } catch {
    return null;
  }

  const session = await db.session.findUnique({ where: { tokenHash: hashToken(token) } });
  if (!session || session.expiresAt < new Date()) return null;

  const user = await db.user.findUnique({ where: { id: payload.sub } });
  if (!user || user.isSuspended) return null;
  return user;
}

// --- Email verification ---------------------------------------------------

export function generateVerificationCode(): string {
  return crypto.randomInt(100000, 999999).toString();
}

export function hashVerificationCode(code: string): string {
  return crypto.createHash("sha256").update(code).digest("hex");
}

export async function requireVerifiedUser(): Promise<User> {
  const user = await requireUser();
  if (!user.emailVerifiedAt) {
    throw new AuthError("Vérifie ton email avant de continuer.", 403);
  }
  return user;
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status = 401) {
    super(message);
    this.status = status;
  }
}

export async function requireUser(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("Connexion requise.", 401);
  return user;
}

export async function requireRole(...roles: Role[]): Promise<User> {
  const user = await requireUser();
  if (!roles.some((r) => user.roles.includes(r))) {
    throw new AuthError("Accès refusé pour ce rôle.", 403);
  }
  return user;
}
