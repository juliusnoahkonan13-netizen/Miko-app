"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewBusinessPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    companyName: "",
    sector: "",
    description: "",
    address: "",
    city: "",
    phone: "",
    email: "",
    website: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!form.companyName) return setError("Le nom de l'entreprise est requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/businesses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push(`/business/${data.business.slug}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Créer une page entreprise</h1>

      <input className="komi-input" placeholder="Nom de l'entreprise" value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
      <input className="komi-input" placeholder="Secteur d'activité" value={form.sector} onChange={(e) => setForm({ ...form, sector: e.target.value })} />
      <textarea className="komi-input" rows={3} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      <input className="komi-input" placeholder="Adresse" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="komi-input" placeholder="Téléphone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input className="komi-input" placeholder="Site web" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} />
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Création..." : "Créer ma page entreprise"}
      </button>
    </div>
  );
}
