"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewProfessionalPage() {
  const router = useRouter();
  const [form, setForm] = useState({ jobTitle: "", description: "", experienceYears: "", zone: "", city: "", quartier: "" });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!form.jobTitle || !form.zone || !form.city) return setError("Métier, zone et ville sont requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/professionals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          experienceYears: form.experienceYears ? Number(form.experienceYears) : undefined
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push("/dashboard/professional");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Devenir professionnel sur Komi</h1>
      <p className="text-sm text-ink/50">Exemple : Plombier, Électricien, Peintre, Maçon, Informaticien...</p>

      <input className="komi-input" placeholder="Ton métier" value={form.jobTitle} onChange={(e) => setForm({ ...form, jobTitle: e.target.value })} />
      <textarea className="komi-input" rows={3} placeholder="Décris ton expérience" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      <input type="number" className="komi-input" placeholder="Années d'expérience" value={form.experienceYears} onChange={(e) => setForm({ ...form, experienceYears: e.target.value })} />
      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="komi-input" placeholder="Quartier" value={form.quartier} onChange={(e) => setForm({ ...form, quartier: e.target.value })} />
      </div>
      <input className="komi-input" placeholder="Zone d'intervention (ex : Yopougon et environs)" value={form.zone} onChange={(e) => setForm({ ...form, zone: e.target.value })} />

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Création..." : "Créer mon profil professionnel"}
      </button>
    </div>
  );
}
