import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ProductCard from "@/components/ProductCard";
import ContactButton from "@/components/ContactButton";
import ReportButton from "@/components/ReportButton";
import { ShieldCheck, MapPin } from "lucide-react";

export default async function StorePage({ params }: { params: { slug: string } }) {
  const store = await db.store.findFirst({
    where: { OR: [{ slug: params.slug }, { id: params.slug }] },
    include: {
      products: { where: { isActive: true }, include: { images: true } },
      promotions: { where: { endsAt: { gte: new Date() } } }
    }
  });

  if (!store) notFound();

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="komi-card p-5 flex items-center gap-4 mb-6">
        <div className="w-16 h-16 rounded-2xl bg-amber/20 flex items-center justify-center font-display text-2xl font-bold text-amber-dark shrink-0">
          {store.name[0]}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="font-display text-xl font-bold text-indigo flex items-center gap-2">
            {store.name}
            {store.verification === "VERIFIED" && (
              <span className="komi-badge-verified"><ShieldCheck size={12} /> Vérifié par Komi</span>
            )}
          </h1>
          {store.city && (
            <p className="text-sm text-ink/50 flex items-center gap-1 mt-0.5">
              <MapPin size={13} /> {store.city}{store.quartier ? `, ${store.quartier}` : ""}
            </p>
          )}
          {store.description && <p className="text-sm text-ink/60 mt-1">{store.description}</p>}
        </div>
        <ContactButton recipientId={store.ownerId} label="Contacter la boutique" />
      </div>
      <div className="mb-4">
        <ReportButton targetType="STORE" targetId={store.id} />
      </div>

      <h2 className="font-display font-semibold text-indigo mb-3">Produits ({store.products.length})</h2>
      {store.products.length === 0 ? (
        <p className="text-ink/40 text-sm py-10 text-center">Cette boutique n'a pas encore de produit.</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {store.products.map((p) => (
            <ProductCard
              key={p.id}
              id={p.id}
              slug={p.slug}
              name={p.name}
              price={p.price}
              promoPrice={p.promoPrice}
              imageUrl={p.images[0]?.url}
              storeName={store.name}
            />
          ))}
        </div>
      )}
    </div>
  );
}
