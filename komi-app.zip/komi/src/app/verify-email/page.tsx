"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";

export default function VerifyEmailPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (!loading && !user) router.push("/login");
    if (!loading && user?.emailVerifiedAt) router.push("/");
  }, [user, loading]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function submit() {
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Code incorrect.");
      await refresh();
      router.push("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setSubmitting(false);
    }
  }

  async function resend() {
    setError(null);
    setInfo(null);
    setResending(true);
    try {
      const res = await fetch("/api/auth/resend-verification", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Impossible de renvoyer le code.");
      setInfo("Un nouveau code a été envoyé.");
      setCooldown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setResending(false);
    }
  }

  if (loading || !user) return <div className="max-w-sm mx-auto px-4 py-16 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-sm mx-auto px-4 py-16 text-center">
      <p className="text-4xl mb-3">📧</p>
      <h1 className="font-display text-2xl font-bold text-indigo mb-2">Vérifie ton email</h1>
      <p className="text-ink/60 text-sm mb-6">
        On a envoyé un code à 6 chiffres à <span className="font-medium text-ink">{user.email}</span>.
      </p>

      <input
        className="komi-input text-center text-2xl tracking-[0.5em] font-display"
        maxLength={6}
        inputMode="numeric"
        value={code}
        onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
        placeholder="000000"
      />

      {error && <p className="text-sm text-red-600 mt-3">{error}</p>}
      {info && <p className="text-sm text-teal mt-3">{info}</p>}

      <button onClick={submit} disabled={submitting || code.length !== 6} className="komi-btn-primary w-full mt-4">
        {submitting ? "Vérification..." : "Vérifier"}
      </button>

      <button
        onClick={resend}
        disabled={resending || cooldown > 0}
        className="text-sm text-teal font-medium mt-4 disabled:text-ink/30"
      >
        {cooldown > 0 ? `Renvoyer le code (${cooldown}s)` : resending ? "Envoi..." : "Renvoyer le code"}
      </button>
    </div>
  );
}
