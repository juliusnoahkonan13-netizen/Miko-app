"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { LogOut, Store, Wrench, Building2, Home, Car, ShieldCheck } from "lucide-react";

export default function ProfilePage() {
  const { user, loading, refresh, logout } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({ firstName: "", lastName: "", city: "", quartier: "", bio: "" });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.push("/login");
    if (user) setForm({ firstName: user.firstName, lastName: user.lastName, city: user.city ?? "", quartier: user.quartier ?? "", bio: "" });
  }, [user, loading]);

  async function save() {
    setSaving(true);
    setSaved(false);
    await fetch("/api/users/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    await refresh();
    setSaving(false);
    setSaved(true);
  }

  if (loading || !user) return <div className="max-w-xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  const isSeller = user.roles.includes("SELLER");
  const isProfessional = user.roles.includes("PROFESSIONAL");
  const isBusiness = user.roles.includes("BUSINESS");
  const isAdmin = user.roles.includes("ADMIN");

  return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-indigo/10 flex items-center justify-center font-display text-2xl font-bold text-indigo">
          {user.firstName[0]}
        </div>
        <div>
          <h1 className="font-display text-xl font-bold text-indigo">{user.firstName} {user.lastName}</h1>
          <p className="text-sm text-ink/50">{user.email}</p>
        </div>
      </div>

      <div className="komi-card p-4 space-y-3">
        <h2 className="font-display font-semibold text-indigo">Mes espaces</h2>
        <div className="grid grid-cols-2 gap-2">
          <SpaceLink href={isSeller ? "/dashboard/seller" : "/sell/store"} icon={Store} label={isSeller ? "Ma boutique" : "Devenir vendeur"} />
          <SpaceLink href={isProfessional ? "/dashboard/professional" : "/sell/professional"} icon={Wrench} label={isProfessional ? "Mon espace pro" : "Devenir professionnel"} />
          <SpaceLink href={isBusiness ? "/business/me" : "/sell/business"} icon={Building2} label={isBusiness ? "Ma page entreprise" : "Créer une page entreprise"} />
          <SpaceLink href="/properties/new" icon={Home} label="Publier un bien" />
          <SpaceLink href="/vehicles/new" icon={Car} label="Publier un véhicule" />
          {isAdmin && <SpaceLink href="/admin" icon={ShieldCheck} label="Komi Admin" />}
        </div>
      </div>

      <div className="komi-card p-4 space-y-3">
        <h2 className="font-display font-semibold text-indigo">Informations</h2>
        <div className="grid grid-cols-2 gap-3">
          <input className="komi-input" placeholder="Prénom" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
          <input className="komi-input" placeholder="Nom" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          <input className="komi-input" placeholder="Quartier" value={form.quartier} onChange={(e) => setForm({ ...form, quartier: e.target.value })} />
        </div>
        <button onClick={save} disabled={saving} className="komi-btn-primary">
          {saving ? "Enregistrement..." : saved ? "Enregistré ✓" : "Enregistrer"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Link href="/orders" className="komi-btn-secondary text-center">Mes commandes</Link>
        <Link href="/favorites" className="komi-btn-secondary text-center">Mes favoris</Link>
      </div>

      <button onClick={logout} className="flex items-center gap-2 text-red-600 text-sm font-medium">
        <LogOut size={16} /> Se déconnecter
      </button>
    </div>
  );
}

function SpaceLink({ href, icon: Icon, label }: { href: string; icon: any; label: string }) {
  return (
    <Link href={href} className="flex items-center gap-2 p-3 rounded-komi border border-line hover:border-amber text-sm font-medium text-indigo">
      <Icon size={18} /> {label}
    </Link>
  );
}
