import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ContactButton from "@/components/ContactButton";
import FavoriteButton from "@/components/FavoriteButton";
import ReportButton from "@/components/ReportButton";
import { MapPin, BedDouble, Bath, Ruler } from "lucide-react";

export const dynamic = "force-dynamic";

const TYPE_LABEL: Record<string, string> = {
  HOUSE: "Maison",
  APARTMENT: "Appartement",
  VILLA: "Villa",
  LAND: "Terrain",
  SHOP: "Magasin",
  OFFICE: "Bureau",
  ROOM: "Chambre",
  COMMERCIAL_SPACE: "Local commercial"
};

export default async function PropertyPage({ params }: { params: { id: string } }) {
  const property = await db.property.findUnique({
    where: { id: params.id },
    include: { images: true, owner: { select: { firstName: true, lastName: true, phone: true } } }
  });
  if (!property) notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="komi-card overflow-hidden">
        <div className="aspect-video bg-line/40">
          {property.images[0] && <img src={property.images[0].url} alt={property.title} className="w-full h-full object-cover" />}
        </div>
        {property.images.length > 1 && (
          <div className="grid grid-cols-4 gap-1 p-1">
            {property.images.slice(1, 5).map((img) => (
              <div key={img.id} className="aspect-video overflow-hidden rounded">
                <img src={img.url} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mt-5">
        <span className="text-xs font-semibold text-teal uppercase tracking-wide">
          {TYPE_LABEL[property.type]} · {property.transactionType === "SALE" ? "À vendre" : "À louer"}
        </span>
        <h1 className="font-display text-2xl font-bold text-indigo mt-1">{property.title}</h1>
        <p className="text-ink/50 flex items-center gap-1 mt-1">
          <MapPin size={14} /> {property.quartier ? `${property.quartier}, ` : ""}{property.city}
        </p>

        <p className="font-display text-3xl font-bold text-indigo mt-4">
          {property.price.toLocaleString("fr-FR")} FCFA{property.transactionType === "RENT" ? " /mois" : ""}
        </p>

        <div className="flex gap-5 mt-4 text-sm text-ink/70">
          {property.surfaceM2 && <span className="flex items-center gap-1"><Ruler size={14} /> {property.surfaceM2} m²</span>}
          {property.bedrooms != null && <span className="flex items-center gap-1"><BedDouble size={14} /> {property.bedrooms} chambres</span>}
          {property.bathrooms != null && <span className="flex items-center gap-1"><Bath size={14} /> {property.bathrooms} sdb</span>}
        </div>

        <p className="text-ink/70 mt-4 whitespace-pre-line">{property.description}</p>

        {property.amenities.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {property.amenities.map((a) => (
              <span key={a} className="text-xs px-2 py-1 rounded-full border border-line text-ink/70">{a}</span>
            ))}
          </div>
        )}

        <div className="flex items-center gap-2 mt-6">
          <ContactButton recipientId={property.ownerId} label="Contacter le propriétaire" />
          <FavoriteButton targetType="PROPERTY" targetId={property.id} />
        </div>
        <div className="mt-2">
          <ReportButton targetType="PROPERTY" targetId={property.id} />
        </div>
      </div>
    </div>
  );
}
