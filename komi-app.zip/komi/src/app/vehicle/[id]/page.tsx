import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ContactButton from "@/components/ContactButton";
import FavoriteButton from "@/components/FavoriteButton";
import ReportButton from "@/components/ReportButton";
import { MapPin, Gauge, Calendar } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function VehiclePage({ params }: { params: { id: string } }) {
  const vehicle = await db.vehicle.findUnique({
    where: { id: params.id },
    include: { images: true, seller: { select: { firstName: true, lastName: true, phone: true } } }
  });
  if (!vehicle) notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="komi-card overflow-hidden">
        <div className="aspect-video bg-line/40">
          {vehicle.images[0] && <img src={vehicle.images[0].url} alt={vehicle.brand} className="w-full h-full object-cover" />}
        </div>
      </div>

      <div className="mt-5">
        <span className="text-xs font-semibold text-teal uppercase tracking-wide">
          {vehicle.condition === "NEW" ? "Neuf" : "Occasion"}
        </span>
        <h1 className="font-display text-2xl font-bold text-indigo mt-1">
          {vehicle.brand} {vehicle.model} · {vehicle.year}
        </h1>
        <p className="text-ink/50 flex items-center gap-1 mt-1">
          <MapPin size={14} /> {vehicle.quartier ? `${vehicle.quartier}, ` : ""}{vehicle.city}
        </p>

        <p className="font-display text-3xl font-bold text-indigo mt-4">{vehicle.price.toLocaleString("fr-FR")} FCFA</p>

        <div className="flex gap-5 mt-4 text-sm text-ink/70">
          <span className="flex items-center gap-1"><Calendar size={14} /> {vehicle.year}</span>
          {vehicle.mileageKm != null && <span className="flex items-center gap-1"><Gauge size={14} /> {vehicle.mileageKm.toLocaleString("fr-FR")} km</span>}
        </div>

        {vehicle.description && <p className="text-ink/70 mt-4 whitespace-pre-line">{vehicle.description}</p>}

        <div className="flex items-center gap-2 mt-6">
          <ContactButton recipientId={vehicle.sellerId} label="Contacter le vendeur" />
          <FavoriteButton targetType="VEHICLE" targetId={vehicle.id} />
        </div>
        <div className="mt-2">
          <ReportButton targetType="VEHICLE" targetId={vehicle.id} />
        </div>
      </div>
    </div>
  );
}
