"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Bell } from "lucide-react";

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/notifications", { cache: "no-store" });
    const data = await res.json();
    setNotifications(data.notifications);
  }

  useEffect(() => {
    load();
  }, []);

  async function markRead(id: string) {
    await fetch(`/api/notifications/${id}`, { method: "PATCH" });
    setNotifications((prev) => prev?.map((n) => (n.id === id ? { ...n, isRead: true } : n)) ?? null);
  }

  async function markAllRead() {
    await fetch("/api/notifications/read-all", { method: "POST" });
    setNotifications((prev) => prev?.map((n) => ({ ...n, isRead: true })) ?? null);
  }

  if (notifications === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  if (notifications.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">
        <Bell className="mx-auto mb-3" size={40} />
        <p>Aucune notification pour le moment.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display text-2xl font-bold text-indigo">Notifications</h1>
        {notifications.some((n) => !n.isRead) && (
          <button onClick={markAllRead} className="text-sm text-teal font-medium">Tout marquer comme lu</button>
        )}
      </div>
      <div className="space-y-2">
        {notifications.map((n) => (
          <Link
            key={n.id}
            href={n.linkUrl ?? "#"}
            onClick={() => !n.isRead && markRead(n.id)}
            className={`komi-card p-3 block ${!n.isRead ? "border-amber bg-amber/5" : ""}`}
          >
            <p className="font-medium text-sm">{n.title}</p>
            <p className="text-xs text-ink/60 mt-0.5">{n.body}</p>
            <p className="text-[11px] text-ink/40 mt-1">{new Date(n.createdAt).toLocaleString("fr-FR")}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
