"use client";

import { useEffect, useState } from "react";

const STATUS_LABEL: Record<string, string> = {
  SENT: "En attente de ta réponse",
  ACCEPTED: "Accepté",
  REFUSED: "Refusé",
  EXPIRED: "Expiré"
};

export default function ClientQuotesPage() {
  const [quotes, setQuotes] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/quotes", { cache: "no-store" });
    const data = await res.json();
    setQuotes(data.quotes ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function respond(id: string, decision: "ACCEPTED" | "REFUSED") {
    await fetch(`/api/quotes/${id}/respond`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decision })
    });
    load();
  }

  if (quotes === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Mes devis reçus</h1>
      {quotes.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucun devis reçu.</p>}
      {quotes.map((q) => (
        <div key={q.id} className="komi-card p-4">
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="font-medium text-sm">{q.number}</p>
              <p className="text-xs text-ink/50">{q.professional.jobTitle} — {q.professional.user.firstName} {q.professional.user.lastName}</p>
            </div>
            <span className="text-xs font-semibold text-indigo">{STATUS_LABEL[q.status]}</span>
          </div>
          <ul className="text-sm text-ink/70 mb-2">
            {q.lines.map((l: any) => (
              <li key={l.id}>{l.quantity} × {l.label} — {(l.unitPrice * l.quantity).toLocaleString("fr-FR")} FCFA</li>
            ))}
          </ul>
          {q.conditions && <p className="text-xs text-ink/40 mb-2 italic">{q.conditions}</p>}
          <p className="font-display font-bold text-indigo mb-3">{q.total.toLocaleString("fr-FR")} FCFA</p>
          {q.status === "SENT" && (
            <div className="flex gap-2">
              <button onClick={() => respond(q.id, "ACCEPTED")} className="komi-btn-primary text-sm">Accepter</button>
              <button onClick={() => respond(q.id, "REFUSED")} className="komi-btn-secondary text-sm">Refuser</button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
