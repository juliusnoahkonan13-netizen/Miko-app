import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function MyBusinessRedirect() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const business = await db.businessProfile.findUnique({ where: { userId: user.id } });
  redirect(business ? `/business/${business.slug}` : "/sell/business");
}
