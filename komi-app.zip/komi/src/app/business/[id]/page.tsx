import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ContactButton from "@/components/ContactButton";
import { ShieldCheck, MapPin, Globe, Phone } from "lucide-react";

export default async function BusinessPage({ params }: { params: { id: string } }) {
  const business = await db.businessProfile.findFirst({
    where: { OR: [{ slug: params.id }, { id: params.id }] },
    include: { services: true, employees: true }
  });

  if (!business) notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="komi-card p-5 flex items-start gap-4">
        <div className="w-16 h-16 rounded-2xl bg-indigo/10 flex items-center justify-center font-display text-2xl font-bold text-indigo shrink-0">
          {business.companyName[0]}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="font-display text-xl font-bold text-indigo flex items-center gap-2 flex-wrap">
            {business.companyName}
            {business.verification === "VERIFIED" && (
              <span className="komi-badge-verified"><ShieldCheck size={12} /> Vérifié par Komi</span>
            )}
          </h1>
          <p className="text-sm text-ink/50">{business.sector}</p>
          {business.city && (
            <p className="text-sm text-ink/50 flex items-center gap-1 mt-1"><MapPin size={13} /> {business.city}</p>
          )}
          {business.website && (
            <a href={business.website} target="_blank" className="text-sm text-teal flex items-center gap-1 mt-1">
              <Globe size={13} /> {business.website}
            </a>
          )}
          {business.phone && <p className="text-sm text-ink/50 flex items-center gap-1 mt-1"><Phone size={13} /> {business.phone}</p>}
        </div>
        <ContactButton recipientId={business.userId} label="Contacter" />
      </div>

      {business.description && (
        <div className="komi-card p-4">
          <h2 className="font-display font-semibold text-indigo mb-2">À propos</h2>
          <p className="text-sm text-ink/70 whitespace-pre-line">{business.description}</p>
        </div>
      )}

      {business.services.length > 0 && (
        <div className="komi-card p-4">
          <h2 className="font-display font-semibold text-indigo mb-3">Services</h2>
          <div className="grid md:grid-cols-2 gap-3">
            {business.services.map((s) => (
              <div key={s.id} className="border border-line rounded-komi p-3">
                <p className="font-medium text-sm">{s.name}</p>
                {s.description && <p className="text-xs text-ink/50 mt-1">{s.description}</p>}
                {(s.priceFrom || s.priceTo) && (
                  <p className="text-xs text-indigo font-semibold mt-1">
                    {s.priceFrom?.toLocaleString("fr-FR")} {s.priceTo ? `- ${s.priceTo.toLocaleString("fr-FR")}` : ""} FCFA
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {business.employees.length > 0 && (
        <div className="komi-card p-4">
          <h2 className="font-display font-semibold text-indigo mb-3">Équipe</h2>
          <div className="flex flex-wrap gap-4">
            {business.employees.map((e) => (
              <div key={e.id} className="text-center w-20">
                <div className="w-14 h-14 rounded-full bg-line/50 mx-auto mb-1" />
                <p className="text-xs font-medium">{e.fullName}</p>
                {e.role && <p className="text-[10px] text-ink/40">{e.role}</p>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
