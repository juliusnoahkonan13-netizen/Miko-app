"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Star, MapPin, ShieldCheck } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import ProfessionalCard from "@/components/ProfessionalCard";

const TYPES = [
  { value: "", label: "Tout" },
  { value: "product", label: "🛒 Produits" },
  { value: "professional", label: "🔧 Services" },
  { value: "property", label: "🏠 Immobilier" },
  { value: "vehicle", label: "🚗 Véhicules" },
  { value: "business", label: "🏢 Entreprises" },
  { value: "store", label: "🛍️ Boutiques" }
];

function SearchContent() {
  const params = useSearchParams();
  const router = useRouter();
  const q = params.get("q") ?? "";
  const type = params.get("type") ?? "";
  const city = params.get("city") ?? "";
  const minPrice = params.get("minPrice") ?? "";
  const maxPrice = params.get("maxPrice") ?? "";
  const condition = params.get("condition") ?? "";

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  function updateParam(key: string, value: string) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    router.push(`/search?${next.toString()}`);
  }

  useEffect(() => {
    setLoading(true);
    const controller = new AbortController();

    async function run() {
      try {
        if (type === "product") {
          const sp = new URLSearchParams();
          if (q) sp.set("q", q);
          if (city) sp.set("city", city);
          if (minPrice) sp.set("minPrice", minPrice);
          if (maxPrice) sp.set("maxPrice", maxPrice);
          if (condition) sp.set("condition", condition);
          const res = await fetch(`/api/products?${sp}`, { signal: controller.signal });
          setData({ kind: "product", ...(await res.json()) });
        } else if (type === "professional") {
          const sp = new URLSearchParams();
          if (q) sp.set("q", q);
          if (city) sp.set("city", city);
          const res = await fetch(`/api/professionals?${sp}`, { signal: controller.signal });
          setData({ kind: "professional", ...(await res.json()) });
        } else if (type === "property") {
          const sp = new URLSearchParams();
          if (city) sp.set("city", city);
          if (minPrice) sp.set("minPrice", minPrice);
          if (maxPrice) sp.set("maxPrice", maxPrice);
          const res = await fetch(`/api/properties?${sp}`, { signal: controller.signal });
          setData({ kind: "property", ...(await res.json()) });
        } else if (type === "vehicle") {
          const sp = new URLSearchParams();
          if (q) sp.set("brand", q);
          if (city) sp.set("city", city);
          if (maxPrice) sp.set("maxPrice", maxPrice);
          const res = await fetch(`/api/vehicles?${sp}`, { signal: controller.signal });
          setData({ kind: "vehicle", ...(await res.json()) });
        } else if (type === "business") {
          const sp = new URLSearchParams();
          if (q) sp.set("q", q);
          if (city) sp.set("city", city);
          const res = await fetch(`/api/businesses?${sp}`, { signal: controller.signal });
          setData({ kind: "business", ...(await res.json()) });
        } else if (type === "store") {
          const sp = new URLSearchParams();
          if (q) sp.set("q", q);
          if (city) sp.set("city", city);
          const res = await fetch(`/api/stores?${sp}`, { signal: controller.signal });
          setData({ kind: "store", ...(await res.json()) });
        } else if (q) {
          const sp = new URLSearchParams({ q });
          if (city) sp.set("city", city);
          const res = await fetch(`/api/search?${sp}`, { signal: controller.signal });
          setData({ kind: "mixed", ...(await res.json()) });
        } else {
          setData(null);
        }
      } finally {
        setLoading(false);
      }
    }
    run();
    return () => controller.abort();
  }, [q, type, city, minPrice, maxPrice, condition]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex flex-wrap gap-2 mb-4">
        {TYPES.map((t) => (
          <button
            key={t.value}
            onClick={() => updateParam("type", t.value)}
            className={`px-3 py-1.5 rounded-full text-sm font-medium border ${
              type === t.value ? "bg-indigo text-white border-indigo" : "bg-white text-indigo border-line"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-[220px_1fr] gap-6">
        <aside className="komi-card p-4 h-fit space-y-4">
          <h3 className="font-display font-semibold text-indigo">Filtres</h3>
          <FilterField label="Ville">
            <input className="komi-input" defaultValue={city} onBlur={(e) => updateParam("city", e.target.value)} placeholder="Abidjan, Yopougon..." />
          </FilterField>
          {(type === "product" || type === "property" || type === "vehicle" || type === "") && (
            <div className="grid grid-cols-2 gap-2">
              <FilterField label="Prix min">
                <input type="number" className="komi-input" defaultValue={minPrice} onBlur={(e) => updateParam("minPrice", e.target.value)} />
              </FilterField>
              <FilterField label="Prix max">
                <input type="number" className="komi-input" defaultValue={maxPrice} onBlur={(e) => updateParam("maxPrice", e.target.value)} />
              </FilterField>
            </div>
          )}
          {type === "product" && (
            <FilterField label="État">
              <select className="komi-input" value={condition} onChange={(e) => updateParam("condition", e.target.value)}>
                <option value="">Tous</option>
                <option value="neuf">Neuf</option>
                <option value="occasion">Occasion</option>
              </select>
            </FilterField>
          )}
        </aside>

        <div>
          {loading && <p className="text-ink/50 text-sm">Recherche en cours...</p>}
          {!loading && !data && <p className="text-ink/50 text-sm">Écris une recherche ou choisis une catégorie.</p>}
          {!loading && data && <ResultsView data={data} />}
        </div>
      </div>
    </div>
  );
}

function ResultsView({ data }: { data: any }) {
  if (data.kind === "product") {
    if (!data.products?.length) return <EmptyState text="Aucun produit ne correspond à ta recherche." />;
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {data.products.map((p: any) => (
          <ProductCard key={p.id} id={p.id} slug={p.slug} name={p.name} price={p.price} promoPrice={p.promoPrice} imageUrl={p.images[0]?.url} storeName={p.store?.name} />
        ))}
      </div>
    );
  }

  if (data.kind === "professional") {
    if (!data.professionals?.length) return <EmptyState text="Aucun professionnel trouvé." />;
    return (
      <div className="grid md:grid-cols-2 gap-4">
        {data.professionals.map((p: any) => (
          <ProfessionalCard key={p.id} id={p.id} jobTitle={p.jobTitle} firstName={p.user.firstName} lastName={p.user.lastName} city={p.city} quartier={p.quartier} ratingAvg={p.ratingAvg} ratingCount={p.ratingCount} verified={p.verification === "VERIFIED"} />
        ))}
      </div>
    );
  }

  if (data.kind === "property") {
    if (!data.properties?.length) return <EmptyState text="Aucune annonce immobilière trouvée." />;
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {data.properties.map((prop: any) => (
          <Link key={prop.id} href={`/property/${prop.id}`} className="komi-card overflow-hidden block">
            <div className="aspect-video bg-line/40">
              {prop.images[0] && <img src={prop.images[0].url} alt={prop.title} className="w-full h-full object-cover" />}
            </div>
            <div className="p-3">
              <p className="text-sm font-medium line-clamp-1">{prop.title}</p>
              <p className="text-xs text-ink/50 flex items-center gap-1"><MapPin size={12} /> {prop.city}{prop.quartier ? `, ${prop.quartier}` : ""}</p>
              <p className="font-display font-semibold text-indigo mt-1">{prop.price.toLocaleString("fr-FR")} FCFA</p>
            </div>
          </Link>
        ))}
      </div>
    );
  }

  if (data.kind === "vehicle") {
    if (!data.vehicles?.length) return <EmptyState text="Aucun véhicule trouvé." />;
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {data.vehicles.map((v: any) => (
          <Link key={v.id} href={`/vehicle/${v.id}`} className="komi-card overflow-hidden block">
            <div className="aspect-video bg-line/40">
              {v.images[0] && <img src={v.images[0].url} alt={v.brand} className="w-full h-full object-cover" />}
            </div>
            <div className="p-3">
              <p className="text-sm font-medium">{v.brand} {v.model} · {v.year}</p>
              <p className="text-xs text-ink/50">{v.mileageKm?.toLocaleString("fr-FR")} km · {v.city}</p>
              <p className="font-display font-semibold text-indigo mt-1">{v.price.toLocaleString("fr-FR")} FCFA</p>
            </div>
          </Link>
        ))}
      </div>
    );
  }

  if (data.kind === "business") {
    if (!data.businesses?.length) return <EmptyState text="Aucune entreprise trouvée." />;
    return (
      <div className="grid md:grid-cols-2 gap-4">
        {data.businesses.map((b: any) => (
          <Link key={b.id} href={`/business/${b.id}`} className="komi-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo/10 flex items-center justify-center font-display font-bold text-indigo">{b.companyName[0]}</div>
            <div>
              <p className="font-medium flex items-center gap-1">{b.companyName} {b.verification === "VERIFIED" && <ShieldCheck size={14} className="text-teal" />}</p>
              <p className="text-xs text-ink/50">{b.sector} · {b.city}</p>
            </div>
          </Link>
        ))}
      </div>
    );
  }

  if (data.kind === "store") {
    if (!data.stores?.length) return <EmptyState text="Aucune boutique trouvée." />;
    return (
      <div className="grid md:grid-cols-2 gap-4">
        {data.stores.map((s: any) => (
          <Link key={s.id} href={`/store/${s.slug}`} className="komi-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber/20 flex items-center justify-center font-display font-bold text-amber-dark">{s.name[0]}</div>
            <div>
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-ink/50">{s._count?.products ?? 0} produits · {s.city}</p>
            </div>
          </Link>
        ))}
      </div>
    );
  }

  // mixed Komi AI results
  const r = data.results ?? {};
  const sections: [string, any[]][] = [
    ["🛒 Produits", r.products ?? []],
    ["🔧 Professionnels", r.professionals ?? []],
    ["🏠 Immobilier", r.properties ?? []],
    ["🚗 Véhicules", r.vehicles ?? []],
    ["🛍️ Boutiques", r.stores ?? []]
  ];

  if (data.totalResults === 0) return <EmptyState text={`Aucun résultat pour "${data.query}".`} />;

  return (
    <div className="space-y-8">
      {sections.map(
        ([label, items]) =>
          items.length > 0 && (
            <div key={label}>
              <h3 className="font-display font-semibold text-indigo mb-3">{label}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {items.map((item: any) => (
                  <Link key={item.id} href={resolveLink(label, item)} className="komi-card p-3 block">
                    <p className="text-sm font-medium line-clamp-1">
                      {item.name ?? item.jobTitle ?? item.title ?? `${item.brand ?? ""} ${item.model ?? ""}`}
                    </p>
                    {item.price != null && (
                      <p className="text-xs text-indigo font-semibold mt-1">{item.price.toLocaleString("fr-FR")} FCFA</p>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          )
      )}
    </div>
  );
}

function resolveLink(label: string, item: any) {
  if (label.includes("Produits")) return `/product/${item.slug ?? item.id}`;
  if (label.includes("Professionnels")) return `/professional/${item.id}`;
  if (label.includes("Immobilier")) return `/property/${item.id}`;
  if (label.includes("Véhicules")) return `/vehicle/${item.id}`;
  if (label.includes("Boutiques")) return `/store/${item.slug ?? item.id}`;
  return "#";
}

function FilterField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-center py-16 text-ink/50">
      <p className="text-3xl mb-2">🔎</p>
      <p>{text}</p>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense>
      <SearchContent />
    </Suspense>
  );
}
