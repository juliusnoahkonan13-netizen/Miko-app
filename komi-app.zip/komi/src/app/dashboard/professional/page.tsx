"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Star, FileText, CalendarClock, ShieldCheck } from "lucide-react";

export default function ProfessionalDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    fetch("/api/dashboard/professional", { cache: "no-store" }).then(async (res) => {
      if (res.status === 404) return setNotFound(true);
      setStats(await res.json());
    });
  }, []);

  if (notFound) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <p className="text-4xl mb-3">🔧</p>
        <h1 className="font-display text-xl font-bold text-indigo mb-2">Crée ton profil professionnel</h1>
        <Link href="/sell/professional" className="komi-btn-primary inline-block mt-2">Devenir professionnel sur Komi</Link>
      </div>
    );
  }

  if (!stats) return <div className="max-w-4xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="font-display text-2xl font-bold text-indigo">Espace professionnel</h1>
        <div className="flex gap-2 flex-wrap">
          <Link href="/dashboard/professional/services/new" className="komi-btn-amber text-sm">+ Service</Link>
          <Link href="/dashboard/professional/appointments" className="komi-btn-secondary text-sm">Rendez-vous</Link>
          <Link href="/dashboard/professional/quotes" className="komi-btn-secondary text-sm">Devis</Link>
          <Link href="/dashboard/professional/availability" className="komi-btn-secondary text-sm">Disponibilités</Link>
        </div>
      </div>

      {stats.verification !== "VERIFIED" && (
        <div className="komi-card p-3 text-sm text-amber-dark bg-amber/10 border-amber flex items-center gap-2">
          <ShieldCheck size={16} /> Ton profil n'est pas encore vérifié par Komi. La vérification renforce la confiance des clients.
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Star} label="Note moyenne" value={`${stats.ratingAvg.toFixed(1)} (${stats.ratingCount})`} />
        <StatCard icon={FileText} label="Devis envoyés" value={stats.quotesSent} />
        <StatCard icon={FileText} label="Devis acceptés" value={stats.quotesAccepted} />
        <StatCard icon={CalendarClock} label="RDV à venir" value={stats.upcomingAppointments} />
      </div>

      <Link href="/service-requests" className="komi-card p-4 block hover:border-amber">
        <p className="font-display font-semibold text-indigo">🔎 Voir les demandes de service des clients</p>
        <p className="text-sm text-ink/50 mt-1">Réponds avec un prix et une disponibilité pour décrocher la mission.</p>
      </Link>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: any }) {
  return (
    <div className="komi-card p-4">
      <Icon size={18} className="text-teal mb-2" />
      <p className="text-xl font-display font-bold text-indigo">{value}</p>
      <p className="text-xs text-ink/50">{label}</p>
    </div>
  );
}
