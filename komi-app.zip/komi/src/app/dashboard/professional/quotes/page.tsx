"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const STATUS_LABEL: Record<string, string> = {
  SENT: "Envoyé",
  ACCEPTED: "Accepté",
  REFUSED: "Refusé",
  EXPIRED: "Expiré"
};

export default function ProfessionalQuotesPage() {
  const [quotes, setQuotes] = useState<any[] | null>(null);

  useEffect(() => {
    fetch("/api/quotes?as=professional", { cache: "no-store" })
      .then((res) => res.json())
      .then((data) => setQuotes(data.quotes ?? []));
  }, []);

  if (quotes === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-indigo">Mes devis</h1>
        <Link href="/dashboard/professional/quotes/new" className="komi-btn-amber text-sm">+ Nouveau devis</Link>
      </div>
      {quotes.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Pas encore de devis envoyé.</p>}
      {quotes.map((q) => (
        <div key={q.id} className="komi-card p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="font-medium text-sm">{q.number}</p>
              <p className="text-xs text-ink/50">{q.client.firstName} {q.client.lastName}</p>
            </div>
            <span className="text-xs font-semibold text-indigo">{STATUS_LABEL[q.status]}</span>
          </div>
          <ul className="text-sm text-ink/70 my-2">
            {q.lines.map((l: any) => (
              <li key={l.id}>{l.quantity} × {l.label} — {(l.unitPrice * l.quantity).toLocaleString("fr-FR")} FCFA</li>
            ))}
          </ul>
          <p className="font-display font-bold text-indigo">{q.total.toLocaleString("fr-FR")} FCFA</p>
        </div>
      ))}
    </div>
  );
}
