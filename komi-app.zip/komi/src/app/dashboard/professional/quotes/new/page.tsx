"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";

type Line = { label: string; quantity: number; unitPrice: number };

export default function NewQuotePage() {
  const router = useRouter();
  const [contacts, setContacts] = useState<any[]>([]);
  const [clientId, setClientId] = useState("");
  const [conditions, setConditions] = useState("Devis valable 15 jours. Acompte de 30% à la commande.");
  const [lines, setLines] = useState<Line[]>([{ label: "", quantity: 1, unitPrice: 0 }]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/conversations")
      .then((res) => res.json())
      .then(async (data) => {
        const meRes = await fetch("/api/auth/me");
        const me = await meRes.json();
        const others = data.conversations
          .map((c: any) => c.participants.find((p: any) => p.user.id !== me.user?.id)?.user)
          .filter(Boolean);
        setContacts(others);
      });
  }, []);

  function updateLine(i: number, field: keyof Line, value: string) {
    setLines(lines.map((l, idx) => (idx === i ? { ...l, [field]: field === "label" ? value : Number(value) } : l)));
  }

  const total = lines.reduce((sum, l) => sum + l.quantity * l.unitPrice, 0);

  async function submit() {
    if (!clientId) return setError("Choisis un client (contacte-le d'abord en message).");
    if (lines.some((l) => !l.label || l.unitPrice <= 0)) return setError("Complète chaque ligne du devis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientId, conditions, lines })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push("/dashboard/professional/quotes");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Nouveau devis</h1>

      <div>
        <label className="text-sm text-ink/60">Client</label>
        <select className="komi-input mt-1" value={clientId} onChange={(e) => setClientId(e.target.value)}>
          <option value="">Choisir un client...</option>
          {contacts.map((c) => (
            <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>
          ))}
        </select>
        {contacts.length === 0 && <p className="text-xs text-ink/40 mt-1">Contacte d'abord le client en message pour pouvoir lui envoyer un devis.</p>}
      </div>

      <div className="space-y-2">
        <label className="text-sm text-ink/60">Prestations</label>
        {lines.map((line, i) => (
          <div key={i} className="flex gap-2 items-center">
            <input className="komi-input flex-1" placeholder="Prestation" value={line.label} onChange={(e) => updateLine(i, "label", e.target.value)} />
            <input type="number" className="komi-input w-16" placeholder="Qté" value={line.quantity} onChange={(e) => updateLine(i, "quantity", e.target.value)} />
            <input type="number" className="komi-input w-28" placeholder="Prix unit." value={line.unitPrice || ""} onChange={(e) => updateLine(i, "unitPrice", e.target.value)} />
            <button onClick={() => setLines(lines.filter((_, idx) => idx !== i))} className="text-ink/30 hover:text-red-500">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
        <button onClick={() => setLines([...lines, { label: "", quantity: 1, unitPrice: 0 }])} className="text-teal text-sm flex items-center gap-1">
          <Plus size={14} /> Ajouter une ligne
        </button>
      </div>

      <textarea className="komi-input" rows={2} placeholder="Conditions" value={conditions} onChange={(e) => setConditions(e.target.value)} />

      <div className="komi-card p-3 flex justify-between font-display font-bold text-indigo">
        <span>Total</span>
        <span>{total.toLocaleString("fr-FR")} FCFA</span>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Envoi..." : "Envoyer le devis"}
      </button>
    </div>
  );
}
