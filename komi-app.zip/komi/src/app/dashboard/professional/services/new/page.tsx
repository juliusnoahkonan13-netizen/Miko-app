"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewServicePage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", description: "", priceFrom: "", priceTo: "" });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!form.name) return setError("Le nom du service est requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/services", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          description: form.description || undefined,
          priceFrom: form.priceFrom ? Number(form.priceFrom) : undefined,
          priceTo: form.priceTo ? Number(form.priceTo) : undefined
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push("/dashboard/professional");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Ajouter un service</h1>
      <input className="komi-input" placeholder="Ex : Réparation de fuite" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <textarea className="komi-input" rows={3} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      <div className="grid grid-cols-2 gap-3">
        <input type="number" className="komi-input" placeholder="Prix à partir de" value={form.priceFrom} onChange={(e) => setForm({ ...form, priceFrom: e.target.value })} />
        <input type="number" className="komi-input" placeholder="Prix jusqu'à (optionnel)" value={form.priceTo} onChange={(e) => setForm({ ...form, priceTo: e.target.value })} />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Ajout..." : "Ajouter le service"}
      </button>
    </div>
  );
}
