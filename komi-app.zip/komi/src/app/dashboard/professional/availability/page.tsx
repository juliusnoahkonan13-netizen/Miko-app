"use client";

import { useEffect, useState } from "react";

const DAYS = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

type Slot = { dayOfWeek: number; startTime: string; endTime: string };

export default function AvailabilityPage() {
  const [professionalId, setProfessionalId] = useState<string | null>(null);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/dashboard/professional")
      .then((res) => res.json())
      .then(async (dash) => {
        if (!dash.id) return;
        setProfessionalId(dash.id);
        const res = await fetch(`/api/professionals/${dash.id}/availability`);
        const data = await res.json();
        setSlots(data.availabilities?.map((a: any) => ({ dayOfWeek: a.dayOfWeek, startTime: a.startTime, endTime: a.endTime })) ?? []);
      });
  }, []);

  function toggleDay(day: number) {
    const exists = slots.find((s) => s.dayOfWeek === day);
    if (exists) setSlots(slots.filter((s) => s.dayOfWeek !== day));
    else setSlots([...slots, { dayOfWeek: day, startTime: "09:00", endTime: "17:00" }]);
  }

  function updateSlot(day: number, field: "startTime" | "endTime", value: string) {
    setSlots(slots.map((s) => (s.dayOfWeek === day ? { ...s, [field]: value } : s)));
  }

  async function save() {
    if (!professionalId) return;
    setSaving(true);
    await fetch(`/api/professionals/${professionalId}/availability`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slots })
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Mes disponibilités</h1>
      <p className="text-sm text-ink/50">Coche les jours où tu travailles et définis tes horaires.</p>

      <div className="space-y-2">
        {DAYS.map((label, day) => {
          const slot = slots.find((s) => s.dayOfWeek === day);
          return (
            <div key={day} className="komi-card p-3 flex items-center gap-3">
              <label className="flex items-center gap-2 w-28 shrink-0">
                <input type="checkbox" checked={!!slot} onChange={() => toggleDay(day)} />
                <span className="text-sm font-medium">{label}</span>
              </label>
              {slot && (
                <div className="flex items-center gap-2">
                  <input type="time" className="komi-input" value={slot.startTime} onChange={(e) => updateSlot(day, "startTime", e.target.value)} />
                  <span className="text-ink/40">→</span>
                  <input type="time" className="komi-input" value={slot.endTime} onChange={(e) => updateSlot(day, "endTime", e.target.value)} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <button onClick={save} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Enregistrement..." : saved ? "Enregistré ✓" : "Enregistrer mes disponibilités"}
      </button>
    </div>
  );
}
