"use client";

import { useEffect, useState } from "react";

export default function ProfessionalAppointmentsPage() {
  const [appointments, setAppointments] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/appointments?as=professional", { cache: "no-store" });
    const data = await res.json();
    setAppointments(data.appointments ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    load();
  }

  if (appointments === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-3">
      <h1 className="font-display text-2xl font-bold text-indigo mb-2">Mes rendez-vous</h1>
      {appointments.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucun rendez-vous.</p>}
      {appointments.map((a) => (
        <div key={a.id} className="komi-card p-4">
          <p className="font-medium text-sm">{a.client.firstName} {a.client.lastName}</p>
          <p className="text-xs text-ink/50">{new Date(a.startTime).toLocaleString("fr-FR")}</p>
          {a.note && <p className="text-sm text-ink/60 mt-1">{a.note}</p>}
          <p className="text-xs font-semibold text-indigo mt-2">{a.status}</p>
          {a.status === "PENDING" && (
            <div className="flex gap-2 mt-2">
              <button onClick={() => updateStatus(a.id, "CONFIRMED")} className="komi-btn-primary text-sm">Confirmer</button>
              <button onClick={() => updateStatus(a.id, "CANCELLED")} className="komi-btn-secondary text-sm">Refuser</button>
            </div>
          )}
          {a.status === "CONFIRMED" && new Date(a.startTime) < new Date() && (
            <button onClick={() => updateStatus(a.id, "COMPLETED")} className="komi-btn-secondary text-sm mt-2">Marquer terminé</button>
          )}
        </div>
      ))}
    </div>
  );
}
