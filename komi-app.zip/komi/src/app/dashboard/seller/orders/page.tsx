"use client";

import { useEffect, useState } from "react";

const NEXT_STATUS: Record<string, { value: string; label: string }[]> = {
  PENDING: [{ value: "CONFIRMED", label: "Confirmer" }, { value: "CANCELLED", label: "Refuser" }],
  CONFIRMED: [{ value: "PREPARING", label: "Préparer" }, { value: "CANCELLED", label: "Annuler" }],
  PREPARING: [{ value: "SHIPPED", label: "Marquer expédiée" }],
  SHIPPED: [{ value: "DELIVERED", label: "Marquer livrée" }],
  DELIVERED: [],
  CANCELLED: []
};

export default function SellerOrdersPage() {
  const [orders, setOrders] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/orders?as=seller", { cache: "no-store" });
    const data = await res.json();
    setOrders(data.orders ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(orderId: string, status: string) {
    await fetch(`/api/orders/${orderId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    load();
  }

  if (orders === null) return <div className="max-w-3xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Commandes reçues</h1>
      {orders.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Pas encore de commande.</p>}
      {orders.map((order) => (
        <div key={order.id} className="komi-card p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="font-medium text-sm">#{order.id.slice(-6).toUpperCase()} · {order.buyer.firstName} {order.buyer.lastName}</p>
            <span className="text-xs font-semibold text-indigo">{order.status}</span>
          </div>
          <p className="text-xs text-ink/50 mb-2">{order.buyer.phone ?? "Pas de téléphone renseigné"}</p>
          <ul className="text-sm text-ink/70 mb-3">
            {order.items.map((item: any) => (
              <li key={item.id}>{item.quantity} × {item.product.name}</li>
            ))}
          </ul>
          <p className="font-display font-semibold text-indigo mb-3">{order.total.toLocaleString("fr-FR")} FCFA</p>
          <div className="flex gap-2">
            {NEXT_STATUS[order.status]?.map((next) => (
              <button
                key={next.value}
                onClick={() => updateStatus(order.id, next.value)}
                className={next.value === "CANCELLED" ? "komi-btn-secondary text-sm" : "komi-btn-primary text-sm"}
              >
                {next.label}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
