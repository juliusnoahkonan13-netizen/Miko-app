"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Trash2, Eye, EyeOff } from "lucide-react";

export default function SellerProductsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display text-2xl font-bold text-indigo">Mes produits</h1>
        <Link href="/dashboard/seller/products/new" className="komi-btn-amber text-sm">+ Ajouter</Link>
      </div>
      <ProductList />
    </div>
  );
}

function ProductList() {
  const [products, setProducts] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/dashboard/seller/products", { cache: "no-store" });
    if (res.ok) setProducts((await res.json()).products);
    else setProducts([]);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleActive(id: string, isActive: boolean) {
    await fetch(`/api/products/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive })
    });
    load();
  }

  async function remove(id: string) {
    if (!confirm("Supprimer ce produit ?")) return;
    await fetch(`/api/products/${id}`, { method: "DELETE" });
    load();
  }

  if (products === null) return <p className="text-ink/50">Chargement...</p>;
  if (products.length === 0) return <p className="text-ink/40 text-sm py-10 text-center">Pas encore de produit.</p>;

  return (
    <div className="space-y-2">
      {products.map((p) => (
        <div key={p.id} className="komi-card p-3 flex items-center gap-3">
          <div className="w-14 h-14 rounded-komi bg-line/40 overflow-hidden shrink-0">
            {p.images[0] && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.images[0].url} alt="" className="w-full h-full object-cover" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm truncate">{p.name}</p>
            <p className="text-xs text-ink/50">{p.stock} en stock · {p.price.toLocaleString("fr-FR")} FCFA</p>
          </div>
          <button onClick={() => toggleActive(p.id, p.isActive)} className="text-ink/40 hover:text-teal" title={p.isActive ? "Masquer" : "Publier"}>
            {p.isActive ? <Eye size={18} /> : <EyeOff size={18} />}
          </button>
          <button onClick={() => remove(p.id)} className="text-ink/30 hover:text-red-500">
            <Trash2 size={18} />
          </button>
        </div>
      ))}
    </div>
  );
}
