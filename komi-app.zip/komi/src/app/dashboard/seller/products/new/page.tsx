"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import ImageUploader from "@/components/ImageUploader";

export default function NewProductPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<any[]>([]);
  const [images, setImages] = useState<string[]>([]);
  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    promoPrice: "",
    stock: "1",
    brand: "",
    condition: "neuf",
    categoryId: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories ?? []));
  }, []);

  async function submit() {
    setError(null);
    if (images.length === 0) return setError("Ajoute au moins une photo.");
    if (!form.name || !form.description || !form.price) return setError("Nom, description et prix sont requis.");

    setSaving(true);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          description: form.description,
          price: Number(form.price),
          promoPrice: form.promoPrice ? Number(form.promoPrice) : undefined,
          stock: Number(form.stock || 0),
          brand: form.brand || undefined,
          condition: form.condition,
          categoryId: form.categoryId || undefined,
          images
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur lors de la création.");
      router.push("/dashboard/seller/products");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Ajouter un produit</h1>

      <ImageUploader urls={images} onChange={setImages} />

      <input className="komi-input" placeholder="Nom du produit" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <textarea className="komi-input" rows={4} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

      <div className="grid grid-cols-2 gap-3">
        <input type="number" className="komi-input" placeholder="Prix (FCFA)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
        <input type="number" className="komi-input" placeholder="Prix promo (optionnel)" value={form.promoPrice} onChange={(e) => setForm({ ...form, promoPrice: e.target.value })} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <input type="number" className="komi-input" placeholder="Stock" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
        <input className="komi-input" placeholder="Marque (optionnel)" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <select className="komi-input" value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value })}>
          <option value="neuf">Neuf</option>
          <option value="occasion">Occasion</option>
        </select>
        <select className="komi-input" value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
          <option value="">Catégorie (optionnel)</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Publication..." : "Publier le produit"}
      </button>
    </div>
  );
}
