"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Package, ShoppingBag, TrendingUp, Clock } from "lucide-react";

export default function SellerDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/seller", { cache: "no-store" })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) setError(data.error);
        else setStats(data);
      });
  }, []);

  if (error === "Aucune boutique.") {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <p className="text-4xl mb-3">🛍️</p>
        <h1 className="font-display text-xl font-bold text-indigo mb-2">Tu n'as pas encore de boutique</h1>
        <Link href="/sell/store" className="komi-btn-primary inline-block mt-2">Créer ma boutique</Link>
      </div>
    );
  }

  if (!stats) return <div className="max-w-4xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-indigo">Tableau de bord vendeur</h1>
        <div className="flex gap-2">
          <Link href="/dashboard/seller/products/new" className="komi-btn-amber text-sm">+ Produit</Link>
          <Link href="/dashboard/seller/orders" className="komi-btn-secondary text-sm">Commandes</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={TrendingUp} label="Revenus aujourd'hui" value={`${stats.today.revenue.toLocaleString("fr-FR")} FCFA`} />
        <StatCard icon={ShoppingBag} label="Commandes aujourd'hui" value={stats.today.orders} />
        <StatCard icon={Package} label="Produits actifs" value={stats.productCount} />
        <StatCard icon={Clock} label="Commandes en attente" value={stats.pendingOrders} accent />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="komi-card p-4">
          <h2 className="font-display font-semibold text-indigo mb-3">Revenus</h2>
          <Row label="Cette semaine" value={`${stats.week.revenue.toLocaleString("fr-FR")} FCFA`} sub={`${stats.week.orders} commandes`} />
          <Row label="Ce mois" value={`${stats.month.revenue.toLocaleString("fr-FR")} FCFA`} sub={`${stats.month.orders} commandes`} />
        </div>
        <div className="komi-card p-4">
          <h2 className="font-display font-semibold text-indigo mb-3">Produits populaires</h2>
          {stats.topProducts.length === 0 && <p className="text-sm text-ink/40">Pas encore de vente.</p>}
          {stats.topProducts.map((tp: any, i: number) => (
            <Row key={i} label={tp.product?.name ?? "Produit"} value={`${tp.quantitySold} vendu(s)`} />
          ))}
        </div>
      </div>

      <Link href="/dashboard/seller/products" className="komi-btn-secondary inline-block">Gérer mes produits</Link>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent }: { icon: any; label: string; value: any; accent?: boolean }) {
  return (
    <div className={`komi-card p-4 ${accent && Number(value) > 0 ? "border-amber" : ""}`}>
      <Icon size={18} className="text-teal mb-2" />
      <p className="text-xl font-display font-bold text-indigo">{value}</p>
      <p className="text-xs text-ink/50">{label}</p>
    </div>
  );
}

function Row({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="flex items-center justify-between py-1.5 text-sm">
      <div>
        <p>{label}</p>
        {sub && <p className="text-xs text-ink/40">{sub}</p>}
      </div>
      <span className="font-semibold text-indigo">{value}</span>
    </div>
  );
}
