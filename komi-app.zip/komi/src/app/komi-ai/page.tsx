"use client";

import { useState } from "react";
import Link from "next/link";
import { Sparkles, Send } from "lucide-react";

type Turn = {
  role: "user" | "assistant";
  text: string;
  results?: any;
};

const SUGGESTIONS = [
  "Je cherche un plombier à Yopougon",
  "Maison à louer avec 3 chambres à Cocody",
  "Chaussures à moins de 20000 FCFA"
];

export default function KomiAiPage() {
  const [turns, setTurns] = useState<Turn[]>([
    { role: "assistant", text: "Bonjour 👋 Dis-moi ce que tu cherches — produit, service, professionnel, immobilier ou véhicule." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function ask(message: string) {
    if (!message.trim()) return;
    setTurns((t) => [...t, { role: "user", text: message }]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/komi-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message })
      });
      const data = await res.json();
      setTurns((t) => [...t, { role: "assistant", text: data.reply, results: data.results }]);
    } catch {
      setTurns((t) => [...t, { role: "assistant", text: "Une erreur est survenue, réessaie." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 flex flex-col h-[calc(100vh-140px)]">
      <h1 className="font-display text-2xl font-bold text-indigo flex items-center gap-2 mb-4">
        <Sparkles className="text-amber" size={22} /> Komi AI
      </h1>

      <div className="flex-1 overflow-y-auto space-y-4 pb-4">
        {turns.map((turn, i) => (
          <div key={i} className={`flex ${turn.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${turn.role === "user" ? "bg-indigo text-white" : "komi-card"}`}>
              <p>{turn.text}</p>
              {turn.results && <ResultCards results={turn.results} />}
            </div>
          </div>
        ))}
        {loading && <p className="text-ink/40 text-sm">Komi AI cherche...</p>}
      </div>

      {turns.length === 1 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {SUGGESTIONS.map((s) => (
            <button key={s} onClick={() => ask(s)} className="text-xs px-3 py-1.5 rounded-full border border-line text-ink/60 hover:border-amber">
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="flex gap-2 border-t border-line pt-3">
        <input
          className="komi-input"
          placeholder="Écris ta recherche en langage naturel..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && ask(input)}
        />
        <button onClick={() => ask(input)} disabled={loading} className="komi-btn-primary px-4">
          <Send size={16} />
        </button>
      </div>
    </div>
  );
}

function ResultCards({ results }: { results: any }) {
  const groups: { label: string; items: any[]; link: (item: any) => string; title: (item: any) => string; price?: (item: any) => number | null }[] = [
    { label: "Produits", items: results.products ?? [], link: (p) => `/product/${p.slug}`, title: (p) => p.name, price: (p) => p.promoPrice ?? p.price },
    { label: "Professionnels", items: results.professionals ?? [], link: (p) => `/professional/${p.id}`, title: (p) => `${p.jobTitle} — ${p.user.firstName} ${p.user.lastName}` },
    { label: "Immobilier", items: results.properties ?? [], link: (p) => `/property/${p.id}`, title: (p) => p.title, price: (p) => p.price },
    { label: "Véhicules", items: results.vehicles ?? [], link: (v) => `/vehicle/${v.id}`, title: (v) => `${v.brand} ${v.model} (${v.year})`, price: (v) => v.price },
    { label: "Services", items: results.services ?? [], link: () => "/service-requests", title: (s) => s.name }
  ];

  const nonEmpty = groups.filter((g) => g.items.length > 0);
  if (nonEmpty.length === 0) return null;

  return (
    <div className="mt-3 space-y-3">
      {nonEmpty.map((group) => (
        <div key={group.label}>
          <p className="text-xs font-semibold text-ink/50 mb-1">{group.label}</p>
          <div className="space-y-1.5">
            {group.items.slice(0, 4).map((item: any, i: number) => (
              <Link key={i} href={group.link(item)} className="block bg-ivoire rounded-lg px-3 py-2 hover:bg-line/40">
                <p className="text-sm font-medium text-ink">{group.title(item)}</p>
                {group.price?.(item) != null && (
                  <p className="text-xs text-indigo font-semibold">{group.price!(item)!.toLocaleString("fr-FR")} FCFA</p>
                )}
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
