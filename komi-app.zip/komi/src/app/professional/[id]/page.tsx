import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ContactButton from "@/components/ContactButton";
import BookAppointmentButton from "@/components/BookAppointmentButton";
import FavoriteButton from "@/components/FavoriteButton";
import ReportButton from "@/components/ReportButton";
import { Star, ShieldCheck, MapPin, Briefcase } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProfessionalPage({ params }: { params: { id: string } }) {
  const profile = await db.professionalProfile.findUnique({
    where: { id: params.id },
    include: {
      user: { select: { firstName: true, lastName: true, avatarUrl: true } },
      services: true,
      portfolioImages: true
    }
  });
  if (!profile) notFound();

  const reviews = await db.review.findMany({
    where: { targetType: "PROFESSIONAL", targetId: profile.id },
    include: { author: { select: { firstName: true, lastName: true } } },
    orderBy: { createdAt: "desc" },
    take: 10
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="komi-card p-6 flex flex-col md:flex-row md:items-start gap-4">
        <div className="w-16 h-16 rounded-full bg-teal/10 text-teal flex items-center justify-center font-display text-xl font-bold shrink-0">
          {profile.user.firstName[0]}{profile.user.lastName[0]}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="font-display text-2xl font-bold text-indigo">
              {profile.user.firstName} {profile.user.lastName}
            </h1>
            {profile.verification === "VERIFIED" && (
              <span className="komi-badge-verified"><ShieldCheck size={12} /> Vérifié par Komi</span>
            )}
          </div>
          <p className="text-indigo/80 flex items-center gap-1 mt-1"><Briefcase size={14} /> {profile.jobTitle}</p>
          <div className="flex items-center gap-4 text-sm text-ink/50 mt-1">
            <span className="flex items-center gap-1"><Star size={14} className="fill-amber text-amber" /> {profile.ratingAvg.toFixed(1)} ({profile.ratingCount} avis)</span>
            <span className="flex items-center gap-1"><MapPin size={14} /> {profile.quartier ? `${profile.quartier}, ` : ""}{profile.city}</span>
          </div>
          {profile.description && <p className="text-ink/70 mt-3">{profile.description}</p>}

          <div className="flex items-center gap-2 mt-4">
            <ContactButton recipientId={profile.userId} />
            <BookAppointmentButton professionalId={profile.id} />
            <FavoriteButton targetType="PROFESSIONAL" targetId={profile.id} />
          </div>
          <div className="mt-2">
            <ReportButton targetType="PROFESSIONAL" targetId={profile.id} />
          </div>
        </div>
      </div>

      {profile.services.length > 0 && (
        <section className="mt-8">
          <h2 className="font-display text-xl font-semibold text-indigo mb-3">Services</h2>
          <div className="grid md:grid-cols-2 gap-3">
            {profile.services.map((s) => (
              <div key={s.id} className="komi-card p-4">
                <p className="font-medium">{s.name}</p>
                {s.description && <p className="text-sm text-ink/60 mt-1">{s.description}</p>}
                {(s.priceFrom || s.priceTo) && (
                  <p className="text-sm text-indigo font-semibold mt-2">
                    {s.priceFrom?.toLocaleString("fr-FR")} {s.priceTo ? `– ${s.priceTo.toLocaleString("fr-FR")}` : ""} FCFA
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {profile.portfolioImages.length > 0 && (
        <section className="mt-8">
          <h2 className="font-display text-xl font-semibold text-indigo mb-3">Réalisations</h2>
          <div className="grid grid-cols-3 gap-2">
            {profile.portfolioImages.map((img) => (
              <div key={img.id} className="aspect-square komi-card overflow-hidden">
                <img src={img.url} alt={img.caption ?? ""} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="mt-8">
        <h2 className="font-display text-xl font-semibold text-indigo mb-3">Avis ({reviews.length})</h2>
        <div className="space-y-3">
          {reviews.map((r) => (
            <div key={r.id} className="komi-card p-4">
              <div className="flex items-center justify-between">
                <p className="font-medium text-sm">{r.author.firstName} {r.author.lastName}</p>
                <span className="flex items-center gap-1 text-sm">
                  <Star size={14} className="fill-amber text-amber" /> {r.rating}/5
                </span>
              </div>
              {r.comment && <p className="text-sm text-ink/70 mt-1">{r.comment}</p>}
            </div>
          ))}
          {reviews.length === 0 && <p className="text-ink/40 text-sm">Aucun avis pour le moment.</p>}
        </div>
      </section>
    </div>
  );
}
