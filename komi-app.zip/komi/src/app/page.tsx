import Link from "next/link";
import { Sparkles } from "lucide-react";
import { db } from "@/lib/db";
import SearchBar from "@/components/SearchBar";
import CategoryGrid from "@/components/CategoryGrid";
import ProductCard from "@/components/ProductCard";
import ProfessionalCard from "@/components/ProfessionalCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [trendingProducts, topProfessionals, popularStores, recentProperties] = await Promise.all([
    db.product.findMany({
      where: { isActive: true },
      include: { images: true, store: true },
      orderBy: { createdAt: "desc" },
      take: 8
    }),
    db.professionalProfile.findMany({
      include: { user: { select: { firstName: true, lastName: true } } },
      orderBy: { ratingAvg: "desc" },
      take: 6
    }),
    db.store.findMany({ orderBy: { createdAt: "desc" }, take: 6, include: { _count: { select: { products: true } } } }),
    db.property.findMany({ where: { status: "PUBLISHED" }, include: { images: true }, orderBy: { createdAt: "desc" }, take: 4 })
  ]);

  return (
    <div className="max-w-6xl mx-auto px-4">
      <section className="py-10 md:py-14 flex flex-col items-center text-center gap-6">
        <h1 className="font-display text-3xl md:text-5xl font-bold text-indigo max-w-2xl leading-tight">
          Tout commence ici.
        </h1>
        <p className="text-ink/60 max-w-lg">
          Produits, services, professionnels, entreprises et immobilier — une seule recherche pour tout Komi.
        </p>
        <SearchBar />
        <Link href="/komi-ai" className="flex items-center gap-1.5 text-sm text-amber-dark font-medium">
          <Sparkles size={15} /> Ou demande à Komi AI en langage naturel
        </Link>
      </section>

      <section className="pb-8">
        <CategoryGrid />
      </section>

      <Section title="🔥 Tendances" href="/search?type=product">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {trendingProducts.map((p) => (
            <ProductCard
              key={p.id}
              id={p.id}
              slug={p.slug}
              name={p.name}
              price={p.price}
              promoPrice={p.promoPrice}
              imageUrl={p.images[0]?.url}
              storeName={p.store.name}
            />
          ))}
          {trendingProducts.length === 0 && <EmptyHint text="Pas encore de produits publiés — sois le premier vendeur !" />}
        </div>
      </Section>

      <Section title="⭐ Professionnels recommandés" href="/search?type=professional">
        <div className="grid md:grid-cols-2 gap-4">
          {topProfessionals.map((p) => (
            <ProfessionalCard
              key={p.id}
              id={p.id}
              jobTitle={p.jobTitle}
              firstName={p.user.firstName}
              lastName={p.user.lastName}
              city={p.city}
              quartier={p.quartier}
              ratingAvg={p.ratingAvg}
              ratingCount={p.ratingCount}
              verified={p.verification === "VERIFIED"}
            />
          ))}
          {topProfessionals.length === 0 && <EmptyHint text="Aucun professionnel inscrit pour le moment." />}
        </div>
      </Section>

      <Section title="🛍️ Boutiques populaires" href="/search?type=store">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {popularStores.map((s) => (
            <Link key={s.id} href={`/store/${s.slug}`} className="komi-card p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber/20 flex items-center justify-center font-display font-bold text-amber-dark">
                {s.name[0]}
              </div>
              <div>
                <p className="font-medium text-ink">{s.name}</p>
                <p className="text-xs text-ink/50">{s._count.products} produits · {s.city ?? "—"}</p>
              </div>
            </Link>
          ))}
          {popularStores.length === 0 && <EmptyHint text="Aucune boutique pour le moment." />}
        </div>
      </Section>

      <Section title="🏠 Annonces immobilières" href="/search?type=property">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {recentProperties.map((prop) => (
            <Link key={prop.id} href={`/property/${prop.id}`} className="komi-card overflow-hidden block">
              <div className="aspect-video bg-line/40 relative">
                {prop.images[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={prop.images[0].url} alt={prop.title} className="w-full h-full object-cover" />
                )}
              </div>
              <div className="p-3">
                <p className="text-sm font-medium line-clamp-1">{prop.title}</p>
                <p className="text-xs text-ink/50">{prop.city}{prop.quartier ? `, ${prop.quartier}` : ""}</p>
                <p className="font-display font-semibold text-indigo mt-1">
                  {prop.price.toLocaleString("fr-FR")} FCFA {prop.transactionType === "RENT" ? "/mois" : ""}
                </p>
              </div>
            </Link>
          ))}
          {recentProperties.length === 0 && <EmptyHint text="Aucune annonce immobilière pour le moment." />}
        </div>
      </Section>
    </div>
  );
}

function Section({ title, href, children }: { title: string; href: string; children: React.ReactNode }) {
  return (
    <section className="py-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-xl font-semibold text-indigo">{title}</h2>
        <Link href={href} className="text-sm text-teal font-medium hover:underline">
          Voir tout
        </Link>
      </div>
      {children}
    </section>
  );
}

function EmptyHint({ text }: { text: string }) {
  return <p className="text-sm text-ink/40 col-span-full py-6 text-center">{text}</p>;
}
