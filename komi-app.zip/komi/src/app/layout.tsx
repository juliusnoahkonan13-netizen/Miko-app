import type { Metadata } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/components/AuthProvider";
import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import EmailVerifyBanner from "@/components/EmailVerifyBanner";

const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display", weight: ["500", "600", "700"] });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "Komi — Tout commence ici.",
  description:
    "Komi est la super-marketplace ivoirienne qui réunit produits, services, professionnels, entreprises et immobilier. Tout commence ici."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className={`${display.variable} ${body.variable} font-body bg-ivoire text-ink min-h-screen`}>
        <AuthProvider>
          <Navbar />
          <EmailVerifyBanner />
          <main className="pb-20 md:pb-8">{children}</main>
          <BottomNav />
        </AuthProvider>
      </body>
    </html>
  );
}
