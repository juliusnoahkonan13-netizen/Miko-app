"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import ImageUploader from "@/components/ImageUploader";

export default function NewVehiclePage() {
  const router = useRouter();
  const [images, setImages] = useState<string[]>([]);
  const [form, setForm] = useState({
    type: "CAR",
    brand: "",
    model: "",
    year: new Date().getFullYear().toString(),
    mileageKm: "",
    price: "",
    condition: "USED",
    city: "",
    quartier: "",
    description: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (images.length === 0) return setError("Ajoute au moins une photo.");
    if (!form.brand || !form.model || !form.price || !form.city) return setError("Marque, modèle, prix et ville sont requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/vehicles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          year: Number(form.year),
          mileageKm: form.mileageKm ? Number(form.mileageKm) : undefined,
          price: Number(form.price),
          images
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push(`/vehicle/${data.vehicle.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Publier un véhicule</h1>

      <ImageUploader urls={images} onChange={setImages} />

      <div className="grid grid-cols-2 gap-3">
        <select className="komi-input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
          <option value="CAR">Voiture</option>
          <option value="MOTORCYCLE">Moto</option>
          <option value="UTILITY">Utilitaire</option>
          <option value="OTHER">Autre</option>
        </select>
        <select className="komi-input" value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value })}>
          <option value="USED">Occasion</option>
          <option value="NEW">Neuf</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Marque" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
        <input className="komi-input" placeholder="Modèle" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <input type="number" className="komi-input" placeholder="Année" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} />
        <input type="number" className="komi-input" placeholder="Kilométrage" value={form.mileageKm} onChange={(e) => setForm({ ...form, mileageKm: e.target.value })} />
      </div>

      <input type="number" className="komi-input" placeholder="Prix (FCFA)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />

      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="komi-input" placeholder="Quartier" value={form.quartier} onChange={(e) => setForm({ ...form, quartier: e.target.value })} />
      </div>

      <textarea className="komi-input" rows={3} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Publication..." : "Publier le véhicule"}
      </button>
    </div>
  );
}
