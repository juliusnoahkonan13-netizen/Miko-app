"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Users, Store, Wrench, Package, ShoppingBag, Flag, ShieldCheck, Wallet } from "lucide-react";

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [forbidden, setForbidden] = useState(false);

  useEffect(() => {
    fetch("/api/admin/stats", { cache: "no-store" }).then(async (res) => {
      if (res.status === 403 || res.status === 401) return setForbidden(true);
      setStats(await res.json());
    });
  }, []);

  if (forbidden) {
    return <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">Accès réservé aux administrateurs Komi.</div>;
  }

  if (!stats) return <div className="max-w-5xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="font-display text-2xl font-bold text-indigo">Komi Admin</h1>
        <div className="flex gap-2">
          <Link href="/admin/users" className="komi-btn-secondary text-sm">Utilisateurs</Link>
          <Link href="/admin/reports" className="komi-btn-secondary text-sm">Signalements ({stats.pendingReports})</Link>
          <Link href="/admin/verify" className="komi-btn-amber text-sm">Vérifications ({stats.pendingVerifications})</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Users} label="Utilisateurs" value={stats.userCount} />
        <StatCard icon={Store} label="Boutiques" value={stats.storeCount} />
        <StatCard icon={Wrench} label="Professionnels" value={stats.professionalCount} />
        <StatCard icon={Package} label="Produits" value={stats.productCount} />
        <StatCard icon={ShoppingBag} label="Commandes" value={stats.orderCount} />
        <StatCard icon={Wallet} label="Revenu total (livré)" value={`${stats.totalRevenue.toLocaleString("fr-FR")} FCFA`} />
        <StatCard icon={Flag} label="Signalements en attente" value={stats.pendingReports} accent={stats.pendingReports > 0} />
        <StatCard icon={ShieldCheck} label="Vérifications en attente" value={stats.pendingVerifications} accent={stats.pendingVerifications > 0} />
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, accent }: { icon: any; label: string; value: any; accent?: boolean }) {
  return (
    <div className={`komi-card p-4 ${accent ? "border-amber" : ""}`}>
      <Icon size={18} className="text-indigo mb-2" />
      <p className="text-xl font-display font-bold text-indigo">{value}</p>
      <p className="text-xs text-ink/50">{label}</p>
    </div>
  );
}
