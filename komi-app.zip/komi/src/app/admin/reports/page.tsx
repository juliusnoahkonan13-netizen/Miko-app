"use client";

import { useEffect, useState } from "react";
import { Flag } from "lucide-react";

const TARGET_LABEL: Record<string, string> = {
  PRODUCT: "Produit",
  STORE: "Boutique",
  PROFESSIONAL: "Professionnel",
  BUSINESS: "Entreprise",
  PROPERTY: "Annonce immobilière",
  VEHICLE: "Véhicule",
  SERVICE: "Service",
  USER: "Utilisateur",
  MESSAGE: "Message",
  REVIEW: "Avis"
};

export default function AdminReportsPage() {
  const [reports, setReports] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/reports", { cache: "no-store" });
    if (res.ok) setReports((await res.json()).reports);
  }

  useEffect(() => {
    load();
  }, []);

  async function resolve(id: string, status: string, removeContent: boolean) {
    await fetch(`/api/admin/reports/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, removeContent })
    });
    load();
  }

  if (reports === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo flex items-center gap-2"><Flag size={22} /> Signalements</h1>

      {reports.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucun signalement en attente.</p>}

      {reports.map((r) => (
        <div key={r.id} className="komi-card p-4">
          <p className="text-xs text-ink/40 mb-1">{TARGET_LABEL[r.targetType]} · signalé par {r.reporter.firstName} {r.reporter.lastName}</p>
          <p className="font-medium text-sm">{r.reason}</p>
          {r.details && <p className="text-sm text-ink/60 mt-1">{r.details}</p>}
          <div className="flex gap-2 mt-3">
            <button onClick={() => resolve(r.id, "ACTION_TAKEN", true)} className="komi-btn-primary text-sm">Retirer le contenu</button>
            <button onClick={() => resolve(r.id, "DISMISSED", false)} className="komi-btn-secondary text-sm">Rejeter le signalement</button>
          </div>
        </div>
      ))}
    </div>
  );
}
