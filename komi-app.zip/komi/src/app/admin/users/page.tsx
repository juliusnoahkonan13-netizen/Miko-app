"use client";

import { useEffect, useState } from "react";
import { Search, Ban, CheckCircle } from "lucide-react";

export default function AdminUsersPage() {
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<any[]>([]);

  async function load(query = "") {
    const res = await fetch(`/api/admin/users?q=${encodeURIComponent(query)}`, { cache: "no-store" });
    if (res.ok) setUsers((await res.json()).users);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleSuspend(id: string, isSuspended: boolean) {
    await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isSuspended: !isSuspended })
    });
    load(q);
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Utilisateurs</h1>

      <div className="flex gap-2">
        <div className="flex items-center gap-2 komi-input flex-1">
          <Search size={16} className="text-ink/40" />
          <input className="flex-1 outline-none bg-transparent" placeholder="Chercher un email ou un nom..." value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load(q)} />
        </div>
        <button onClick={() => load(q)} className="komi-btn-secondary">Chercher</button>
      </div>

      <div className="space-y-2">
        {users.map((u) => (
          <div key={u.id} className="komi-card p-3 flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">{u.firstName} {u.lastName} {u.isSuspended && <span className="text-red-600 text-xs font-semibold ml-1">SUSPENDU</span>}</p>
              <p className="text-xs text-ink/50">{u.email} · {u.roles.join(", ")}</p>
            </div>
            <button
              onClick={() => toggleSuspend(u.id, u.isSuspended)}
              className={`flex items-center gap-1 text-sm font-medium ${u.isSuspended ? "text-teal" : "text-red-600"}`}
            >
              {u.isSuspended ? <><CheckCircle size={16} /> Réactiver</> : <><Ban size={16} /> Suspendre</>}
            </button>
          </div>
        ))}
        {users.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucun utilisateur trouvé.</p>}
      </div>
    </div>
  );
}
