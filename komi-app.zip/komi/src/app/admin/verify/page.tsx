"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, ShieldX } from "lucide-react";

export default function AdminVerifyPage() {
  const [data, setData] = useState<{ professionals: any[]; businesses: any[]; stores: any[] } | null>(null);

  async function load() {
    const res = await fetch("/api/admin/verify/pending", { cache: "no-store" });
    if (res.ok) setData(await res.json());
  }

  useEffect(() => {
    load();
  }, []);

  async function setStatus(id: string, targetType: "PROFESSIONAL" | "BUSINESS" | "STORE", status: "VERIFIED" | "REJECTED") {
    await fetch(`/api/admin/verify/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetType, status })
    });
    load();
  }

  if (!data) return <div className="max-w-3xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  const sections = [
    { key: "professionals" as const, label: "Professionnels", targetType: "PROFESSIONAL" as const, render: (p: any) => `${p.jobTitle} — ${p.user.firstName} ${p.user.lastName}` },
    { key: "businesses" as const, label: "Entreprises", targetType: "BUSINESS" as const, render: (b: any) => b.companyName },
    { key: "stores" as const, label: "Boutiques", targetType: "STORE" as const, render: (s: any) => s.name }
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-8">
      <h1 className="font-display text-2xl font-bold text-indigo">Vérifications en attente</h1>

      {sections.map((section) => (
        <div key={section.key}>
          <h2 className="font-display font-semibold text-indigo mb-3">{section.label} ({data[section.key].length})</h2>
          <div className="space-y-2">
            {data[section.key].map((item: any) => (
              <div key={item.id} className="komi-card p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{section.render(item)}</p>
                  <p className="text-xs text-ink/40">{item.verification}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setStatus(item.id, section.targetType, "VERIFIED")} className="text-teal flex items-center gap-1 text-sm font-medium">
                    <ShieldCheck size={16} /> Vérifier
                  </button>
                  <button onClick={() => setStatus(item.id, section.targetType, "REJECTED")} className="text-red-600 flex items-center gap-1 text-sm font-medium">
                    <ShieldX size={16} /> Rejeter
                  </button>
                </div>
              </div>
            ))}
            {data[section.key].length === 0 && <p className="text-ink/40 text-sm">Rien en attente.</p>}
          </div>
        </div>
      ))}
    </div>
  );
}
