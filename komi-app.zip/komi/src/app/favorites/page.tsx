"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Heart, X } from "lucide-react";

const TARGET_LINK: Record<string, (id: string) => string> = {
  PRODUCT: (id) => `/product/${id}`,
  PROFESSIONAL: (id) => `/professional/${id}`,
  PROPERTY: (id) => `/property/${id}`,
  VEHICLE: (id) => `/vehicle/${id}`,
  STORE: (id) => `/store/${id}`,
  BUSINESS: (id) => `/business/${id}`
};

const TARGET_LABEL: Record<string, string> = {
  PRODUCT: "Produit",
  PROFESSIONAL: "Professionnel",
  PROPERTY: "Immobilier",
  VEHICLE: "Véhicule",
  STORE: "Boutique",
  BUSINESS: "Entreprise"
};

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<any[] | null>(null);

  async function load() {
    const res = await fetch("/api/favorites", { cache: "no-store" });
    const data = await res.json();
    setFavorites(data.favorites);
  }

  useEffect(() => {
    load();
  }, []);

  async function remove(id: string) {
    await fetch(`/api/favorites/${id}`, { method: "DELETE" });
    setFavorites((prev) => prev?.filter((f) => f.id !== id) ?? null);
  }

  if (favorites === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  if (favorites.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">
        <Heart className="mx-auto mb-3" size={40} />
        <p>Tu n'as pas encore de favoris.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="font-display text-2xl font-bold text-indigo mb-4">❤️ Mes favoris</h1>
      <div className="space-y-2">
        {favorites.map((f) => (
          <div key={f.id} className="komi-card p-3 flex items-center gap-3">
            <Link href={TARGET_LINK[f.targetType]?.(f.targetId) ?? "#"} className="flex-1 flex items-center gap-3 min-w-0">
              {f.imageUrl && (
                <div className="w-12 h-12 rounded-komi overflow-hidden bg-line/40 shrink-0">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={f.imageUrl} alt="" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="min-w-0">
                <span className="text-xs text-ink/40">{TARGET_LABEL[f.targetType]}</span>
                <p className="text-sm font-medium truncate">{f.label}</p>
                {f.price != null && <p className="text-xs text-indigo font-semibold">{f.price.toLocaleString("fr-FR")} FCFA</p>}
              </div>
            </Link>
            <button onClick={() => remove(f.id)} className="text-ink/30 hover:text-red-500 shrink-0">
              <X size={18} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
