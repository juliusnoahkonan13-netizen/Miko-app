"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { MessageCircle } from "lucide-react";

export default function MessagesPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [conversations, setConversations] = useState<any[] | null>(null);

  useEffect(() => {
    fetch("/api/conversations", { cache: "no-store" })
      .then((res) => {
        if (res.status === 401) return router.push("/login");
        return res.json();
      })
      .then((data) => data && setConversations(data.conversations));
  }, []);

  if (conversations === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  if (conversations.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">
        <MessageCircle className="mx-auto mb-3" size={40} />
        <p>Pas encore de conversation. Contacte un vendeur ou un professionnel pour commencer.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="font-display text-2xl font-bold text-indigo mb-4">Messages</h1>
      <div className="space-y-2">
        {conversations.map((conv) => {
          const other = conv.participants.find((p: any) => p.user.id !== user?.id)?.user;
          const lastMessage = conv.messages[0];
          return (
            <Link key={conv.id} href={`/messages/${conv.id}`} className="komi-card p-3 flex items-center gap-3 block">
              <div className="w-11 h-11 rounded-full bg-indigo/10 flex items-center justify-center font-display font-semibold text-indigo shrink-0">
                {other?.firstName?.[0] ?? "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{other?.firstName} {other?.lastName}</p>
                <p className="text-xs text-ink/50 truncate">{lastMessage?.body ?? "Nouvelle conversation"}</p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
