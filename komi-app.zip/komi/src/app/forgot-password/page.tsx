"use client";

import { useState, FormEvent } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email })
    });
    setLoading(false);
    setSent(true);
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-12">
      <h1 className="font-display text-2xl font-bold text-indigo mb-1">Mot de passe oublié</h1>
      <p className="text-ink/60 text-sm mb-6">On t'enverra un lien de réinitialisation par email.</p>

      {sent ? (
        <p className="komi-card p-4 text-sm text-teal">
          Si un compte existe avec cet email, un lien de réinitialisation vient d'être envoyé.
        </p>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4">
          <input
            type="email"
            className="komi-input"
            placeholder="ton@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button type="submit" disabled={loading} className="komi-btn-primary w-full">
            {loading ? "Envoi..." : "Envoyer le lien"}
          </button>
        </form>
      )}
    </div>
  );
}
