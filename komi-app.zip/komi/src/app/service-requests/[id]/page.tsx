"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";

export default function ServiceRequestDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [request, setRequest] = useState<any>(null);
  const [offerForm, setOfferForm] = useState({ price: "", message: "", estimatedDuration: "" });
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);

  async function load() {
    const res = await fetch(`/api/service-requests/${id}`);
    const data = await res.json();
    setRequest(data.request);
  }

  useEffect(() => {
    load();
  }, [id]);

  async function sendOffer() {
    if (!offerForm.message) return setError("Écris un message pour ta proposition.");
    setSending(true);
    setError(null);
    try {
      const res = await fetch(`/api/service-requests/${id}/offers`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: offerForm.message,
          price: offerForm.price ? Number(offerForm.price) : undefined,
          estimatedDuration: offerForm.estimatedDuration || undefined
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      setOfferForm({ price: "", message: "", estimatedDuration: "" });
      load();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  if (!request) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  const isOwner = user?.id === request.client.id;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <div className="komi-card p-4">
        <h1 className="font-display text-xl font-bold text-indigo">{request.title}</h1>
        <p className="text-sm text-ink/60 mt-2">{request.description}</p>
        <p className="text-xs text-ink/40 mt-2">{request.city}{request.quartier ? `, ${request.quartier}` : ""} · publié par {request.client.firstName}</p>
      </div>

      <div>
        <h2 className="font-display font-semibold text-indigo mb-2">Réponses ({request.offers.length})</h2>
        <div className="space-y-2">
          {request.offers.map((o: any) => (
            <div key={o.id} className="komi-card p-3">
              <p className="font-medium text-sm">{o.professional.jobTitle} — {o.professional.user.firstName} {o.professional.user.lastName}</p>
              <p className="text-sm text-ink/60 mt-1">{o.message}</p>
              <div className="flex gap-3 mt-1 text-xs text-ink/50">
                {o.price && <span>{o.price.toLocaleString("fr-FR")} FCFA</span>}
                {o.estimatedDuration && <span>{o.estimatedDuration}</span>}
              </div>
            </div>
          ))}
          {request.offers.length === 0 && <p className="text-ink/40 text-sm">Pas encore de réponse.</p>}
        </div>
      </div>

      {!isOwner && (
        <div className="komi-card p-4 space-y-2">
          <h2 className="font-display font-semibold text-indigo">Répondre à cette demande</h2>
          <p className="text-xs text-ink/40">Réservé aux professionnels inscrits sur Komi.</p>
          <textarea className="komi-input" rows={3} placeholder="Ton message" value={offerForm.message} onChange={(e) => setOfferForm({ ...offerForm, message: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <input type="number" className="komi-input" placeholder="Prix proposé" value={offerForm.price} onChange={(e) => setOfferForm({ ...offerForm, price: e.target.value })} />
            <input className="komi-input" placeholder="Durée estimée" value={offerForm.estimatedDuration} onChange={(e) => setOfferForm({ ...offerForm, estimatedDuration: e.target.value })} />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button onClick={sendOffer} disabled={sending} className="komi-btn-primary">
            {sending ? "Envoi..." : "Envoyer ma proposition"}
          </button>
        </div>
      )}
    </div>
  );
}
