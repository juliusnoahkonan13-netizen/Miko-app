"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { PlusCircle } from "lucide-react";

export default function ServiceRequestsPage() {
  const [requests, setRequests] = useState<any[] | null>(null);

  useEffect(() => {
    fetch("/api/service-requests")
      .then((res) => res.json())
      .then((data) => setRequests(data.requests ?? []));
  }, []);

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-indigo">Demandes de service</h1>
        <Link href="/service-requests/new" className="komi-btn-amber text-sm flex items-center gap-1">
          <PlusCircle size={16} /> Publier une demande
        </Link>
      </div>

      {requests === null && <p className="text-ink/50">Chargement...</p>}
      {requests?.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucune demande ouverte pour le moment.</p>}

      {requests?.map((r) => (
        <Link key={r.id} href={`/service-requests/${r.id}`} className="komi-card p-4 block">
          <p className="font-medium">{r.title}</p>
          <p className="text-sm text-ink/60 line-clamp-2 mt-1">{r.description}</p>
          <p className="text-xs text-ink/40 mt-2">{r.city} · {r.offers.length} réponse(s)</p>
        </Link>
      ))}
    </div>
  );
}
