"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewServiceRequestPage() {
  const router = useRouter();
  const [form, setForm] = useState({ title: "", description: "", city: "", quartier: "" });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!form.title || !form.description || !form.city) return setError("Titre, description et ville sont requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/service-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push(`/service-requests/${data.request.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Publier une demande de service</h1>
      <p className="text-sm text-ink/50">Ex : "Je cherche un électricien pour installer 5 prises dans une maison."</p>

      <input className="komi-input" placeholder="Titre" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <textarea className="komi-input" rows={4} placeholder="Décris ton besoin en détail" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="komi-input" placeholder="Quartier" value={form.quartier} onChange={(e) => setForm({ ...form, quartier: e.target.value })} />
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Publication..." : "Publier ma demande"}
      </button>
    </div>
  );
}
