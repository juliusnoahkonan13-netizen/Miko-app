"use client";

import { useEffect, useState } from "react";
import ReviewForm from "@/components/ReviewForm";

const STATUS_LABEL: Record<string, string> = {
  PENDING: "En attente de confirmation",
  CONFIRMED: "Confirmé",
  CANCELLED: "Annulé",
  COMPLETED: "Terminé"
};

export default function ClientAppointmentsPage() {
  const [appointments, setAppointments] = useState<any[] | null>(null);

  useEffect(() => {
    fetch("/api/appointments", { cache: "no-store" })
      .then((res) => res.json())
      .then((data) => setAppointments(data.appointments ?? []));
  }, []);

  if (appointments === null) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-3">
      <h1 className="font-display text-2xl font-bold text-indigo mb-2">Mes rendez-vous</h1>
      {appointments.length === 0 && <p className="text-ink/40 text-sm py-10 text-center">Aucun rendez-vous réservé.</p>}
      {appointments.map((a) => (
        <div key={a.id} className="komi-card p-4">
          <p className="font-medium text-sm">{a.professional.jobTitle} — {a.professional.user.firstName} {a.professional.user.lastName}</p>
          <p className="text-xs text-ink/50">{new Date(a.startTime).toLocaleString("fr-FR")}</p>
          <p className="text-xs font-semibold text-indigo mt-1">{STATUS_LABEL[a.status]}</p>
          {a.status === "COMPLETED" && (
            <div className="mt-2">
              <ReviewForm targetType="PROFESSIONAL" targetId={a.professionalId} label="Noter ce professionnel" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
