import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db";
import AddToCartButton from "@/components/AddToCartButton";
import ContactButton from "@/components/ContactButton";
import FavoriteButton from "@/components/FavoriteButton";
import ReportButton from "@/components/ReportButton";
import { Star } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await db.product.findFirst({
    where: { OR: [{ id: params.slug }, { slug: params.slug }] },
    include: { images: true, variants: true, store: true, promotions: true }
  });
  if (!product) notFound();

  const reviewStats = await db.review.aggregate({
    where: { targetType: "PRODUCT", targetId: product.id },
    _avg: { rating: true },
    _count: true
  });

  const hasPromo = product.promoPrice && product.promoPrice < product.price;

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 grid md:grid-cols-2 gap-8">
      <div>
        <div className="komi-card aspect-square overflow-hidden">
          {product.images[0] ? (
            <img src={product.images[0].url} alt={product.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-5xl">🛍️</div>
          )}
        </div>
        {product.images.length > 1 && (
          <div className="grid grid-cols-4 gap-2 mt-2">
            {product.images.slice(1, 5).map((img) => (
              <div key={img.id} className="aspect-square komi-card overflow-hidden">
                <img src={img.url} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <Link href={`/store/${product.store.slug}`} className="text-sm text-teal font-medium hover:underline">
          {product.store.name}
        </Link>
        <h1 className="font-display text-2xl font-bold text-indigo mt-1">{product.name}</h1>

        <div className="flex items-center gap-2 mt-2 text-sm text-ink/60">
          <Star size={14} className="fill-amber text-amber" />
          {reviewStats._avg.rating?.toFixed(1) ?? "—"} ({reviewStats._count} avis)
        </div>

        <div className="flex items-baseline gap-3 mt-4">
          <span className="font-display text-3xl font-bold text-indigo">
            {(hasPromo ? product.promoPrice! : product.price).toLocaleString("fr-FR")} FCFA
          </span>
          {hasPromo && (
            <span className="text-ink/40 line-through text-lg">{product.price.toLocaleString("fr-FR")} FCFA</span>
          )}
        </div>

        <p className="text-ink/70 mt-4 whitespace-pre-line">{product.description}</p>

        {product.variants.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {product.variants.map((v) => (
              <span key={v.id} className="text-xs px-2 py-1 rounded-full border border-line text-ink/70">
                {[v.size, v.color].filter(Boolean).join(" · ") || "Standard"}
              </span>
            ))}
          </div>
        )}

        <p className="text-sm mt-4">
          {product.stock > 0 ? (
            <span className="text-teal font-medium">{product.stock} en stock</span>
          ) : (
            <span className="text-red-500 font-medium">Rupture de stock</span>
          )}
        </p>

        <div className="flex items-center gap-2 mt-6">
          <AddToCartButton productId={product.id} disabled={product.stock === 0} />
          <ContactButton recipientId={product.store.ownerId} label="Contacter le vendeur" />
          <FavoriteButton targetType="PRODUCT" targetId={product.id} />
        </div>
        <div className="mt-3">
          <ReportButton targetType="PRODUCT" targetId={product.id} />
        </div>
      </div>
    </div>
  );
}
