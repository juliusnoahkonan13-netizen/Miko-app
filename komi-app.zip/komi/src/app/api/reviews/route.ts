import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";
import { TargetType } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const targetType = req.nextUrl.searchParams.get("targetType") as TargetType | null;
    const targetId = req.nextUrl.searchParams.get("targetId");
    if (!targetType || !targetId) {
      return NextResponse.json({ error: "targetType et targetId requis." }, { status: 400 });
    }
    const reviews = await db.review.findMany({
      where: { targetType, targetId },
      include: { author: { select: { firstName: true, lastName: true, avatarUrl: true } } },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ reviews });
  });
}

const schema = z.object({
  targetType: z.nativeEnum(TargetType),
  targetId: z.string(),
  orderId: z.string().optional(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(2000).optional()
});

/** Verifies the reviewer actually transacted with the target before allowing a review. */
async function canReview(userId: string, body: z.infer<typeof schema>): Promise<string | null> {
  if (body.targetType === "PRODUCT") {
    if (!body.orderId) return "Précise la commande liée à cet avis.";
    const order = await db.order.findFirst({
      where: {
        id: body.orderId,
        buyerId: userId,
        status: "DELIVERED",
        items: { some: { productId: body.targetId } }
      }
    });
    if (!order) return "Tu ne peux noter que des produits d'une commande livrée.";
    return null;
  }

  if (body.targetType === "PROFESSIONAL") {
    const completed = await db.appointment.findFirst({
      where: { professionalId: body.targetId, clientId: userId, status: "COMPLETED" }
    });
    const acceptedQuote = await db.quote.findFirst({
      where: { professionalId: body.targetId, clientId: userId, status: "ACCEPTED" }
    });
    if (!completed && !acceptedQuote) {
      return "Tu ne peux noter qu'un professionnel avec qui tu as eu une prestation terminée ou un devis accepté.";
    }
    return null;
  }

  if (body.targetType === "STORE") {
    const order = await db.order.findFirst({
      where: { storeId: body.targetId, buyerId: userId, status: "DELIVERED" }
    });
    if (!order) return "Tu ne peux noter qu'une boutique après une commande livrée.";
    return null;
  }

  return null; // other target types: no verification wired yet
}

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());

    const denyReason = await canReview(user.id, body);
    if (denyReason) return NextResponse.json({ error: denyReason }, { status: 403 });

    const review = await db.review.create({
      data: {
        authorId: user.id,
        targetType: body.targetType,
        targetId: body.targetId,
        orderId: body.orderId,
        rating: body.rating,
        comment: body.comment
      }
    });

    if (body.targetType === "PROFESSIONAL") {
      const agg = await db.review.aggregate({
        where: { targetType: "PROFESSIONAL", targetId: body.targetId },
        _avg: { rating: true },
        _count: true
      });
      const professional = await db.professionalProfile.update({
        where: { id: body.targetId },
        data: { ratingAvg: agg._avg.rating ?? 0, ratingCount: agg._count }
      });
      await notify(
        professional.userId,
        "NEW_REVIEW",
        "Nouvel avis reçu",
        `${user.firstName} ${user.lastName} t'a laissé ${body.rating}/5.`,
        `/professional/${professional.id}`
      );
    }

    return NextResponse.json({ review }, { status: 201 });
  });
}
