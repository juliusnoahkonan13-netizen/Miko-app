import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireVerifiedUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { PropertyType, TransactionType } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const sp = req.nextUrl.searchParams;
    const city = sp.get("city") ?? undefined;
    const quartier = sp.get("quartier") ?? undefined;
    const type = sp.get("type") as PropertyType | null;
    const transactionType = sp.get("transactionType") as TransactionType | null;
    const minPrice = sp.get("minPrice") ? Number(sp.get("minPrice")) : undefined;
    const maxPrice = sp.get("maxPrice") ? Number(sp.get("maxPrice")) : undefined;
    const bedrooms = sp.get("bedrooms") ? Number(sp.get("bedrooms")) : undefined;

    const properties = await db.property.findMany({
      where: {
        status: "PUBLISHED",
        city: city || undefined,
        quartier: quartier || undefined,
        type: type || undefined,
        transactionType: transactionType || undefined,
        bedrooms: bedrooms ? { gte: bedrooms } : undefined,
        price: minPrice || maxPrice ? { gte: minPrice, lte: maxPrice } : undefined
      },
      include: { images: true, owner: { select: { firstName: true, lastName: true, phone: true } } },
      orderBy: { createdAt: "desc" },
      take: 40
    });

    return NextResponse.json({ properties });
  });
}

const schema = z.object({
  type: z.nativeEnum(PropertyType),
  transactionType: z.nativeEnum(TransactionType),
  title: z.string().min(3),
  description: z.string().min(10),
  price: z.number().int().positive(),
  city: z.string().min(1),
  quartier: z.string().optional(),
  surfaceM2: z.number().int().positive().optional(),
  bedrooms: z.number().int().min(0).optional(),
  bathrooms: z.number().int().min(0).optional(),
  amenities: z.array(z.string()).default([]),
  images: z.array(z.string().url()).min(1, "Ajoute au moins une photo.")
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const body = schema.parse(await req.json());

    const property = await db.property.create({
      data: {
        ownerId: user.id,
        type: body.type,
        transactionType: body.transactionType,
        title: body.title,
        description: body.description,
        price: body.price,
        city: body.city,
        quartier: body.quartier,
        surfaceM2: body.surfaceM2,
        bedrooms: body.bedrooms,
        bathrooms: body.bathrooms,
        amenities: body.amenities,
        images: { create: body.images.map((url, position) => ({ url, position })) }
      },
      include: { images: true }
    });

    return NextResponse.json({ property }, { status: 201 });
  });
}
