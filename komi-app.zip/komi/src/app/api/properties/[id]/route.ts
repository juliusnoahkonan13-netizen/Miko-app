import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const property = await db.property.findUnique({
      where: { id: params.id },
      include: { images: true, owner: { select: { firstName: true, lastName: true, phone: true } } }
    });
    if (!property) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });
    return NextResponse.json({ property });
  });
}

const schema = z.object({
  title: z.string().optional(),
  description: z.string().optional(),
  price: z.number().int().positive().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "SOLD", "RENTED", "ARCHIVED"]).optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const property = await db.property.findUnique({ where: { id: params.id } });
    if (!property || property.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const body = schema.parse(await req.json());
    const updated = await db.property.update({ where: { id: params.id }, data: body });
    return NextResponse.json({ property: updated });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const property = await db.property.findUnique({ where: { id: params.id } });
    if (!property || property.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    await db.property.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
