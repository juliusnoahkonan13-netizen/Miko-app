import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute, generateQuoteNumber } from "@/lib/api";
import { notify } from "@/lib/notify";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const as = req.nextUrl.searchParams.get("as");

    if (as === "professional") {
      const professional = await db.professionalProfile.findUnique({ where: { userId: user.id } });
      if (!professional) return NextResponse.json({ quotes: [] });
      const quotes = await db.quote.findMany({
        where: { professionalId: professional.id },
        include: { lines: true, client: { select: { firstName: true, lastName: true } } },
        orderBy: { createdAt: "desc" }
      });
      return NextResponse.json({ quotes });
    }

    const quotes = await db.quote.findMany({
      where: { clientId: user.id },
      include: { lines: true, professional: { include: { user: true } } },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ quotes });
  });
}

const schema = z.object({
  clientId: z.string(),
  conditions: z.string().optional(),
  lines: z
    .array(z.object({ label: z.string().min(1), quantity: z.number().int().positive(), unitPrice: z.number().int().positive() }))
    .min(1)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const professional = await db.professionalProfile.findUnique({ where: { userId: user.id } });
    if (!professional) return NextResponse.json({ error: "Réservé aux professionnels." }, { status: 403 });

    const body = schema.parse(await req.json());
    const total = body.lines.reduce((sum, l) => sum + l.quantity * l.unitPrice, 0);

    const quote = await db.quote.create({
      data: {
        number: generateQuoteNumber(),
        professionalId: professional.id,
        clientId: body.clientId,
        conditions: body.conditions,
        total,
        lines: { create: body.lines }
      },
      include: { lines: true }
    });

    await notify(
      body.clientId,
      "NEW_QUOTE",
      "Nouveau devis reçu",
      `${professional.jobTitle} t'a envoyé le devis ${quote.number} (${total} FCFA).`,
      `/quotes/${quote.id}`
    );

    return NextResponse.json({ quote }, { status: 201 });
  });
}
