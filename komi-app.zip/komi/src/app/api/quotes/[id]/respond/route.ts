import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";

const schema = z.object({ decision: z.enum(["ACCEPTED", "REFUSED"]) });

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const quote = await db.quote.findUnique({ where: { id: params.id }, include: { professional: true } });
    if (!quote || quote.clientId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }

    const { decision } = schema.parse(await req.json());
    const updated = await db.quote.update({
      where: { id: params.id },
      data: { status: decision, respondedAt: new Date() }
    });

    await notify(
      quote.professional.userId,
      decision === "ACCEPTED" ? "QUOTE_ACCEPTED" : "QUOTE_REFUSED",
      decision === "ACCEPTED" ? "Devis accepté" : "Devis refusé",
      `${user.firstName} ${user.lastName} a ${decision === "ACCEPTED" ? "accepté" : "refusé"} le devis ${quote.number}.`,
      `/dashboard/professional/quotes/${quote.id}`
    );

    return NextResponse.json({ quote: updated });
  });
}
