import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { handleRoute } from "@/lib/api";

/**
 * Komi AI — search engine.
 *
 * This is a real, working search over the actual database: it extracts a
 * price ceiling from natural phrases ("moins de 20000 FCFA"), then queries
 * products, professionals, properties, vehicles, services and stores in
 * parallel and returns ranked, grouped results.
 *
 * It does NOT call an external LLM, so it needs no API key to work today.
 * To upgrade it to true natural-language understanding, wire this endpoint
 * to the Anthropic API (see /docs/build-with-claude) to turn free text into
 * the structured filters below before running the same Prisma queries.
 */

function extractMaxPrice(query: string): number | undefined {
  const match = query.match(/(?:moins de|sous|max(?:imum)?)\s*(\d[\d\s]{2,})/i);
  if (!match) return undefined;
  return Number(match[1].replace(/\s/g, ""));
}

function stripPricePhrase(query: string): string {
  return query.replace(/(?:moins de|sous|max(?:imum)?)\s*\d[\d\s]*(?:\s*fcfa)?/gi, "").trim();
}

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const rawQuery = req.nextUrl.searchParams.get("q")?.trim() ?? "";
    const city = req.nextUrl.searchParams.get("city") ?? undefined;
    if (!rawQuery) return NextResponse.json({ error: "Écris ce que tu cherches." }, { status: 400 });

    const maxPrice = extractMaxPrice(rawQuery);
    const q = stripPricePhrase(rawQuery) || rawQuery;

    const [products, professionals, properties, vehicles, services, stores] = await Promise.all([
      db.product.findMany({
        where: {
          isActive: true,
          store: city ? { city } : undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } },
            { brand: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true, store: true },
        take: 12
      }),
      db.professionalProfile.findMany({
        where: {
          city: city || undefined,
          OR: [
            { jobTitle: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { user: { select: { firstName: true, lastName: true } } },
        orderBy: { ratingAvg: "desc" },
        take: 12
      }),
      db.property.findMany({
        where: {
          status: "PUBLISHED",
          city: city || undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { title: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true },
        take: 12
      }),
      db.vehicle.findMany({
        where: {
          status: "PUBLISHED",
          city: city || undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { brand: { contains: q, mode: "insensitive" } },
            { model: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true },
        take: 12
      }),
      db.service.findMany({
        where: {
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { professional: true, business: true },
        take: 12
      }),
      db.store.findMany({
        where: { name: { contains: q, mode: "insensitive" } },
        take: 8
      })
    ]);

    return NextResponse.json({
      query: rawQuery,
      interpreted: { text: q, maxPrice, city },
      results: { products, professionals, properties, vehicles, services, stores },
      totalResults:
        products.length + professionals.length + properties.length + vehicles.length + services.length + stores.length
    });
  });
}
