import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { TargetType } from "@prisma/client";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const favorites = await db.favorite.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" }
    });

    const byType = favorites.reduce<Record<string, string[]>>((acc, f) => {
      (acc[f.targetType] ??= []).push(f.targetId);
      return acc;
    }, {});

    const [products, professionals, properties, vehicles, stores, businesses] = await Promise.all([
      byType.PRODUCT ? db.product.findMany({ where: { id: { in: byType.PRODUCT } }, include: { images: true } }) : [],
      byType.PROFESSIONAL
        ? db.professionalProfile.findMany({ where: { id: { in: byType.PROFESSIONAL } }, include: { user: true } })
        : [],
      byType.PROPERTY ? db.property.findMany({ where: { id: { in: byType.PROPERTY } }, include: { images: true } }) : [],
      byType.VEHICLE ? db.vehicle.findMany({ where: { id: { in: byType.VEHICLE } }, include: { images: true } }) : [],
      byType.STORE ? db.store.findMany({ where: { id: { in: byType.STORE } } }) : [],
      byType.BUSINESS ? db.businessProfile.findMany({ where: { id: { in: byType.BUSINESS } } }) : []
    ]);

    function describe(f: (typeof favorites)[number]) {
      switch (f.targetType) {
        case "PRODUCT": {
          const p = products.find((x) => x.id === f.targetId);
          return { label: p?.name ?? "Produit supprimé", imageUrl: p?.images[0]?.url, price: p?.price };
        }
        case "PROFESSIONAL": {
          const p = professionals.find((x) => x.id === f.targetId);
          return { label: p ? `${p.jobTitle} — ${p.user.firstName} ${p.user.lastName}` : "Profil supprimé" };
        }
        case "PROPERTY": {
          const p = properties.find((x) => x.id === f.targetId);
          return { label: p?.title ?? "Annonce supprimée", imageUrl: p?.images[0]?.url, price: p?.price };
        }
        case "VEHICLE": {
          const v = vehicles.find((x) => x.id === f.targetId);
          return { label: v ? `${v.brand} ${v.model} (${v.year})` : "Annonce supprimée", imageUrl: v?.images[0]?.url, price: v?.price };
        }
        case "STORE": {
          const s = stores.find((x) => x.id === f.targetId);
          return { label: s?.name ?? "Boutique supprimée" };
        }
        case "BUSINESS": {
          const b = businesses.find((x) => x.id === f.targetId);
          return { label: b?.companyName ?? "Entreprise supprimée" };
        }
        default:
          return { label: f.targetId };
      }
    }

    return NextResponse.json({ favorites: favorites.map((f) => ({ ...f, ...describe(f) })) });
  });
}

const schema = z.object({ targetType: z.nativeEnum(TargetType), targetId: z.string() });

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());
    const favorite = await db.favorite.upsert({
      where: { userId_targetType_targetId: { userId: user.id, ...body } },
      create: { userId: user.id, ...body },
      update: {}
    });
    return NextResponse.json({ favorite }, { status: 201 });
  });
}
