import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const favorite = await db.favorite.findUnique({ where: { id: params.id } });
    if (!favorite || favorite.userId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    await db.favorite.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
