import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";

const schema = z.object({
  price: z.number().int().positive().optional(),
  message: z.string().min(1),
  estimatedDuration: z.string().optional()
});

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const professional = await db.professionalProfile.findUnique({ where: { userId: user.id } });
    if (!professional) {
      return NextResponse.json({ error: "Réservé aux professionnels." }, { status: 403 });
    }

    const request = await db.serviceRequest.findUnique({ where: { id: params.id } });
    if (!request) return NextResponse.json({ error: "Demande introuvable." }, { status: 404 });

    const body = schema.parse(await req.json());

    const [offer] = await db.$transaction([
      db.serviceOffer.create({
        data: { serviceRequestId: params.id, professionalId: professional.id, ...body }
      }),
      db.serviceRequest.update({ where: { id: params.id }, data: { status: "ANSWERED" } })
    ]);

    await notify(
      request.clientId,
      "SERVICE_REQUEST_RESPONSE",
      "Un professionnel a répondu",
      `${professional.jobTitle} a répondu à ta demande "${request.title}".`,
      `/services/requests/${request.id}`
    );

    return NextResponse.json({ offer }, { status: 201 });
  });
}
