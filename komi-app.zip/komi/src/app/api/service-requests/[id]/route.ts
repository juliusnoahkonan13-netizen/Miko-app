import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const request = await db.serviceRequest.findUnique({
      where: { id: params.id },
      include: {
        client: { select: { firstName: true, lastName: true } },
        offers: {
          include: { professional: { include: { user: { select: { firstName: true, lastName: true } } } } }
        }
      }
    });
    if (!request) return NextResponse.json({ error: "Demande introuvable." }, { status: 404 });
    return NextResponse.json({ request });
  });
}
