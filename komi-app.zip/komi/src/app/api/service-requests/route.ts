import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const city = req.nextUrl.searchParams.get("city") ?? undefined;
    const status = req.nextUrl.searchParams.get("status") ?? "OPEN";
    const requests = await db.serviceRequest.findMany({
      where: { city: city || undefined, status: status as any },
      include: { client: { select: { firstName: true, lastName: true } }, offers: true },
      orderBy: { createdAt: "desc" },
      take: 40
    });
    return NextResponse.json({ requests });
  });
}

const schema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  city: z.string().min(1),
  quartier: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());
    const request = await db.serviceRequest.create({ data: { ...body, clientId: user.id } });

    // Naive matching: notify verified professionals in the same city whose job
    // title appears in the request title/description. Good enough as a real
    // first pass; can be replaced by Komi AI ranking later.
    const candidates = await db.professionalProfile.findMany({
      where: { city: body.city },
      take: 20
    });
    const text = `${body.title} ${body.description}`.toLowerCase();
    const matches = candidates.filter((p) => text.includes(p.jobTitle.toLowerCase()));

    await Promise.all(
      matches.map((p) =>
        db.notification.create({
          data: {
            userId: p.userId,
            type: "SERVICE_REQUEST_RESPONSE",
            title: "Nouvelle demande de service",
            body: `Un client cherche : "${body.title}" à ${body.city}.`,
            linkUrl: `/services/requests/${request.id}`
          }
        })
      )
    );

    return NextResponse.json({ request }, { status: 201 });
  });
}
