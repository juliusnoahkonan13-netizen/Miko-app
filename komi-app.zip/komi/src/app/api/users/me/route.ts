import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  city: z.string().optional(),
  quartier: z.string().optional(),
  bio: z.string().max(500).optional(),
  avatarUrl: z.string().url().optional()
});

export async function PATCH(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());
    const updated = await db.user.update({ where: { id: user.id }, data: body });
    const { passwordHash, ...safeUser } = updated;
    return NextResponse.json({ user: safeUser });
  });
}
