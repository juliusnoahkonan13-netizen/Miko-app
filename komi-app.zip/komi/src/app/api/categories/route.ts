import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute, uniqueSlug } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET() {
  return handleRoute(async () => {
    const categories = await db.category.findMany({
      where: { parentId: null },
      include: { children: true },
      orderBy: { name: "asc" }
    });
    return NextResponse.json({ categories });
  });
}

const schema = z.object({
  name: z.string().min(1),
  icon: z.string().optional(),
  parentId: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    await requireRole(Role.ADMIN);
    const body = schema.parse(await req.json());
    const slug = await uniqueSlug(body.name, (s) => db.category.findUnique({ where: { slug: s } }));
    const category = await db.category.create({ data: { ...body, slug } });
    return NextResponse.json({ category }, { status: 201 });
  });
}
