import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { handleRoute } from "@/lib/api";

/**
 * Komi AI
 * --------
 * A real assistant, not a scripted demo: it parses the message for a known
 * city/commune, a price ceiling ("moins de 20 000 FCFA"), and a residual
 * search phrase, then queries the actual Komi database across every module
 * (products, professionals, real estate, vehicles, services, stores) and
 * writes a short French summary of what it found.
 *
 * It works with zero external dependencies today. To give it real natural-
 * language understanding (handling typos, synonyms, multi-intent messages),
 * swap the `parseIntent` function below for a call to the Anthropic API
 * (POST https://api.anthropic.com/v1/messages) asking it to return the same
 * { city, maxPrice, text } shape as structured JSON — see the docs at
 * docs.claude.com. Keep the Prisma queries unchanged; only the parsing step
 * needs to change.
 */

const KNOWN_CITIES = [
  "Yopougon",
  "Cocody",
  "Marcory",
  "Treichville",
  "Plateau",
  "Koumassi",
  "Abobo",
  "Adjamé",
  "Attécoubé",
  "Bingerville",
  "Songon",
  "Port-Bouët",
  "Bouaké",
  "San Pedro",
  "Yamoussoukro",
  "Daloa",
  "Korhogo",
  "Abidjan"
];

function detectCity(message: string): string | undefined {
  const lower = message.toLowerCase();
  return KNOWN_CITIES.find((c) => lower.includes(c.toLowerCase()));
}

function extractMaxPrice(message: string): number | undefined {
  const match = message.match(/(?:moins de|sous|max(?:imum)?|à\s*)\s*(\d[\d\s]{2,})/i);
  if (!match) return undefined;
  return Number(match[1].replace(/\s/g, ""));
}

function cleanText(message: string, city?: string): string {
  let text = message
    .replace(/(?:moins de|sous|max(?:imum)?)\s*\d[\d\s]*(?:\s*fcfa)?/gi, "")
    .replace(/\bfcfa\b/gi, "");
  if (city) text = text.replace(new RegExp(city, "gi"), "");
  return text
    .replace(/\b(je cherche|je veux|trouve[- ]moi|un|une|des|à|dans|de|du|la|le|les)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const schema = z.object({ message: z.string().min(2) });

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const { message } = schema.parse(await req.json());

    const city = detectCity(message);
    const maxPrice = extractMaxPrice(message);
    const q = cleanText(message, city) || message;

    const [products, professionals, properties, vehicles, services] = await Promise.all([
      db.product.findMany({
        where: {
          isActive: true,
          store: city ? { city } : undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } },
            { brand: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true, store: true },
        take: 6
      }),
      db.professionalProfile.findMany({
        where: {
          city: city || undefined,
          OR: [
            { jobTitle: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { user: { select: { firstName: true, lastName: true } } },
        orderBy: { ratingAvg: "desc" },
        take: 6
      }),
      db.property.findMany({
        where: {
          status: "PUBLISHED",
          city: city || undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { title: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true },
        take: 6
      }),
      db.vehicle.findMany({
        where: {
          status: "PUBLISHED",
          city: city || undefined,
          price: maxPrice ? { lte: maxPrice } : undefined,
          OR: [
            { brand: { contains: q, mode: "insensitive" } },
            { model: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { images: true },
        take: 6
      }),
      db.service.findMany({
        where: {
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { description: { contains: q, mode: "insensitive" } }
          ]
        },
        include: { professional: { include: { user: true } } },
        take: 6
      })
    ]);

    const total = products.length + professionals.length + properties.length + vehicles.length + services.length;

    const parts: string[] = [];
    if (products.length) parts.push(`${products.length} produit(s)`);
    if (professionals.length) parts.push(`${professionals.length} professionnel(s)`);
    if (properties.length) parts.push(`${properties.length} annonce(s) immobilière(s)`);
    if (vehicles.length) parts.push(`${vehicles.length} véhicule(s)`);
    if (services.length) parts.push(`${services.length} service(s)`);

    const reply =
      total === 0
        ? `Je n'ai rien trouvé pour "${message}"${city ? ` à ${city}` : ""}. Essaie avec d'autres mots.`
        : `Pour "${q || message}"${city ? ` à ${city}` : ""}${maxPrice ? ` à moins de ${maxPrice} FCFA` : ""}, j'ai trouvé ${parts.join(", ")}.`;

    return NextResponse.json({
      reply,
      interpreted: { city, maxPrice, text: q },
      results: { products, professionals, properties, vehicles, services }
    });
  });
}
