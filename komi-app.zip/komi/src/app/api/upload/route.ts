import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_BYTES = 8 * 1024 * 1024; // 8MB

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    await requireUser();

    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "Aucun fichier reçu." }, { status: 400 });
    }
    if (!ALLOWED.includes(file.type)) {
      return NextResponse.json({ error: "Format d'image non supporté." }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: "Image trop lourde (8 Mo max)." }, { status: 400 });
    }

    const bytes = Buffer.from(await file.arrayBuffer());
    const ext = file.type.split("/")[1];
    const filename = `${crypto.randomUUID()}.${ext}`;

    // NOTE: this writes to the local filesystem. That works for local dev and
    // for a self-hosted server with persistent disk. On serverless hosts
    // (Vercel, etc.) the filesystem is ephemeral — swap this block for a real
    // object storage provider (S3, Cloudinary, Supabase Storage) before
    // launching in production. Only this function needs to change; every
    // caller just expects a public URL back.
    const uploadDir = path.join(process.cwd(), "public", "uploads");
    await mkdir(uploadDir, { recursive: true });
    await writeFile(path.join(uploadDir, filename), bytes);

    return NextResponse.json({ url: `/uploads/${filename}` }, { status: 201 });
  });
}
