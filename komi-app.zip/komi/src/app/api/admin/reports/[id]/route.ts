import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role, ReportStatus } from "@prisma/client";

const schema = z.object({
  status: z.nativeEnum(ReportStatus),
  removeContent: z.boolean().default(false)
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const admin = await requireRole(Role.ADMIN);
    const report = await db.report.findUnique({ where: { id: params.id } });
    if (!report) return NextResponse.json({ error: "Signalement introuvable." }, { status: 404 });

    const body = schema.parse(await req.json());

    if (body.removeContent) {
      switch (report.targetType) {
        case "PRODUCT":
          await db.product.update({ where: { id: report.targetId }, data: { isActive: false } }).catch(() => null);
          break;
        case "PROPERTY":
          await db.property.update({ where: { id: report.targetId }, data: { status: "ARCHIVED" } }).catch(() => null);
          break;
        case "VEHICLE":
          await db.vehicle.update({ where: { id: report.targetId }, data: { status: "ARCHIVED" } }).catch(() => null);
          break;
        default:
          break; // other target types need a manual admin decision, not an automatic takedown
      }
    }

    const [updated] = await db.$transaction([
      db.report.update({ where: { id: params.id }, data: { status: body.status } }),
      db.adminAction.create({
        data: {
          adminId: admin.id,
          action: body.removeContent ? "REMOVE_CONTENT" : "REVIEW_REPORT",
          targetType: report.targetType,
          targetId: report.targetId,
          notes: `Report ${report.id} -> ${body.status}`
        }
      })
    ]);

    return NextResponse.json({ report: updated });
  });
}
