import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    await requireRole(Role.ADMIN);
    const q = req.nextUrl.searchParams.get("q") ?? undefined;

    const users = await db.user.findMany({
      where: q
        ? {
            OR: [
              { email: { contains: q, mode: "insensitive" } },
              { firstName: { contains: q, mode: "insensitive" } },
              { lastName: { contains: q, mode: "insensitive" } }
            ]
          }
        : undefined,
      select: {
        id: true,
        email: true,
        phone: true,
        firstName: true,
        lastName: true,
        roles: true,
        isSuspended: true,
        createdAt: true
      },
      orderBy: { createdAt: "desc" },
      take: 100
    });

    return NextResponse.json({ users });
  });
}
