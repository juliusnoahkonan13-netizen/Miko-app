import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role } from "@prisma/client";

const schema = z.object({ isSuspended: z.boolean(), notes: z.string().optional() });

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const admin = await requireRole(Role.ADMIN);
    const body = schema.parse(await req.json());

    const [user] = await db.$transaction([
      db.user.update({ where: { id: params.id }, data: { isSuspended: body.isSuspended } }),
      db.adminAction.create({
        data: {
          adminId: admin.id,
          action: body.isSuspended ? "SUSPEND_USER" : "UNSUSPEND_USER",
          targetType: "USER",
          targetId: params.id,
          notes: body.notes
        }
      }),
      db.session.deleteMany({ where: { userId: params.id } })
    ]);

    return NextResponse.json({ user });
  });
}
