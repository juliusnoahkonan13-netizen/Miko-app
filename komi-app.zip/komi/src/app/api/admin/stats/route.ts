import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET() {
  return handleRoute(async () => {
    await requireRole(Role.ADMIN);

    const [
      userCount,
      storeCount,
      professionalCount,
      productCount,
      orderCount,
      pendingReports,
      pendingVerifications,
      revenueAgg
    ] = await Promise.all([
      db.user.count(),
      db.store.count(),
      db.professionalProfile.count(),
      db.product.count(),
      db.order.count(),
      db.report.count({ where: { status: "PENDING" } }),
      db.professionalProfile.count({ where: { verification: "PENDING" } }),
      db.order.aggregate({ where: { status: "DELIVERED" }, _sum: { total: true } })
    ]);

    return NextResponse.json({
      userCount,
      storeCount,
      professionalCount,
      productCount,
      orderCount,
      pendingReports,
      pendingVerifications,
      totalRevenue: revenueAgg._sum.total ?? 0
    });
  });
}
