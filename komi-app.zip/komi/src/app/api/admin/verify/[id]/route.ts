import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";
import { Role, VerificationStatus } from "@prisma/client";

const schema = z.object({
  targetType: z.enum(["PROFESSIONAL", "BUSINESS", "STORE"]),
  status: z.nativeEnum(VerificationStatus)
});

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const admin = await requireRole(Role.ADMIN);
    const body = schema.parse(await req.json());

    let ownerId: string | null = null;

    if (body.targetType === "PROFESSIONAL") {
      const profile = await db.professionalProfile.update({
        where: { id: params.id },
        data: { verification: body.status }
      });
      ownerId = profile.userId;
    } else if (body.targetType === "BUSINESS") {
      const business = await db.businessProfile.update({
        where: { id: params.id },
        data: { verification: body.status }
      });
      ownerId = business.userId;
    } else {
      const store = await db.store.update({
        where: { id: params.id },
        data: { verification: body.status }
      });
      ownerId = store.ownerId;
    }

    await db.adminAction.create({
      data: {
        adminId: admin.id,
        action: `SET_VERIFICATION_${body.status}`,
        targetType: body.targetType,
        targetId: params.id
      }
    });

    if (ownerId) {
      await notify(
        ownerId,
        "VERIFICATION_UPDATE",
        "Statut de vérification mis à jour",
        `Ton profil est maintenant : ${body.status}.`
      );
    }

    return NextResponse.json({ ok: true, status: body.status });
  });
}
