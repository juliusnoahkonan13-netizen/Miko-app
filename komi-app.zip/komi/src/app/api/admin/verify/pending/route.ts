import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET() {
  return handleRoute(async () => {
    await requireRole(Role.ADMIN);

    const [professionals, businesses, stores] = await Promise.all([
      db.professionalProfile.findMany({
        where: { verification: { not: "VERIFIED" } },
        include: { user: { select: { firstName: true, lastName: true, email: true, phone: true } } },
        orderBy: { createdAt: "asc" }
      }),
      db.businessProfile.findMany({
        where: { verification: { not: "VERIFIED" } },
        include: { user: { select: { firstName: true, lastName: true, email: true } } },
        orderBy: { createdAt: "asc" }
      }),
      db.store.findMany({
        where: { verification: { not: "VERIFIED" } },
        include: { owner: { select: { firstName: true, lastName: true, email: true } } },
        orderBy: { createdAt: "asc" }
      })
    ]);

    return NextResponse.json({ professionals, businesses, stores });
  });
}
