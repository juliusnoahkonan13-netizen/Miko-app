import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const [availabilities, upcomingAppointments] = await Promise.all([
      db.availability.findMany({ where: { professionalId: params.id } }),
      db.appointment.findMany({
        where: { professionalId: params.id, startTime: { gte: new Date() }, status: { not: "CANCELLED" } },
        select: { startTime: true, endTime: true }
      })
    ]);
    return NextResponse.json({ availabilities, bookedSlots: upcomingAppointments });
  });
}

const schema = z.object({
  slots: z
    .array(z.object({ dayOfWeek: z.number().min(0).max(6), startTime: z.string(), endTime: z.string() }))
    .min(1)
});

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const profile = await db.professionalProfile.findUnique({ where: { id: params.id } });
    if (!profile || profile.userId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const { slots } = schema.parse(await req.json());

    await db.$transaction([
      db.availability.deleteMany({ where: { professionalId: params.id } }),
      db.availability.createMany({ data: slots.map((s) => ({ ...s, professionalId: params.id })) })
    ]);

    return NextResponse.json({ ok: true });
  });
}
