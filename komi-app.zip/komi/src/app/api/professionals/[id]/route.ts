import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const profile = await db.professionalProfile.findUnique({
      where: { id: params.id },
      include: {
        user: { select: { firstName: true, lastName: true, avatarUrl: true, phone: true } },
        services: true,
        portfolioImages: true,
        availabilities: true
      }
    });
    if (!profile) return NextResponse.json({ error: "Profil introuvable." }, { status: 404 });

    const reviews = await db.review.findMany({
      where: { targetType: "PROFESSIONAL", targetId: profile.id },
      orderBy: { createdAt: "desc" },
      take: 20,
      include: { author: { select: { firstName: true, lastName: true } } }
    });

    return NextResponse.json({ profile, reviews });
  });
}

const schema = z.object({
  jobTitle: z.string().min(2).optional(),
  description: z.string().optional(),
  experienceYears: z.number().int().min(0).optional(),
  zone: z.string().optional(),
  city: z.string().optional(),
  quartier: z.string().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const profile = await db.professionalProfile.findUnique({ where: { id: params.id } });
    if (!profile || profile.userId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const body = schema.parse(await req.json());
    const updated = await db.professionalProfile.update({ where: { id: params.id }, data: body });
    return NextResponse.json({ profile: updated });
  });
}
