import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireVerifiedUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const sp = req.nextUrl.searchParams;
    const q = sp.get("q") ?? undefined;
    const city = sp.get("city") ?? undefined;
    const verifiedOnly = sp.get("verified") === "true";

    const professionals = await db.professionalProfile.findMany({
      where: {
        city: city || undefined,
        verification: verifiedOnly ? "VERIFIED" : undefined,
        OR: q
          ? [
              { jobTitle: { contains: q, mode: "insensitive" } },
              { description: { contains: q, mode: "insensitive" } }
            ]
          : undefined
      },
      include: {
        user: { select: { firstName: true, lastName: true, avatarUrl: true } },
        services: true
      },
      orderBy: { ratingAvg: "desc" },
      take: 40
    });

    return NextResponse.json({ professionals });
  });
}

const schema = z.object({
  jobTitle: z.string().min(2),
  description: z.string().optional(),
  experienceYears: z.number().int().min(0).optional(),
  zone: z.string().min(1),
  city: z.string().min(1),
  quartier: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const existing = await db.professionalProfile.findUnique({ where: { userId: user.id } });
    if (existing) {
      return NextResponse.json({ error: "Ton profil professionnel existe déjà." }, { status: 409 });
    }

    const body = schema.parse(await req.json());

    const [profile] = await db.$transaction([
      db.professionalProfile.create({ data: { ...body, userId: user.id } }),
      db.user.update({
        where: { id: user.id },
        data: { roles: user.roles.includes(Role.PROFESSIONAL) ? undefined : { push: Role.PROFESSIONAL } }
      })
    ]);

    return NextResponse.json({ profile }, { status: 201 });
  });
}
