import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const vehicle = await db.vehicle.findUnique({
      where: { id: params.id },
      include: { images: true, seller: { select: { firstName: true, lastName: true, phone: true } } }
    });
    if (!vehicle) return NextResponse.json({ error: "Annonce introuvable." }, { status: 404 });
    return NextResponse.json({ vehicle });
  });
}

const schema = z.object({
  price: z.number().int().positive().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "SOLD", "ARCHIVED"]).optional(),
  description: z.string().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const vehicle = await db.vehicle.findUnique({ where: { id: params.id } });
    if (!vehicle || vehicle.sellerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const body = schema.parse(await req.json());
    const updated = await db.vehicle.update({ where: { id: params.id }, data: body as any });
    return NextResponse.json({ vehicle: updated });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const vehicle = await db.vehicle.findUnique({ where: { id: params.id } });
    if (!vehicle || vehicle.sellerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    await db.vehicle.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
