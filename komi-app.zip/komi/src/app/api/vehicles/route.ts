import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireVerifiedUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { VehicleType, VehicleCondition } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const sp = req.nextUrl.searchParams;
    const city = sp.get("city") ?? undefined;
    const type = sp.get("type") as VehicleType | null;
    const brand = sp.get("brand") ?? undefined;
    const condition = sp.get("condition") as VehicleCondition | null;
    const maxPrice = sp.get("maxPrice") ? Number(sp.get("maxPrice")) : undefined;

    const vehicles = await db.vehicle.findMany({
      where: {
        status: "PUBLISHED",
        city: city || undefined,
        type: type || undefined,
        condition: condition || undefined,
        brand: brand ? { contains: brand, mode: "insensitive" } : undefined,
        price: maxPrice ? { lte: maxPrice } : undefined
      },
      include: { images: true, seller: { select: { firstName: true, lastName: true, phone: true } } },
      orderBy: { createdAt: "desc" },
      take: 40
    });

    return NextResponse.json({ vehicles });
  });
}

const schema = z.object({
  type: z.nativeEnum(VehicleType),
  brand: z.string().min(1),
  model: z.string().min(1),
  year: z.number().int().min(1950).max(new Date().getFullYear() + 1),
  mileageKm: z.number().int().min(0).optional(),
  price: z.number().int().positive(),
  condition: z.nativeEnum(VehicleCondition),
  city: z.string().min(1),
  quartier: z.string().optional(),
  description: z.string().optional(),
  images: z.array(z.string().url()).min(1, "Ajoute au moins une photo.")
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const body = schema.parse(await req.json());

    const vehicle = await db.vehicle.create({
      data: {
        sellerId: user.id,
        type: body.type,
        brand: body.brand,
        model: body.model,
        year: body.year,
        mileageKm: body.mileageKm,
        price: body.price,
        condition: body.condition,
        city: body.city,
        quartier: body.quartier,
        description: body.description,
        images: { create: body.images.map((url, position) => ({ url, position })) }
      },
      include: { images: true }
    });

    return NextResponse.json({ vehicle }, { status: 201 });
  });
}
