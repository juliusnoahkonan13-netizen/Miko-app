import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const professional = await db.professionalProfile.findUnique({ where: { userId: user.id } });
    if (!professional) return NextResponse.json({ error: "Aucun profil professionnel." }, { status: 404 });

    const [pendingRequests, quotesSent, quotesAccepted, upcomingAppointments, completedAppointments] =
      await Promise.all([
        db.serviceOffer.count({ where: { professionalId: professional.id } }),
        db.quote.count({ where: { professionalId: professional.id } }),
        db.quote.count({ where: { professionalId: professional.id, status: "ACCEPTED" } }),
        db.appointment.count({
          where: { professionalId: professional.id, startTime: { gte: new Date() }, status: { not: "CANCELLED" } }
        }),
        db.appointment.count({ where: { professionalId: professional.id, status: "COMPLETED" } })
      ]);

    return NextResponse.json({
      id: professional.id,
      ratingAvg: professional.ratingAvg,
      ratingCount: professional.ratingCount,
      verification: professional.verification,
      pendingRequests,
      quotesSent,
      quotesAccepted,
      upcomingAppointments,
      completedAppointments
    });
  });
}
