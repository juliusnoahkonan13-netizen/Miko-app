import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { ownerId: user.id } });
    if (!store) return NextResponse.json({ error: "Aucune boutique." }, { status: 404 });

    const products = await db.product.findMany({
      where: { storeId: store.id },
      include: { images: true },
      orderBy: { createdAt: "desc" }
    });

    return NextResponse.json({ products });
  });
}
