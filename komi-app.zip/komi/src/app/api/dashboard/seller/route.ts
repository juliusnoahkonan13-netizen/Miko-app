import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { ownerId: user.id } });
    if (!store) return NextResponse.json({ error: "Aucune boutique." }, { status: 404 });

    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(startOfDay);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
    const startOfMonth = new Date(startOfDay.getFullYear(), startOfDay.getMonth(), 1);

    const [today, week, month, productCount, topProducts, pendingOrders] = await Promise.all([
      db.order.aggregate({ where: { storeId: store.id, createdAt: { gte: startOfDay } }, _sum: { total: true }, _count: true }),
      db.order.aggregate({ where: { storeId: store.id, createdAt: { gte: startOfWeek } }, _sum: { total: true }, _count: true }),
      db.order.aggregate({ where: { storeId: store.id, createdAt: { gte: startOfMonth } }, _sum: { total: true }, _count: true }),
      db.product.count({ where: { storeId: store.id, isActive: true } }),
      db.orderItem.groupBy({
        by: ["productId"],
        where: { order: { storeId: store.id } },
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: "desc" } },
        take: 5
      }),
      db.order.count({ where: { storeId: store.id, status: "PENDING" } })
    ]);

    const productDetails = await db.product.findMany({
      where: { id: { in: topProducts.map((p) => p.productId) } },
      select: { id: true, name: true }
    });

    return NextResponse.json({
      today: { revenue: today._sum.total ?? 0, orders: today._count },
      week: { revenue: week._sum.total ?? 0, orders: week._count },
      month: { revenue: month._sum.total ?? 0, orders: month._count },
      productCount,
      pendingOrders,
      topProducts: topProducts.map((tp) => ({
        product: productDetails.find((p) => p.id === tp.productId),
        quantitySold: tp._sum.quantity ?? 0
      }))
    });
  });
}
