import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

async function assertParticipant(conversationId: string, userId: string) {
  const participant = await db.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } }
  });
  return !!participant;
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    if (!(await assertParticipant(params.id, user.id))) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }

    const messages = await db.message.findMany({
      where: { conversationId: params.id },
      orderBy: { createdAt: "asc" },
      include: { sender: { select: { firstName: true, lastName: true, avatarUrl: true } } }
    });

    await db.conversationParticipant.update({
      where: { conversationId_userId: { conversationId: params.id, userId: user.id } },
      data: { lastReadAt: new Date() }
    });

    return NextResponse.json({ messages });
  });
}

const schema = z.object({ body: z.string().optional(), imageUrl: z.string().url().optional() });

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    if (!(await assertParticipant(params.id, user.id))) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }

    const body = schema.parse(await req.json());
    if (!body.body && !body.imageUrl) {
      return NextResponse.json({ error: "Message vide." }, { status: 400 });
    }

    const message = await db.message.create({
      data: { conversationId: params.id, senderId: user.id, body: body.body, imageUrl: body.imageUrl }
    });

    const others = await db.conversationParticipant.findMany({
      where: { conversationId: params.id, userId: { not: user.id } }
    });
    await Promise.all(
      others.map((p) =>
        db.notification.create({
          data: {
            userId: p.userId,
            type: "NEW_MESSAGE",
            title: "Nouveau message",
            body: `${user.firstName} ${user.lastName} : ${body.body?.slice(0, 60) ?? "📷 Photo"}`,
            linkUrl: `/messages/${params.id}`
          }
        })
      )
    );

    return NextResponse.json({ message }, { status: 201 });
  });
}
