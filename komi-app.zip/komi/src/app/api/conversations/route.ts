import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const conversations = await db.conversation.findMany({
      where: { participants: { some: { userId: user.id } } },
      include: {
        participants: { include: { user: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } } } },
        messages: { orderBy: { createdAt: "desc" }, take: 1 }
      },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ conversations });
  });
}

const schema = z.object({
  recipientId: z.string(),
  firstMessage: z.string().min(1)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());

    if (body.recipientId === user.id) {
      return NextResponse.json({ error: "Impossible de te contacter toi-même." }, { status: 400 });
    }

    // Reuse an existing 1-to-1 conversation if one already exists.
    const existing = await db.conversation.findFirst({
      where: {
        AND: [
          { participants: { some: { userId: user.id } } },
          { participants: { some: { userId: body.recipientId } } }
        ]
      }
    });

    const conversation =
      existing ??
      (await db.conversation.create({
        data: {
          participants: { create: [{ userId: user.id }, { userId: body.recipientId }] }
        }
      }));

    const message = await db.message.create({
      data: { conversationId: conversation.id, senderId: user.id, body: body.firstMessage }
    });

    await db.notification.create({
      data: {
        userId: body.recipientId,
        type: "NEW_MESSAGE",
        title: "Nouveau message",
        body: `${user.firstName} ${user.lastName} t'a envoyé un message.`,
        linkUrl: `/messages/${conversation.id}`
      }
    });

    return NextResponse.json({ conversation, message }, { status: 201 });
  });
}
