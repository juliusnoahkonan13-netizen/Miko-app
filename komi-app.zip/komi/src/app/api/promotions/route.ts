import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const promotions = await db.promotion.findMany({
      where: { endsAt: { gte: new Date() }, startsAt: { lte: new Date() } },
      include: { product: { include: { images: true } }, store: true },
      orderBy: { discountPct: "desc" },
      take: 40
    });
    return NextResponse.json({ promotions });
  });
}

const schema = z.object({
  productId: z.string().optional(),
  label: z.string().min(2),
  discountPct: z.number().int().min(1).max(90),
  startsAt: z.string().datetime(),
  endsAt: z.string().datetime()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { ownerId: user.id } });
    if (!store) return NextResponse.json({ error: "Tu dois avoir une boutique." }, { status: 400 });

    const body = schema.parse(await req.json());

    if (body.productId) {
      const product = await db.product.findUnique({ where: { id: body.productId } });
      if (!product || product.storeId !== store.id) {
        return NextResponse.json({ error: "Ce produit ne t'appartient pas." }, { status: 403 });
      }
      await db.product.update({
        where: { id: body.productId },
        data: { promoPrice: Math.round(product.price * (1 - body.discountPct / 100)) }
      });
    }

    const promotion = await db.promotion.create({
      data: {
        storeId: store.id,
        productId: body.productId,
        label: body.label,
        discountPct: body.discountPct,
        startsAt: new Date(body.startsAt),
        endsAt: new Date(body.endsAt)
        // isSponsored stays false here — sponsored placement is a paid admin-approved flag (module 24).
      }
    });

    return NextResponse.json({ promotion }, { status: 201 });
  });
}
