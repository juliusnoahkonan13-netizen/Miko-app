import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const store = await db.store.findFirst({
      where: { OR: [{ id: params.id }, { slug: params.id }] },
      include: {
        products: { where: { isActive: true }, include: { images: true }, take: 60 },
        promotions: true
      }
    });
    if (!store) return NextResponse.json({ error: "Boutique introuvable." }, { status: 404 });
    return NextResponse.json({ store });
  });
}

const schema = z.object({
  name: z.string().min(2).optional(),
  description: z.string().optional(),
  logoUrl: z.string().url().optional(),
  bannerUrl: z.string().url().optional(),
  city: z.string().optional(),
  quartier: z.string().optional(),
  phone: z.string().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { id: params.id } });
    if (!store || store.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const body = schema.parse(await req.json());
    const updated = await db.store.update({ where: { id: params.id }, data: body });
    return NextResponse.json({ store: updated });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { id: params.id } });
    if (!store || store.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    await db.store.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
