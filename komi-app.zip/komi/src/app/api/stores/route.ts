import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireVerifiedUser } from "@/lib/auth";
import { handleRoute, uniqueSlug } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const city = req.nextUrl.searchParams.get("city") ?? undefined;
    const q = req.nextUrl.searchParams.get("q") ?? undefined;

    const stores = await db.store.findMany({
      where: {
        city: city || undefined,
        name: q ? { contains: q, mode: "insensitive" } : undefined
      },
      include: { _count: { select: { products: true } } },
      orderBy: { createdAt: "desc" },
      take: 40
    });
    return NextResponse.json({ stores });
  });
}

const schema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  city: z.string().optional(),
  quartier: z.string().optional(),
  phone: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const existing = await db.store.findUnique({ where: { ownerId: user.id } });
    if (existing) {
      return NextResponse.json({ error: "Tu as déjà une boutique." }, { status: 409 });
    }

    const body = schema.parse(await req.json());
    const slug = await uniqueSlug(body.name, (s) => db.store.findUnique({ where: { slug: s } }));

    const [store] = await db.$transaction([
      db.store.create({ data: { ...body, slug, ownerId: user.id } }),
      db.user.update({
        where: { id: user.id },
        data: { roles: user.roles.includes(Role.SELLER) ? undefined : { push: Role.SELLER } }
      })
    ]);

    return NextResponse.json({ store }, { status: 201 });
  });
}
