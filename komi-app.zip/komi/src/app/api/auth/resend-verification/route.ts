import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { issueVerificationCode } from "@/lib/verification";

const RESEND_COOLDOWN_SECONDS = 60;

export async function POST() {
  return handleRoute(async () => {
    const user = await requireUser();

    if (user.emailVerifiedAt) {
      return NextResponse.json({ ok: true, alreadyVerified: true });
    }

    const lastCode = await db.emailVerificationCode.findFirst({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" }
    });

    if (lastCode) {
      const secondsSince = (Date.now() - lastCode.createdAt.getTime()) / 1000;
      if (secondsSince < RESEND_COOLDOWN_SECONDS) {
        return NextResponse.json(
          { error: `Attends encore ${Math.ceil(RESEND_COOLDOWN_SECONDS - secondsSince)}s avant de redemander un code.` },
          { status: 429 }
        );
      }
    }

    await issueVerificationCode(user.id, user.email, user.firstName);
    return NextResponse.json({ ok: true });
  });
}
