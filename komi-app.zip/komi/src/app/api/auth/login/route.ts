import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { verifyPassword, createSession } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({
  identifier: z.string().min(3), // email or phone
  password: z.string().min(1)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const { identifier, password } = schema.parse(await req.json());

    const user = await db.user.findFirst({
      where: { OR: [{ email: identifier }, { phone: identifier }] }
    });

    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return NextResponse.json({ error: "Identifiants incorrects." }, { status: 401 });
    }
    if (user.isSuspended) {
      return NextResponse.json({ error: "Ce compte est suspendu." }, { status: 403 });
    }

    await createSession(user.id, req.headers.get("user-agent") ?? undefined);

    const { passwordHash, ...safeUser } = user;
    return NextResponse.json({ user: safeUser });
  });
}
