import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, createSession } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { issueVerificationCode } from "@/lib/verification";
import { Role } from "@prisma/client";

const schema = z.object({
  email: z.string().email(),
  phone: z.string().min(8).optional(),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères."),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  city: z.string().optional(),
  quartier: z.string().optional(),
  role: z.nativeEnum(Role).default(Role.CLIENT)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const body = schema.parse(await req.json());

    const existing = await db.user.findFirst({
      where: { OR: [{ email: body.email }, ...(body.phone ? [{ phone: body.phone }] : [])] }
    });
    if (existing) {
      return NextResponse.json(
        { error: "Un compte existe déjà avec cet email ou ce numéro." },
        { status: 409 }
      );
    }

    // ADMIN can never be self-selected at signup.
    const role = body.role === Role.ADMIN ? Role.CLIENT : body.role;

    const user = await db.user.create({
      data: {
        email: body.email,
        phone: body.phone,
        passwordHash: await hashPassword(body.password),
        firstName: body.firstName,
        lastName: body.lastName,
        city: body.city,
        quartier: body.quartier,
        roles: [role],
        cart: { create: {} }
      }
    });

    await createSession(user.id, req.headers.get("user-agent") ?? undefined);
    await issueVerificationCode(user.id, user.email, user.firstName);

    const { passwordHash, ...safeUser } = user;
    return NextResponse.json({ user: safeUser }, { status: 201 });
  });
}
