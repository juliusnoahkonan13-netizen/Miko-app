import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ user: null });
    const { passwordHash, ...safeUser } = user;
    return NextResponse.json({ user: safeUser });
  });
}
