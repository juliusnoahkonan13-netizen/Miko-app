import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import crypto from "crypto";
import { db } from "@/lib/db";
import { handleRoute } from "@/lib/api";
import { sendEmail } from "@/lib/email";

const schema = z.object({ email: z.string().email() });

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const { email } = schema.parse(await req.json());
    const user = await db.user.findUnique({ where: { email } });

    // Always return ok — never reveal whether an email exists.
    if (!user) return NextResponse.json({ ok: true });

    const rawToken = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");

    await db.passwordResetToken.create({
      data: { userId: user.id, tokenHash, expiresAt: new Date(Date.now() + 60 * 60 * 1000) }
    });

    const resetUrl = `${req.nextUrl.origin}/reset-password?token=${rawToken}`;
    const subject = "Réinitialise ton mot de passe Komi";
    const html = `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;">
      <h2 style="color:#1B4F9C;">Réinitialisation de mot de passe</h2>
      <p>Clique sur le lien ci-dessous pour choisir un nouveau mot de passe (valable 1 heure) :</p>
      <p><a href="${resetUrl}" style="color:#1B4F9C;font-weight:600;">${resetUrl}</a></p>
      <p style="color:#666;font-size:14px;">Si tu n'es pas à l'origine de cette demande, ignore cet email.</p>
    </div>`;
    await sendEmail(email, subject, html, `Réinitialise ton mot de passe : ${resetUrl}`);

    return NextResponse.json({ ok: true });
  });
}
