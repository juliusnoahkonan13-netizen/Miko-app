import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, hashVerificationCode } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({ code: z.string().length(6) });

const MAX_ATTEMPTS = 5;

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();

    if (user.emailVerifiedAt) {
      return NextResponse.json({ ok: true, alreadyVerified: true });
    }

    const { code } = schema.parse(await req.json());

    const record = await db.emailVerificationCode.findFirst({
      where: { userId: user.id, consumedAt: null },
      orderBy: { createdAt: "desc" }
    });

    if (!record || record.expiresAt < new Date()) {
      return NextResponse.json({ error: "Code expiré. Demande un nouveau code." }, { status: 400 });
    }
    if (record.attempts >= MAX_ATTEMPTS) {
      return NextResponse.json({ error: "Trop de tentatives. Demande un nouveau code." }, { status: 429 });
    }

    if (hashVerificationCode(code) !== record.codeHash) {
      await db.emailVerificationCode.update({ where: { id: record.id }, data: { attempts: { increment: 1 } } });
      return NextResponse.json({ error: "Code incorrect." }, { status: 400 });
    }

    await db.$transaction([
      db.emailVerificationCode.update({ where: { id: record.id }, data: { consumedAt: new Date() } }),
      db.user.update({ where: { id: user.id }, data: { emailVerifiedAt: new Date() } })
    ]);

    return NextResponse.json({ ok: true });
  });
}
