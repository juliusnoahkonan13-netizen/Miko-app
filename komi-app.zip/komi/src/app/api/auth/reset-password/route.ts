import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import crypto from "crypto";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({
  token: z.string().min(10),
  newPassword: z.string().min(8)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const { token, newPassword } = schema.parse(await req.json());
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");

    const record = await db.passwordResetToken.findUnique({ where: { tokenHash } });
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      return NextResponse.json({ error: "Lien invalide ou expiré." }, { status: 400 });
    }

    await db.$transaction([
      db.user.update({
        where: { id: record.userId },
        data: { passwordHash: await hashPassword(newPassword) }
      }),
      db.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      db.session.deleteMany({ where: { userId: record.userId } }) // force re-login everywhere
    ]);

    return NextResponse.json({ ok: true });
  });
}
