import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const as = req.nextUrl.searchParams.get("as");

    if (as === "professional") {
      const professional = await db.professionalProfile.findUnique({ where: { userId: user.id } });
      if (!professional) return NextResponse.json({ appointments: [] });
      const appointments = await db.appointment.findMany({
        where: { professionalId: professional.id },
        include: { client: { select: { firstName: true, lastName: true, phone: true } } },
        orderBy: { startTime: "asc" }
      });
      return NextResponse.json({ appointments });
    }

    const appointments = await db.appointment.findMany({
      where: { clientId: user.id },
      include: { professional: { include: { user: { select: { firstName: true, lastName: true } } } } },
      orderBy: { startTime: "asc" }
    });
    return NextResponse.json({ appointments });
  });
}

const schema = z.object({
  professionalId: z.string(),
  startTime: z.string().datetime(),
  endTime: z.string().datetime(),
  note: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());

    const overlap = await db.appointment.findFirst({
      where: {
        professionalId: body.professionalId,
        status: { not: "CANCELLED" },
        startTime: { lt: new Date(body.endTime) },
        endTime: { gt: new Date(body.startTime) }
      }
    });
    if (overlap) {
      return NextResponse.json({ error: "Ce créneau vient d'être réservé." }, { status: 409 });
    }

    const appointment = await db.appointment.create({
      data: {
        professionalId: body.professionalId,
        clientId: user.id,
        startTime: new Date(body.startTime),
        endTime: new Date(body.endTime),
        note: body.note
      },
      include: { professional: true }
    });

    await notify(
      appointment.professional.userId,
      "NEW_APPOINTMENT",
      "Nouveau rendez-vous",
      `${user.firstName} ${user.lastName} a réservé un créneau le ${new Date(body.startTime).toLocaleString("fr-FR")}.`,
      `/dashboard/professional/appointments/${appointment.id}`
    );

    return NextResponse.json({ appointment }, { status: 201 });
  });
}
