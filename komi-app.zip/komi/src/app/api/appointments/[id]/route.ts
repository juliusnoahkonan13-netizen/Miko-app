import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({ status: z.enum(["CONFIRMED", "CANCELLED", "COMPLETED"]) });

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const appointment = await db.appointment.findUnique({
      where: { id: params.id },
      include: { professional: true }
    });
    if (!appointment) return NextResponse.json({ error: "Rendez-vous introuvable." }, { status: 404 });

    const isProfessional = appointment.professional.userId === user.id;
    const isClient = appointment.clientId === user.id;
    if (!isProfessional && !isClient) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }

    const { status } = schema.parse(await req.json());
    const updated = await db.appointment.update({ where: { id: params.id }, data: { status } });
    return NextResponse.json({ appointment: updated });
  });
}
