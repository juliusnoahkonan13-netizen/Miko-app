import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireVerifiedUser } from "@/lib/auth";
import { handleRoute, uniqueSlug } from "@/lib/api";
import { Role } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const q = req.nextUrl.searchParams.get("q") ?? undefined;
    const city = req.nextUrl.searchParams.get("city") ?? undefined;
    const businesses = await db.businessProfile.findMany({
      where: {
        city: city || undefined,
        companyName: q ? { contains: q, mode: "insensitive" } : undefined
      },
      include: { services: true, employees: true },
      take: 40
    });
    return NextResponse.json({ businesses });
  });
}

const schema = z.object({
  companyName: z.string().min(2),
  sector: z.string().optional(),
  description: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  website: z.string().url().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const existing = await db.businessProfile.findUnique({ where: { userId: user.id } });
    if (existing) return NextResponse.json({ error: "Ta page entreprise existe déjà." }, { status: 409 });

    const body = schema.parse(await req.json());
    const slug = await uniqueSlug(body.companyName, (s) => db.businessProfile.findUnique({ where: { slug: s } }));

    const [business] = await db.$transaction([
      db.businessProfile.create({ data: { ...body, slug, userId: user.id } }),
      db.user.update({
        where: { id: user.id },
        data: { roles: user.roles.includes(Role.BUSINESS) ? undefined : { push: Role.BUSINESS } }
      })
    ]);

    return NextResponse.json({ business }, { status: 201 });
  });
}
