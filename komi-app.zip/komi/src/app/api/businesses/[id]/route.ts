import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const business = await db.businessProfile.findFirst({
      where: { OR: [{ id: params.id }, { slug: params.id }] },
      include: { services: true, employees: true }
    });
    if (!business) return NextResponse.json({ error: "Entreprise introuvable." }, { status: 404 });
    return NextResponse.json({ business });
  });
}
