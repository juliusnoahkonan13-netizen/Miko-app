import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const notifications = await db.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 50
    });
    const unreadCount = await db.notification.count({ where: { userId: user.id, isRead: false } });
    return NextResponse.json({ notifications, unreadCount });
  });
}
