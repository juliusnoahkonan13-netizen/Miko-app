import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function PATCH(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const notif = await db.notification.findUnique({ where: { id: params.id } });
    if (!notif || notif.userId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const updated = await db.notification.update({ where: { id: params.id }, data: { isRead: true } });
    return NextResponse.json({ notification: updated });
  });
}
