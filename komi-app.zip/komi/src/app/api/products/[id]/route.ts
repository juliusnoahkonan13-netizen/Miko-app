import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const product = await db.product.findFirst({
      where: { OR: [{ id: params.id }, { slug: params.id }] },
      include: {
        images: true,
        variants: true,
        store: true,
        promotions: { where: { endsAt: { gte: new Date() } } }
      }
    });
    if (!product) return NextResponse.json({ error: "Produit introuvable." }, { status: 404 });

    const reviewStats = await db.review.aggregate({
      where: { targetType: "PRODUCT", targetId: product.id },
      _avg: { rating: true },
      _count: true
    });

    return NextResponse.json({
      product,
      rating: { average: reviewStats._avg.rating ?? 0, count: reviewStats._count }
    });
  });
}

const schema = z.object({
  name: z.string().min(2).optional(),
  description: z.string().optional(),
  price: z.number().int().positive().optional(),
  promoPrice: z.number().int().positive().nullable().optional(),
  stock: z.number().int().min(0).optional(),
  isActive: z.boolean().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const product = await db.product.findUnique({ where: { id: params.id }, include: { store: true } });
    if (!product || product.store.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    const body = schema.parse(await req.json());
    const updated = await db.product.update({ where: { id: params.id }, data: body });
    return NextResponse.json({ product: updated });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const product = await db.product.findUnique({ where: { id: params.id }, include: { store: true } });
    if (!product || product.store.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    await db.product.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
