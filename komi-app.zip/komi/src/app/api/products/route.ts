import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute, uniqueSlug } from "@/lib/api";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const sp = req.nextUrl.searchParams;
    const q = sp.get("q") ?? undefined;
    const categoryId = sp.get("categoryId") ?? undefined;
    const city = sp.get("city") ?? undefined;
    const condition = sp.get("condition") ?? undefined;
    const minPrice = sp.get("minPrice") ? Number(sp.get("minPrice")) : undefined;
    const maxPrice = sp.get("maxPrice") ? Number(sp.get("maxPrice")) : undefined;
    const page = Math.max(1, Number(sp.get("page") ?? 1));
    const pageSize = 20;

    const where = {
      isActive: true,
      categoryId: categoryId || undefined,
      condition: condition || undefined,
      store: city ? { city } : undefined,
      price:
        minPrice || maxPrice
          ? { gte: minPrice ?? undefined, lte: maxPrice ?? undefined }
          : undefined,
      OR: q
        ? [
            { name: { contains: q, mode: "insensitive" as const } },
            { description: { contains: q, mode: "insensitive" as const } },
            { brand: { contains: q, mode: "insensitive" as const } }
          ]
        : undefined
    };

    const [products, total] = await db.$transaction([
      db.product.findMany({
        where,
        include: { images: true, store: { select: { name: true, slug: true, city: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      db.product.count({ where })
    ]);

    return NextResponse.json({ products, total, page, pageSize });
  });
}

const schema = z.object({
  name: z.string().min(2),
  description: z.string().min(1),
  price: z.number().int().positive(),
  promoPrice: z.number().int().positive().optional(),
  stock: z.number().int().min(0).default(0),
  brand: z.string().optional(),
  condition: z.enum(["neuf", "occasion"]).optional(),
  categoryId: z.string().optional(),
  images: z.array(z.string().url()).min(1, "Ajoute au moins une photo."),
  variants: z
    .array(z.object({ size: z.string().optional(), color: z.string().optional(), stock: z.number().int().min(0) }))
    .optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const store = await db.store.findUnique({ where: { ownerId: user.id } });
    if (!store) {
      return NextResponse.json(
        { error: "Crée d'abord ta boutique avant d'ajouter un produit." },
        { status: 400 }
      );
    }

    const body = schema.parse(await req.json());
    const slug = await uniqueSlug(body.name, (s) => db.product.findUnique({ where: { slug: s } }));

    const product = await db.product.create({
      data: {
        storeId: store.id,
        name: body.name,
        slug,
        description: body.description,
        price: body.price,
        promoPrice: body.promoPrice,
        stock: body.stock,
        brand: body.brand,
        condition: body.condition,
        categoryId: body.categoryId,
        images: { create: body.images.map((url, position) => ({ url, position })) },
        variants: body.variants ? { create: body.variants } : undefined
      },
      include: { images: true, variants: true }
    });

    return NextResponse.json({ product }, { status: 201 });
  });
}
