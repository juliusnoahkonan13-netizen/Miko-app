import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

async function assertOwnership(itemId: string, userId: string) {
  const item = await db.cartItem.findUnique({ where: { id: itemId }, include: { cart: true } });
  if (!item || item.cart.userId !== userId) return null;
  return item;
}

const schema = z.object({ quantity: z.number().int().positive() });

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const item = await assertOwnership(params.id, user.id);
    if (!item) return NextResponse.json({ error: "Article introuvable." }, { status: 404 });

    const { quantity } = schema.parse(await req.json());
    const updated = await db.cartItem.update({ where: { id: params.id }, data: { quantity } });
    return NextResponse.json({ item: updated });
  });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const item = await assertOwnership(params.id, user.id);
    if (!item) return NextResponse.json({ error: "Article introuvable." }, { status: 404 });

    await db.cartItem.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  });
}
