import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

const schema = z.object({
  productId: z.string(),
  variantId: z.string().optional(),
  quantity: z.number().int().positive().default(1)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());

    const product = await db.product.findUnique({ where: { id: body.productId } });
    if (!product || !product.isActive) {
      return NextResponse.json({ error: "Produit indisponible." }, { status: 404 });
    }
    if (product.stock < body.quantity) {
      return NextResponse.json({ error: "Stock insuffisant." }, { status: 409 });
    }

    const cart = await db.cart.upsert({
      where: { userId: user.id },
      create: { userId: user.id },
      update: {}
    });

    const item = await db.cartItem.upsert({
      where: {
        cartId_productId_variantId: {
          cartId: cart.id,
          productId: body.productId,
          variantId: body.variantId ?? null
        }
      },
      create: {
        cartId: cart.id,
        productId: body.productId,
        variantId: body.variantId,
        quantity: body.quantity
      },
      update: { quantity: { increment: body.quantity } }
    });

    return NextResponse.json({ item }, { status: 201 });
  });
}
