import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET() {
  return handleRoute(async () => {
    const user = await requireUser();
    const cart = await db.cart.upsert({
      where: { userId: user.id },
      create: { userId: user.id },
      update: {},
      include: {
        items: { include: { product: { include: { images: true, store: true } }, variant: true } }
      }
    });

    const subtotal = cart.items.reduce((sum, item) => {
      const price = item.product.promoPrice ?? item.product.price;
      return sum + price * item.quantity;
    }, 0);

    return NextResponse.json({ cart, subtotal });
  });
}
