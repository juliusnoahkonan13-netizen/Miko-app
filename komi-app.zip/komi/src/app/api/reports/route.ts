import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, requireRole } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { TargetType, Role } from "@prisma/client";

export async function GET() {
  return handleRoute(async () => {
    await requireRole(Role.ADMIN);
    const reports = await db.report.findMany({
      where: { status: "PENDING" },
      include: { reporter: { select: { firstName: true, lastName: true } } },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ reports });
  });
}

const schema = z.object({
  targetType: z.nativeEnum(TargetType),
  targetId: z.string(),
  reason: z.string().min(3),
  details: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());
    const report = await db.report.create({ data: { ...body, reporterId: user.id } });
    return NextResponse.json({ report }, { status: 201 });
  });
}
