import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const categoryId = req.nextUrl.searchParams.get("categoryId") ?? undefined;
    const services = await db.service.findMany({
      where: { categoryId: categoryId || undefined },
      include: {
        professional: { include: { user: { select: { firstName: true, lastName: true } } } },
        business: true
      },
      take: 60
    });
    return NextResponse.json({ services });
  });
}

const schema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  priceFrom: z.number().int().positive().optional(),
  priceTo: z.number().int().positive().optional(),
  categoryId: z.string().optional()
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const body = schema.parse(await req.json());

    const [professional, business] = await Promise.all([
      db.professionalProfile.findUnique({ where: { userId: user.id } }),
      db.businessProfile.findUnique({ where: { userId: user.id } })
    ]);

    if (!professional && !business) {
      return NextResponse.json(
        { error: "Crée d'abord un profil professionnel ou une page entreprise." },
        { status: 400 }
      );
    }

    const service = await db.service.create({
      data: { ...body, professionalId: professional?.id, businessId: business?.id }
    });

    return NextResponse.json({ service }, { status: 201 });
  });
}
