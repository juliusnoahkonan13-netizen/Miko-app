import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser, requireVerifiedUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";
import { PaymentMethod } from "@prisma/client";

export async function GET(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireUser();
    const as = req.nextUrl.searchParams.get("as"); // "buyer" | "seller"

    if (as === "seller") {
      const store = await db.store.findUnique({ where: { ownerId: user.id } });
      if (!store) return NextResponse.json({ orders: [] });
      const orders = await db.order.findMany({
        where: { storeId: store.id },
        include: { items: { include: { product: true } }, buyer: { select: { firstName: true, lastName: true, phone: true } } },
        orderBy: { createdAt: "desc" }
      });
      return NextResponse.json({ orders });
    }

    const orders = await db.order.findMany({
      where: { buyerId: user.id },
      include: { items: { include: { product: { include: { images: true } } } }, store: true },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ orders });
  });
}

const schema = z.object({
  deliveryAddress: z.string().min(3),
  deliveryCity: z.string().min(1),
  deliveryQuartier: z.string().optional(),
  paymentMethod: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH_ON_DELIVERY)
});

export async function POST(req: NextRequest) {
  return handleRoute(async () => {
    const user = await requireVerifiedUser();
    const body = schema.parse(await req.json());

    const cart = await db.cart.findUnique({
      where: { userId: user.id },
      include: { items: { include: { product: { include: { store: true } }, variant: true } } }
    });

    if (!cart || cart.items.length === 0) {
      return NextResponse.json({ error: "Ton panier est vide." }, { status: 400 });
    }

    // Group items by store — one Order per seller, as in real marketplaces.
    const byStore = new Map<string, typeof cart.items>();
    for (const item of cart.items) {
      const list = byStore.get(item.product.storeId) ?? [];
      list.push(item);
      byStore.set(item.product.storeId, list);
    }

    const createdOrders = [];

    for (const [storeId, items] of byStore) {
      for (const item of items) {
        if (item.product.stock < item.quantity) {
          return NextResponse.json(
            { error: `Stock insuffisant pour "${item.product.name}".` },
            { status: 409 }
          );
        }
      }

      const subtotal = items.reduce(
        (sum, i) => sum + (i.product.promoPrice ?? i.product.price) * i.quantity,
        0
      );
      const deliveryFee = 0; // TODO: calculer via DeliveryZone du store selon deliveryCity/quartier

      const order = await db.$transaction(async (tx) => {
        const created = await tx.order.create({
          data: {
            buyerId: user.id,
            storeId,
            subtotal,
            deliveryFee,
            total: subtotal + deliveryFee,
            deliveryAddress: body.deliveryAddress,
            deliveryCity: body.deliveryCity,
            deliveryQuartier: body.deliveryQuartier,
            paymentMethod: body.paymentMethod,
            items: {
              create: items.map((i) => ({
                productId: i.productId,
                variantLabel: i.variant
                  ? [i.variant.size, i.variant.color].filter(Boolean).join(" / ") || undefined
                  : undefined,
                quantity: i.quantity,
                unitPrice: i.product.promoPrice ?? i.product.price
              }))
            },
            statusHistory: { create: { status: "PENDING", note: "Commande créée" } },
            payment: {
              create: {
                method: body.paymentMethod,
                amount: subtotal + deliveryFee,
                status: body.paymentMethod === "CASH_ON_DELIVERY" ? "PENDING" : "PENDING"
              }
            }
          },
          include: { items: true, store: true }
        });

        for (const i of items) {
          await tx.product.update({
            where: { id: i.productId },
            data: { stock: { decrement: i.quantity } }
          });
        }
        await tx.cartItem.deleteMany({ where: { id: { in: items.map((i) => i.id) } } });

        return created;
      });

      await notify(
        order.store.ownerId,
        "NEW_ORDER",
        "Nouvelle commande reçue",
        `${user.firstName} ${user.lastName} a commandé ${items.length} article(s) pour ${order.total} FCFA.`,
        `/dashboard/seller/orders/${order.id}`
      );

      createdOrders.push(order);
    }

    return NextResponse.json({ orders: createdOrders }, { status: 201 });
  });
}
