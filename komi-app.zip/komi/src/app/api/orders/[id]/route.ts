import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const order = await db.order.findUnique({
      where: { id: params.id },
      include: {
        items: { include: { product: { include: { images: true } } } },
        store: true,
        payment: true,
        statusHistory: { orderBy: { createdAt: "asc" } }
      }
    });
    if (!order) return NextResponse.json({ error: "Commande introuvable." }, { status: 404 });
    if (order.buyerId !== user.id && order.store.ownerId !== user.id) {
      return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
    }
    return NextResponse.json({ order });
  });
}
