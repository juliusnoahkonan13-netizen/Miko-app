import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleRoute } from "@/lib/api";
import { notify } from "@/lib/notify";
import { OrderStatus, NotificationType } from "@prisma/client";

const schema = z.object({ status: z.nativeEnum(OrderStatus), note: z.string().optional() });

const NOTIF_BY_STATUS: Partial<Record<OrderStatus, NotificationType>> = {
  CONFIRMED: "ORDER_ACCEPTED",
  CANCELLED: "ORDER_REFUSED",
  SHIPPED: "ORDER_SHIPPED",
  DELIVERED: "ORDER_DELIVERED"
};

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  return handleRoute(async () => {
    const user = await requireUser();
    const order = await db.order.findUnique({ where: { id: params.id }, include: { store: true } });
    if (!order) return NextResponse.json({ error: "Commande introuvable." }, { status: 404 });
    if (order.store.ownerId !== user.id) {
      return NextResponse.json({ error: "Seul le vendeur peut changer ce statut." }, { status: 403 });
    }

    const { status, note } = schema.parse(await req.json());

    const updated = await db.$transaction(async (tx) => {
      const o = await tx.order.update({ where: { id: params.id }, data: { status } });
      await tx.orderStatusEvent.create({ data: { orderId: params.id, status, note } });
      return o;
    });

    const notifType = NOTIF_BY_STATUS[status];
    if (notifType) {
      await notify(
        order.buyerId,
        notifType,
        "Mise à jour de ta commande",
        `Ta commande #${order.id.slice(-6).toUpperCase()} est maintenant : ${status}.`,
        `/orders/${order.id}`
      );
    }

    return NextResponse.json({ order: updated });
  });
}
