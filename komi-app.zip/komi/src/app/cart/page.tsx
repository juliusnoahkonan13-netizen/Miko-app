"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Minus, Plus, Trash2 } from "lucide-react";

type CartItem = {
  id: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    price: number;
    promoPrice: number | null;
    stock: number;
    images: { url: string }[];
    store: { name: string };
  };
  variant: { size: string | null; color: string | null } | null;
};

export default function CartPage() {
  const router = useRouter();
  const [items, setItems] = useState<CartItem[] | null>(null);
  const [subtotal, setSubtotal] = useState(0);
  const [checkingOut, setCheckingOut] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [quartier, setQuartier] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("CASH_ON_DELIVERY");
  const [done, setDone] = useState(false);

  async function load() {
    const res = await fetch("/api/cart", { cache: "no-store" });
    if (res.status === 401) return router.push("/login");
    const data = await res.json();
    setItems(data.cart.items);
    setSubtotal(data.subtotal);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateQuantity(itemId: string, quantity: number) {
    if (quantity < 1) return;
    await fetch(`/api/cart/items/${itemId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quantity })
    });
    load();
  }

  async function removeItem(itemId: string) {
    await fetch(`/api/cart/items/${itemId}`, { method: "DELETE" });
    load();
  }

  async function checkout() {
    if (!address || !city) {
      setError("Renseigne une adresse et une ville de livraison.");
      return;
    }
    setError(null);
    setCheckingOut(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deliveryAddress: address,
          deliveryCity: city,
          deliveryQuartier: quartier || undefined,
          paymentMethod
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Impossible de créer la commande.");
      setDone(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCheckingOut(false);
    }
  }

  if (items === null) return <div className="max-w-3xl mx-auto px-4 py-10 text-ink/50">Chargement du panier...</div>;

  if (done) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <p className="text-4xl mb-3">✅</p>
        <h1 className="font-display text-2xl font-bold text-indigo mb-2">Commande envoyée !</h1>
        <p className="text-ink/60 mb-6">Le ou les vendeurs ont été notifiés. Suis l'avancement dans tes commandes.</p>
        <Link href="/orders" className="komi-btn-primary">Voir mes commandes</Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">
        <p className="text-4xl mb-3">🛒</p>
        <p>Ton panier est vide.</p>
        <Link href="/search?type=product" className="komi-btn-primary inline-block mt-4">Découvrir des produits</Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <h1 className="font-display text-2xl font-bold text-indigo">Mon panier</h1>

      <div className="space-y-3">
        {items.map((item) => {
          const price = item.product.promoPrice ?? item.product.price;
          return (
            <div key={item.id} className="komi-card p-3 flex gap-3 items-center">
              <div className="w-16 h-16 rounded-komi bg-line/40 overflow-hidden shrink-0">
                {item.product.images[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.product.images[0].url} alt="" className="w-full h-full object-cover" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm line-clamp-1">{item.product.name}</p>
                <p className="text-xs text-ink/50">{item.product.store.name}</p>
                {item.variant && (item.variant.size || item.variant.color) && (
                  <p className="text-xs text-ink/40">{[item.variant.size, item.variant.color].filter(Boolean).join(" · ")}</p>
                )}
                <p className="font-display font-semibold text-indigo text-sm mt-1">{price.toLocaleString("fr-FR")} FCFA</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-7 h-7 rounded-full border border-line flex items-center justify-center">
                  <Minus size={14} />
                </button>
                <span className="w-6 text-center text-sm">{item.quantity}</span>
                <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-7 h-7 rounded-full border border-line flex items-center justify-center">
                  <Plus size={14} />
                </button>
              </div>
              <button onClick={() => removeItem(item.id)} className="text-ink/30 hover:text-red-500">
                <Trash2 size={18} />
              </button>
            </div>
          );
        })}
      </div>

      <div className="komi-card p-4 space-y-3">
        <h2 className="font-display font-semibold text-indigo">Livraison</h2>
        <input className="komi-input" placeholder="Adresse complète" value={address} onChange={(e) => setAddress(e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <input className="komi-input" placeholder="Ville" value={city} onChange={(e) => setCity(e.target.value)} />
          <input className="komi-input" placeholder="Quartier (optionnel)" value={quartier} onChange={(e) => setQuartier(e.target.value)} />
        </div>
        <div>
          <p className="text-sm text-ink/60 mb-1">Paiement</p>
          <select className="komi-input" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
            <option value="CASH_ON_DELIVERY">Paiement à la livraison</option>
            <option value="MOBILE_MONEY">Mobile Money (bientôt disponible)</option>
            <option value="CARD">Carte bancaire (bientôt disponible)</option>
          </select>
        </div>
      </div>

      <div className="komi-card p-4 flex items-center justify-between">
        <span className="text-ink/60">Sous-total</span>
        <span className="font-display font-bold text-xl text-indigo">{subtotal.toLocaleString("fr-FR")} FCFA</span>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={checkout} disabled={checkingOut} className="komi-btn-primary w-full py-3">
        {checkingOut ? "Envoi de la commande..." : "Passer la commande"}
      </button>
    </div>
  );
}
