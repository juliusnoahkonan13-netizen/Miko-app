"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { CheckCircle2, Circle } from "lucide-react";
import ReviewForm from "@/components/ReviewForm";

const PIPELINE = ["PENDING", "CONFIRMED", "PREPARING", "SHIPPED", "DELIVERED"];
const LABELS: Record<string, string> = {
  PENDING: "Commande créée",
  CONFIRMED: "Commande confirmée",
  PREPARING: "Préparation",
  SHIPPED: "Expédition",
  DELIVERED: "Livraison",
  CANCELLED: "Annulée"
};

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/orders/${id}`, { cache: "no-store" })
      .then((res) => res.json())
      .then((data) => setOrder(data.order));
  }, [id]);

  if (!order) return <div className="max-w-2xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  const currentIndex = PIPELINE.indexOf(order.status);
  const cancelled = order.status === "CANCELLED";

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-indigo">Commande #{order.id.slice(-6).toUpperCase()}</h1>
        <p className="text-ink/50 text-sm">{order.store.name} · {new Date(order.createdAt).toLocaleString("fr-FR")}</p>
      </div>

      {!cancelled ? (
        <div className="komi-card p-4">
          <ol className="space-y-4">
            {PIPELINE.map((step, i) => (
              <li key={step} className="flex items-center gap-3">
                {i <= currentIndex ? (
                  <CheckCircle2 className="text-teal" size={20} />
                ) : (
                  <Circle className="text-line" size={20} />
                )}
                <span className={i <= currentIndex ? "text-ink font-medium" : "text-ink/40"}>{LABELS[step]}</span>
              </li>
            ))}
          </ol>
        </div>
      ) : (
        <div className="komi-card p-4 text-red-600 font-medium">Cette commande a été annulée.</div>
      )}

      <div className="komi-card p-4 space-y-3">
        <h2 className="font-display font-semibold text-indigo">Articles</h2>
        {order.items.map((item: any) => (
          <div key={item.id} className="flex justify-between text-sm">
            <span>{item.quantity} × {item.product.name}{item.variantLabel ? ` (${item.variantLabel})` : ""}</span>
            <span className="font-medium">{(item.unitPrice * item.quantity).toLocaleString("fr-FR")} FCFA</span>
          </div>
        ))}
        <div className="border-t border-line pt-3 flex justify-between font-display font-bold text-indigo">
          <span>Total</span>
          <span>{order.total.toLocaleString("fr-FR")} FCFA</span>
        </div>
      </div>

      <div className="komi-card p-4 space-y-1 text-sm">
        <h2 className="font-display font-semibold text-indigo mb-2">Livraison</h2>
        <p>{order.deliveryAddress}</p>
        <p className="text-ink/60">{order.deliveryCity}{order.deliveryQuartier ? `, ${order.deliveryQuartier}` : ""}</p>
        <p className="text-ink/60">Paiement : {order.paymentMethod === "CASH_ON_DELIVERY" ? "À la livraison" : order.paymentMethod}</p>
      </div>

      {order.status === "DELIVERED" && (
        <div className="komi-card p-4 space-y-3">
          <h2 className="font-display font-semibold text-indigo">Donne ton avis</h2>
          <ReviewForm targetType="STORE" targetId={order.storeId} orderId={order.id} label={`Noter ${order.store.name}`} />
          {order.items.map((item: any) => (
            <ReviewForm key={item.id} targetType="PRODUCT" targetId={item.productId} orderId={order.id} label={`Noter ${item.product.name}`} />
          ))}
        </div>
      )}
    </div>
  );
}
