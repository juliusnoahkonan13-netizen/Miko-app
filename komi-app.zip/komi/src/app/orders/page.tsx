"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Package } from "lucide-react";

const STATUS_LABEL: Record<string, string> = {
  PENDING: "Commande créée",
  CONFIRMED: "Confirmée",
  PREPARING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  CANCELLED: "Annulée"
};

const STATUS_COLOR: Record<string, string> = {
  PENDING: "bg-amber/20 text-amber-dark",
  CONFIRMED: "bg-teal/10 text-teal-dark",
  PREPARING: "bg-teal/10 text-teal-dark",
  SHIPPED: "bg-indigo/10 text-indigo",
  DELIVERED: "bg-green-100 text-green-700",
  CANCELLED: "bg-red-100 text-red-600"
};

export default function OrdersPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<any[] | null>(null);

  useEffect(() => {
    fetch("/api/orders", { cache: "no-store" })
      .then((res) => {
        if (res.status === 401) return router.push("/login");
        return res.json();
      })
      .then((data) => data && setOrders(data.orders));
  }, []);

  if (orders === null) return <div className="max-w-3xl mx-auto px-4 py-10 text-ink/50">Chargement...</div>;

  if (orders.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center text-ink/50">
        <Package className="mx-auto mb-3" size={40} />
        <p>Tu n'as pas encore de commande.</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Mes commandes</h1>
      {orders.map((order) => (
        <Link key={order.id} href={`/orders/${order.id}`} className="komi-card p-4 flex items-center justify-between block">
          <div>
            <p className="font-medium text-sm">Commande #{order.id.slice(-6).toUpperCase()}</p>
            <p className="text-xs text-ink/50">{order.store?.name} · {new Date(order.createdAt).toLocaleDateString("fr-FR")}</p>
            <p className="font-display font-semibold text-indigo mt-1">{order.total.toLocaleString("fr-FR")} FCFA</p>
          </div>
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_COLOR[order.status]}`}>
            {STATUS_LABEL[order.status]}
          </span>
        </Link>
      ))}
    </div>
  );
}
