"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import ImageUploader from "@/components/ImageUploader";

const TYPES = [
  { value: "HOUSE", label: "Maison" },
  { value: "APARTMENT", label: "Appartement" },
  { value: "VILLA", label: "Villa" },
  { value: "LAND", label: "Terrain" },
  { value: "SHOP", label: "Magasin" },
  { value: "OFFICE", label: "Bureau" },
  { value: "ROOM", label: "Chambre" },
  { value: "COMMERCIAL_SPACE", label: "Local commercial" }
];

export default function NewPropertyPage() {
  const router = useRouter();
  const [images, setImages] = useState<string[]>([]);
  const [form, setForm] = useState({
    type: "HOUSE",
    transactionType: "SALE",
    title: "",
    description: "",
    price: "",
    city: "",
    quartier: "",
    surfaceM2: "",
    bedrooms: "",
    bathrooms: "",
    amenities: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (images.length === 0) return setError("Ajoute au moins une photo.");
    if (!form.title || !form.description || !form.price || !form.city) return setError("Titre, description, prix et ville sont requis.");
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/properties", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          price: Number(form.price),
          surfaceM2: form.surfaceM2 ? Number(form.surfaceM2) : undefined,
          bedrooms: form.bedrooms ? Number(form.bedrooms) : undefined,
          bathrooms: form.bathrooms ? Number(form.bathrooms) : undefined,
          amenities: form.amenities ? form.amenities.split(",").map((a) => a.trim()).filter(Boolean) : [],
          images
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur.");
      router.push(`/property/${data.property.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-4">
      <h1 className="font-display text-2xl font-bold text-indigo">Publier un bien immobilier</h1>

      <ImageUploader urls={images} onChange={setImages} />

      <div className="grid grid-cols-2 gap-3">
        <select className="komi-input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
          {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
        <select className="komi-input" value={form.transactionType} onChange={(e) => setForm({ ...form, transactionType: e.target.value })}>
          <option value="SALE">À vendre</option>
          <option value="RENT">À louer</option>
        </select>
      </div>

      <input className="komi-input" placeholder="Titre de l'annonce" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <textarea className="komi-input" rows={4} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      <input type="number" className="komi-input" placeholder={`Prix (FCFA${form.transactionType === "RENT" ? " / mois" : ""})`} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />

      <div className="grid grid-cols-2 gap-3">
        <input className="komi-input" placeholder="Ville" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        <input className="komi-input" placeholder="Quartier" value={form.quartier} onChange={(e) => setForm({ ...form, quartier: e.target.value })} />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <input type="number" className="komi-input" placeholder="Superficie m²" value={form.surfaceM2} onChange={(e) => setForm({ ...form, surfaceM2: e.target.value })} />
        <input type="number" className="komi-input" placeholder="Chambres" value={form.bedrooms} onChange={(e) => setForm({ ...form, bedrooms: e.target.value })} />
        <input type="number" className="komi-input" placeholder="Sdb" value={form.bathrooms} onChange={(e) => setForm({ ...form, bathrooms: e.target.value })} />
      </div>

      <input className="komi-input" placeholder="Équipements séparés par une virgule (ex: Piscine, Garage)" value={form.amenities} onChange={(e) => setForm({ ...form, amenities: e.target.value })} />

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button onClick={submit} disabled={saving} className="komi-btn-primary w-full py-3">
        {saving ? "Publication..." : "Publier l'annonce"}
      </button>
    </div>
  );
}
