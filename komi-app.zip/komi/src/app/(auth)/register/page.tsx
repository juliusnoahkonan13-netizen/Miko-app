"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";

const ROLES = [
  { value: "CLIENT", emoji: "👤", label: "Client", desc: "Je veux acheter, réserver, commander" },
  { value: "SELLER", emoji: "🛍️", label: "Vendeur", desc: "Je veux ouvrir une boutique" },
  { value: "PROFESSIONAL", emoji: "🔧", label: "Professionnel", desc: "Je propose mes services (plombier, etc.)" },
  { value: "BUSINESS", emoji: "🏢", label: "Entreprise", desc: "Je crée une page entreprise" },
  { value: "AGENT", emoji: "🏠", label: "Agent immobilier", desc: "Je publie des biens immobiliers" }
];

export default function RegisterPage() {
  const [role, setRole] = useState("CLIENT");
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    city: "",
    password: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { refresh } = useAuth();

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, role })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur lors de l'inscription.");
      await refresh();
      router.push("/verify-email");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-10">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/komi-logo.jpg" alt="Komi" className="h-10 w-auto mx-auto mb-8 mix-blend-multiply" />
      <h1 className="font-display text-2xl font-bold text-indigo mb-1">Rejoindre Komi</h1>
      <p className="text-ink/60 text-sm mb-6">Choisis comment tu veux utiliser Komi. Tu pourras ajouter d'autres profils plus tard.</p>

      <div className="grid grid-cols-1 gap-2 mb-6">
        {ROLES.map((r) => (
          <button
            type="button"
            key={r.value}
            onClick={() => setRole(r.value)}
            className={`flex items-center gap-3 text-left p-3 rounded-komi border transition-colors ${
              role === r.value ? "border-teal bg-teal/5" : "border-line bg-white"
            }`}
          >
            <span className="text-2xl">{r.emoji}</span>
            <span>
              <span className="block font-medium text-ink">{r.label}</span>
              <span className="block text-xs text-ink/50">{r.desc}</span>
            </span>
          </button>
        ))}
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Prénom" value={form.firstName} onChange={(v) => setForm({ ...form, firstName: v })} />
          <Field label="Nom" value={form.lastName} onChange={(v) => setForm({ ...form, lastName: v })} />
        </div>
        <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
        <Field label="Téléphone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />
        <Field label="Ville" value={form.city} onChange={(v) => setForm({ ...form, city: v })} />
        <Field
          label="Mot de passe (8 caractères min.)"
          type="password"
          value={form.password}
          onChange={(v) => setForm({ ...form, password: v })}
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="komi-btn-primary w-full">
          {loading ? "Création du compte..." : "Créer mon compte"}
        </button>
      </form>

      <p className="mt-4 text-sm text-center">
        Déjà inscrit ?{" "}
        <Link href="/login" className="text-teal font-medium hover:underline">
          Se connecter
        </Link>
      </p>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text"
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div>
      <label className="text-sm font-medium text-ink/70">{label}</label>
      <input
        type={type}
        className="komi-input mt-1"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={type !== "text" || true}
      />
    </div>
  );
}
