"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";

export default function LoginPage() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { refresh } = useAuth();

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur de connexion.");
      await refresh();
      router.push("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-12">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/komi-logo.jpg" alt="Komi" className="h-10 w-auto mx-auto mb-8 mix-blend-multiply" />
      <h1 className="font-display text-2xl font-bold text-indigo mb-1">Content de te revoir</h1>
      <p className="text-ink/60 text-sm mb-6">Connecte-toi à ton compte Komi.</p>

      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-ink/70">Email ou téléphone</label>
          <input className="komi-input mt-1" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
        </div>
        <div>
          <label className="text-sm font-medium text-ink/70">Mot de passe</label>
          <input
            type="password"
            className="komi-input mt-1"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={loading} className="komi-btn-primary w-full">
          {loading ? "Connexion..." : "Se connecter"}
        </button>
      </form>

      <div className="mt-4 flex justify-between text-sm">
        <Link href="/forgot-password" className="text-teal hover:underline">
          Mot de passe oublié ?
        </Link>
        <Link href="/register" className="text-indigo font-medium hover:underline">
          Créer un compte
        </Link>
      </div>
    </div>
  );
}
