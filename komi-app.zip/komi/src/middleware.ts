import { NextRequest, NextResponse } from "next/server";

const PROTECTED_PREFIXES = [
  "/dashboard",
  "/admin",
  "/cart",
  "/checkout",
  "/orders",
  "/messages",
  "/notifications",
  "/favorites",
  "/profile",
  "/sell",
  "/quotes",
  "/properties/new",
  "/vehicles/new"
];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`));
  if (!isProtected) return NextResponse.next();

  const hasSession = req.cookies.has("komi_session");
  if (!hasSession) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }
  return NextResponse.next();
}

// Note: this only checks the cookie exists — it's a fast UX redirect, not the
// security boundary. Every API route independently verifies the session and
// role via requireUser()/requireRole() in src/lib/auth.ts, which is what
// actually protects the data.
export const config = {
  matcher: [
    "/dashboard/:path*",
    "/admin/:path*",
    "/cart/:path*",
    "/checkout/:path*",
    "/orders/:path*",
    "/messages/:path*",
    "/notifications/:path*",
    "/favorites/:path*",
    "/profile/:path*",
    "/sell/:path*",
    "/quotes/:path*",
    "/properties/new",
    "/vehicles/new"
  ]
};
