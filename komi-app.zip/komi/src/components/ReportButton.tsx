"use client";

import { useState } from "react";
import { Flag } from "lucide-react";

const REASONS = ["Contenu trompeur", "Arnaque suspectée", "Contenu inapproprié", "Prix incorrect", "Autre"];

export default function ReportButton({
  targetType,
  targetId
}: {
  targetType: "PRODUCT" | "STORE" | "PROFESSIONAL" | "BUSINESS" | "PROPERTY" | "VEHICLE" | "SERVICE" | "USER" | "MESSAGE" | "REVIEW";
  targetId: string;
}) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(REASONS[0]);
  const [details, setDetails] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetType, targetId, reason, details: details || undefined })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "Erreur lors du signalement.");
      }
      setSent(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (sent) return <p className="text-xs text-ink/40">Signalé, merci ✓</p>;

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="text-xs text-ink/30 hover:text-red-500 flex items-center gap-1">
        <Flag size={12} /> Signaler
      </button>
    );
  }

  return (
    <div className="komi-card p-3 space-y-2 text-sm">
      <select className="komi-input" value={reason} onChange={(e) => setReason(e.target.value)}>
        {REASONS.map((r) => <option key={r} value={r}>{r}</option>)}
      </select>
      <textarea className="komi-input" rows={2} placeholder="Détails (optionnel)" value={details} onChange={(e) => setDetails(e.target.value)} />
      {error && <p className="text-red-600 text-xs">{error}</p>}
      <div className="flex gap-2">
        <button onClick={submit} disabled={saving} className="komi-btn-secondary text-xs">
          {saving ? "Envoi..." : "Envoyer le signalement"}
        </button>
        <button onClick={() => setOpen(false)} className="text-xs text-ink/40">Annuler</button>
      </div>
    </div>
  );
}
