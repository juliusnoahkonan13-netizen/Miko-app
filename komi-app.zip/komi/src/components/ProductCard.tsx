import Link from "next/link";
import Image from "next/image";

type ProductCardProps = {
  id: string;
  slug: string;
  name: string;
  price: number;
  promoPrice?: number | null;
  imageUrl?: string;
  storeName?: string;
};

function formatFcfa(amount: number) {
  return `${amount.toLocaleString("fr-FR")} FCFA`;
}

export default function ProductCard({ slug, name, price, promoPrice, imageUrl, storeName }: ProductCardProps) {
  const hasPromo = promoPrice && promoPrice < price;
  const discountPct = hasPromo ? Math.round(((price - promoPrice!) / price) * 100) : 0;

  return (
    <Link href={`/product/${slug}`} className="komi-card overflow-hidden block group">
      <div className="relative aspect-square bg-line/40">
        {imageUrl ? (
          <Image src={imageUrl} alt={name} fill className="object-cover group-hover:scale-[1.03] transition-transform" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-3xl">🛍️</div>
        )}
        {hasPromo && (
          <span className="absolute top-2 left-2 bg-amber text-ink text-xs font-bold px-2 py-0.5 rounded-full">
            -{discountPct}%
          </span>
        )}
      </div>
      <div className="p-3">
        <p className="text-sm font-medium text-ink line-clamp-1">{name}</p>
        {storeName && <p className="text-xs text-ink/50 mt-0.5">{storeName}</p>}
        <div className="mt-1.5 flex items-baseline gap-2">
          <span className="font-display font-semibold text-indigo">
            {formatFcfa(hasPromo ? promoPrice! : price)}
          </span>
          {hasPromo && <span className="text-xs text-ink/40 line-through">{formatFcfa(price)}</span>}
        </div>
      </div>
    </Link>
  );
}
