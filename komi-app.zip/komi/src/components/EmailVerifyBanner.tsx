"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "./AuthProvider";

export default function EmailVerifyBanner() {
  const { user } = useAuth();
  const pathname = usePathname();

  if (!user || user.emailVerifiedAt || pathname === "/verify-email") return null;

  return (
    <div className="bg-amber/15 text-amber-dark text-sm text-center py-2 px-4">
      📧 Vérifie ton email pour débloquer les achats, la vente et les publications.{" "}
      <Link href="/verify-email" className="font-semibold underline">
        Vérifier maintenant
      </Link>
    </div>
  );
}
