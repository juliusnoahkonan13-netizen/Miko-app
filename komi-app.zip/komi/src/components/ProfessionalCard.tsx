import Link from "next/link";
import { Star, ShieldCheck, MapPin } from "lucide-react";

type ProfessionalCardProps = {
  id: string;
  jobTitle: string;
  firstName: string;
  lastName: string;
  city: string;
  quartier?: string | null;
  ratingAvg: number;
  ratingCount: number;
  verified: boolean;
};

export default function ProfessionalCard(p: ProfessionalCardProps) {
  return (
    <Link href={`/professional/${p.id}`} className="komi-card p-4 flex gap-3 items-start block">
      <div className="w-12 h-12 rounded-full bg-teal/10 text-teal flex items-center justify-center font-display font-semibold shrink-0">
        {p.firstName[0]}
        {p.lastName[0]}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-semibold text-ink">{p.firstName} {p.lastName}</p>
          {p.verified && (
            <span className="komi-badge-verified">
              <ShieldCheck size={12} /> Vérifié
            </span>
          )}
        </div>
        <p className="text-sm text-indigo/80">{p.jobTitle}</p>
        <div className="flex items-center gap-3 mt-1 text-xs text-ink/50">
          <span className="flex items-center gap-1">
            <Star size={12} className="fill-amber text-amber" /> {p.ratingAvg.toFixed(1)} ({p.ratingCount})
          </span>
          <span className="flex items-center gap-1">
            <MapPin size={12} /> {p.quartier ? `${p.quartier}, ` : ""}{p.city}
          </span>
        </div>
      </div>
    </Link>
  );
}
