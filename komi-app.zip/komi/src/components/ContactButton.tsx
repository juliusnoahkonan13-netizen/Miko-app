"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { MessageCircle } from "lucide-react";

export default function ContactButton({ recipientId, label = "Contacter" }: { recipientId: string; label?: string }) {
  const { user } = useAuth();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  async function send() {
    if (!message.trim()) return;
    setSending(true);
    try {
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipientId, firstMessage: message })
      });
      const data = await res.json();
      if (res.ok) router.push(`/messages/${data.conversation.id}`);
    } finally {
      setSending(false);
    }
  }

  if (!user) {
    return (
      <button onClick={() => router.push("/login")} className="komi-btn-secondary flex items-center gap-2">
        <MessageCircle size={16} /> {label}
      </button>
    );
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="komi-btn-secondary flex items-center gap-2">
        <MessageCircle size={16} /> {label}
      </button>
    );
  }

  return (
    <div className="komi-card p-3 space-y-2">
      <textarea
        className="komi-input"
        rows={3}
        placeholder="Écris ton message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <div className="flex gap-2">
        <button onClick={send} disabled={sending} className="komi-btn-primary text-sm">
          {sending ? "Envoi..." : "Envoyer"}
        </button>
        <button onClick={() => setOpen(false)} className="komi-btn-secondary text-sm">
          Annuler
        </button>
      </div>
    </div>
  );
}
