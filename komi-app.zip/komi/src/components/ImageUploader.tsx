"use client";

import { useState } from "react";
import { ImagePlus, X, Loader2 } from "lucide-react";

export default function ImageUploader({
  urls,
  onChange,
  max = 6
}: {
  urls: string[];
  onChange: (urls: string[]) => void;
  max?: number;
}) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setError(null);
    setUploading(true);
    try {
      const uploaded: string[] = [];
      for (const file of Array.from(files).slice(0, max - urls.length)) {
        const form = new FormData();
        form.append("file", file);
        const res = await fetch("/api/upload", { method: "POST", body: form });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Échec de l'envoi.");
        uploaded.push(data.url);
      }
      onChange([...urls, ...uploaded]);
    } catch (err: any) {
      setError(err.message ?? "Échec de l'envoi.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap gap-3">
        {urls.map((url, i) => (
          <div key={url} className="relative w-20 h-20 rounded-komi overflow-hidden border border-line">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={url} alt="" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => onChange(urls.filter((_, idx) => idx !== i))}
              className="absolute top-0.5 right-0.5 bg-black/60 text-white rounded-full w-5 h-5 flex items-center justify-center"
              aria-label="Retirer la photo"
            >
              <X size={12} />
            </button>
          </div>
        ))}
        {urls.length < max && (
          <label className="w-20 h-20 rounded-komi border-2 border-dashed border-line flex items-center justify-center cursor-pointer text-ink/40 hover:border-amber hover:text-amber">
            {uploading ? <Loader2 size={20} className="animate-spin" /> : <ImagePlus size={20} />}
            <input
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              disabled={uploading}
              onChange={(e) => handleFiles(e.target.files)}
            />
          </label>
        )}
      </div>
      {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
      <p className="text-xs text-ink/40 mt-1">{urls.length}/{max} photos</p>
    </div>
  );
}
