import Link from "next/link";

const CATEGORIES = [
  { emoji: "🛒", label: "Produits", href: "/search?type=product" },
  { emoji: "🔧", label: "Services", href: "/search?type=professional" },
  { emoji: "🏠", label: "Immobilier", href: "/search?type=property" },
  { emoji: "🚗", label: "Véhicules", href: "/search?type=vehicle" },
  { emoji: "👕", label: "Mode", href: "/search?q=mode" },
  { emoji: "📱", label: "Électronique", href: "/search?q=electronique" },
  { emoji: "🏢", label: "Entreprises", href: "/search?type=business" },
  { emoji: "🍔", label: "Restaurants", href: "/search?q=restaurant" },
  { emoji: "💼", label: "Professionnels", href: "/search?type=professional" },
  { emoji: "🏡", label: "Maison", href: "/search?q=maison" }
];

export default function CategoryGrid() {
  return (
    <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
      {CATEGORIES.map((cat) => (
        <Link
          key={cat.label}
          href={cat.href}
          className="flex flex-col items-center gap-1.5 text-center group"
        >
          <span className="w-14 h-14 rounded-2xl bg-white border border-line flex items-center justify-center text-2xl group-hover:border-amber transition-colors">
            {cat.emoji}
          </span>
          <span className="text-[11px] font-medium text-indigo/80 leading-tight">{cat.label}</span>
        </Link>
      ))}
    </div>
  );
}
