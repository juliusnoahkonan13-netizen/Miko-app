"use client";

import { useRouter } from "next/navigation";
import { useState, FormEvent } from "react";
import { Search } from "lucide-react";

export default function SearchBar({ placeholder = "Que recherchez-vous ?" }: { placeholder?: string }) {
  const [value, setValue] = useState("");
  const router = useRouter();

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!value.trim()) return;
    router.push(`/search?q=${encodeURIComponent(value.trim())}`);
  }

  return (
    <form onSubmit={onSubmit} className="flex items-center gap-2 bg-white rounded-full border border-line px-4 py-3 shadow-sm w-full max-w-2xl">
      <Search size={20} className="text-indigo/60 shrink-0" />
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder}
        className="flex-1 outline-none bg-transparent text-ink placeholder:text-ink/40"
      />
      <button type="submit" className="komi-btn-amber !py-2 !px-4 text-sm shrink-0">
        Rechercher
      </button>
    </form>
  );
}
