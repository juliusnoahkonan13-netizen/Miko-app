"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Heart } from "lucide-react";
import { useAuth } from "./AuthProvider";

export default function FavoriteButton({ targetType, targetId }: { targetType: string; targetId: string }) {
  const { user } = useAuth();
  const router = useRouter();
  const [saved, setSaved] = useState(false);

  async function toggle() {
    if (!user) return router.push("/login");
    if (saved) return; // simple version: removal happens from the favorites page
    const res = await fetch("/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetType, targetId })
    });
    if (res.ok) setSaved(true);
  }

  return (
    <button
      onClick={toggle}
      aria-label="Ajouter aux favoris"
      className={`w-10 h-10 rounded-full border flex items-center justify-center transition-colors ${
        saved ? "bg-red-50 border-red-200 text-red-500" : "bg-white border-line text-ink/50 hover:text-red-500"
      }`}
    >
      <Heart size={18} fill={saved ? "currentColor" : "none"} />
    </button>
  );
}
