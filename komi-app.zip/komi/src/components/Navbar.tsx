"use client";

import Link from "next/link";
import { Bell, ShoppingCart, MessageCircle, UserCircle, Sparkles } from "lucide-react";
import { useAuth } from "./AuthProvider";

export default function Navbar() {
  const { user, loading } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-ivoire/95 backdrop-blur border-b border-line">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/komi-logo.jpg" alt="Komi — Tout commence ici." className="h-9 md:h-10 w-auto object-contain mix-blend-multiply" />
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-indigo/80">
          <Link href="/search?type=product" className="hover:text-indigo">Marketplace</Link>
          <Link href="/search?type=professional" className="hover:text-indigo">Services</Link>
          <Link href="/search?type=property" className="hover:text-indigo">Immobilier</Link>
          <Link href="/search?type=vehicle" className="hover:text-indigo">Véhicules</Link>
          <Link href="/komi-ai" className="hover:text-indigo flex items-center gap-1">
            <Sparkles size={15} className="text-amber" /> Komi AI
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {!loading && user && (
            <>
              <Link href="/notifications" aria-label="Notifications" className="text-indigo hover:text-amber">
                <Bell size={22} />
              </Link>
              <Link href="/messages" aria-label="Messages" className="text-indigo hover:text-amber">
                <MessageCircle size={22} />
              </Link>
              <Link href="/cart" aria-label="Panier" className="text-indigo hover:text-amber">
                <ShoppingCart size={22} />
              </Link>
              <Link href="/profile" aria-label="Profil" className="text-indigo hover:text-amber">
                <UserCircle size={22} />
              </Link>
            </>
          )}
          {!loading && !user && (
            <Link href="/login" className="komi-btn-primary text-sm">
              Connexion
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
