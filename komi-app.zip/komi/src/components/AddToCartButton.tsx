"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { ShoppingCart, Check } from "lucide-react";

export default function AddToCartButton({ productId, disabled }: { productId: string; disabled?: boolean }) {
  const { user } = useAuth();
  const router = useRouter();
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function addToCart() {
    if (!user) return router.push("/login");
    setState("loading");
    try {
      const res = await fetch("/api/cart/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity: 1 })
      });
      setState(res.ok ? "done" : "error");
      if (res.ok) setTimeout(() => setState("idle"), 1500);
    } catch {
      setState("error");
    }
  }

  return (
    <button onClick={addToCart} disabled={disabled || state === "loading"} className="komi-btn-primary flex items-center gap-2">
      {state === "done" ? <Check size={16} /> : <ShoppingCart size={16} />}
      {disabled ? "Rupture de stock" : state === "done" ? "Ajouté !" : "Ajouter au panier"}
    </button>
  );
}
