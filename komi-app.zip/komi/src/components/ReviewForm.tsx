"use client";

import { useState } from "react";
import { Star } from "lucide-react";

export default function ReviewForm({
  targetType,
  targetId,
  orderId,
  label = "Laisser un avis",
  onSubmitted
}: {
  targetType: "PRODUCT" | "PROFESSIONAL" | "STORE";
  targetId: string;
  orderId?: string;
  label?: string;
  onSubmitted?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  async function submit() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetType, targetId, orderId, rating, comment: comment || undefined })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Impossible d'envoyer l'avis.");
      setDone(true);
      onSubmitted?.();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (done) return <p className="text-sm text-teal font-medium">Merci pour ton avis ✓</p>;

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="komi-btn-secondary text-sm">
        {label}
      </button>
    );
  }

  return (
    <div className="komi-card p-3 space-y-2">
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} onClick={() => setRating(n)} aria-label={`${n} étoiles`}>
            <Star size={20} className={n <= rating ? "fill-amber text-amber" : "text-line"} />
          </button>
        ))}
      </div>
      <textarea className="komi-input" rows={2} placeholder="Ton commentaire (optionnel)" value={comment} onChange={(e) => setComment(e.target.value)} />
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button onClick={submit} disabled={saving} className="komi-btn-primary text-sm">
        {saving ? "Envoi..." : "Envoyer l'avis"}
      </button>
    </div>
  );
}
