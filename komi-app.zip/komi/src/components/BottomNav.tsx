"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, Store, MessageCircle, UserCircle, Plus } from "lucide-react";
import { useState } from "react";

const TABS = [
  { href: "/", label: "Accueil", icon: Home },
  { href: "/search", label: "Recherche", icon: Search },
  { href: "/search?type=product", label: "Marketplace", icon: Store },
  { href: "/messages", label: "Messages", icon: MessageCircle },
  { href: "/profile", label: "Profil", icon: UserCircle }
];

export default function BottomNav() {
  const pathname = usePathname();
  const [showPublish, setShowPublish] = useState(false);

  return (
    <>
      {showPublish && (
        <div
          className="fixed inset-0 z-40 bg-black/40 flex items-end md:hidden"
          onClick={() => setShowPublish(false)}
        >
          <div className="bg-white w-full rounded-t-2xl p-4 space-y-2" onClick={(e) => e.stopPropagation()}>
            <p className="font-display text-lg font-semibold text-indigo px-2 pb-1">Publier sur Komi</p>
            {[
              { href: "/dashboard/seller/products/new", label: "Un produit à vendre" },
              { href: "/dashboard/professional/services/new", label: "Un service professionnel" },
              { href: "/properties/new", label: "Une annonce immobilière" },
              { href: "/vehicles/new", label: "Un véhicule" }
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block w-full text-left px-3 py-3 rounded-komi hover:bg-ivoire text-indigo font-medium"
                onClick={() => setShowPublish(false)}
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}

      <nav className="fixed bottom-0 inset-x-0 z-30 bg-white border-t border-line md:hidden">
        <div className="grid grid-cols-5 items-center h-16">
          {TABS.slice(0, 2).map((tab) => (
            <TabLink key={tab.href} tab={tab} active={pathname === tab.href} />
          ))}

          <div className="flex justify-center -mt-6">
            <button
              onClick={() => setShowPublish(true)}
              aria-label="Publier"
              className="w-14 h-14 rounded-full bg-amber text-ink shadow-lg flex items-center justify-center border-4 border-ivoire"
            >
              <Plus size={26} strokeWidth={2.5} />
            </button>
          </div>

          {TABS.slice(3).map((tab) => (
            <TabLink key={tab.href} tab={tab} active={pathname === tab.href} />
          ))}
        </div>
      </nav>
    </>
  );
}

function TabLink({ tab, active }: { tab: (typeof TABS)[number]; active: boolean }) {
  const Icon = tab.icon;
  return (
    <Link
      href={tab.href}
      className={`flex flex-col items-center justify-center gap-0.5 text-[11px] ${
        active ? "text-teal font-semibold" : "text-indigo/60"
      }`}
    >
      <Icon size={20} />
      {tab.label}
    </Link>
  );
}
