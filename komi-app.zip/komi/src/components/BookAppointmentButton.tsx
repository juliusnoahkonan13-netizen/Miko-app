"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthProvider";
import { CalendarClock } from "lucide-react";

export default function BookAppointmentButton({ professionalId }: { professionalId: string }) {
  const { user } = useAuth();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  async function book() {
    if (!user) return router.push("/login");
    if (!date || !time) return;
    setStatus("loading");
    setError(null);

    const start = new Date(`${date}T${time}:00`);
    const end = new Date(start.getTime() + 60 * 60 * 1000);

    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ professionalId, startTime: start.toISOString(), endTime: end.toISOString() })
    });
    const data = await res.json();
    if (!res.ok) {
      setStatus("error");
      setError(data.error ?? "Erreur.");
      return;
    }
    setStatus("done");
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="komi-btn-amber flex items-center gap-2">
        <CalendarClock size={16} /> Réserver
      </button>
    );
  }

  if (status === "done") {
    return <p className="komi-card p-3 text-teal text-sm">Demande de rendez-vous envoyée ! Le professionnel doit la confirmer.</p>;
  }

  return (
    <div className="komi-card p-3 space-y-2">
      <div className="flex gap-2">
        <input type="date" className="komi-input" value={date} onChange={(e) => setDate(e.target.value)} />
        <input type="time" className="komi-input" value={time} onChange={(e) => setTime(e.target.value)} />
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="flex gap-2">
        <button onClick={book} disabled={status === "loading"} className="komi-btn-primary text-sm">
          Confirmer la demande
        </button>
        <button onClick={() => setOpen(false)} className="komi-btn-secondary text-sm">
          Annuler
        </button>
      </div>
    </div>
  );
}
