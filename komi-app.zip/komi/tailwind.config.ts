import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ivoire: "#F5F7FA",
        ink: "#12182B",
        indigo: {
          DEFAULT: "#1B4F9C",
          light: "#2E6FC4"
        },
        amber: {
          DEFAULT: "#F0791C",
          dark: "#D4650F"
        },
        teal: {
          DEFAULT: "#1B7F79",
          dark: "#12564F"
        },
        line: "#E2E6ED"
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"]
      },
      borderRadius: {
        komi: "14px"
      }
    }
  },
  plugins: []
};
export default config;
