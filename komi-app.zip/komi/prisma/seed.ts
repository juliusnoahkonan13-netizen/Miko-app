import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  console.log("Seeding Komi...");

  // --- Categories -----------------------------------------------------
  const categoryNames = [
    "Électronique",
    "Mode",
    "Maison",
    "Véhicules",
    "Services",
    "Immobilier",
    "Restaurants",
    "Beauté"
  ];
  const categories = await Promise.all(
    categoryNames.map((name) =>
      db.category.upsert({
        where: { slug: name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "") },
        update: {},
        create: {
          name,
          slug: name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        }
      })
    )
  );

  // --- Admin ------------------------------------------------------------
  const adminPassword = await bcrypt.hash("KomiAdmin2026!", 12);
  const admin = await db.user.upsert({
    where: { email: "admin@komi.ci" },
    update: {},
    create: {
      email: "admin@komi.ci",
      passwordHash: adminPassword,
      firstName: "Komi",
      lastName: "Admin",
      roles: [Role.ADMIN],
      emailVerifiedAt: new Date(),
      city: "Abidjan"
    }
  });

  // --- Sample seller + store + products ----------------------------------
  const sellerPassword = await bcrypt.hash("Password123!", 12);
  const seller = await db.user.upsert({
    where: { email: "vendeur@komi.ci" },
    update: {},
    create: {
      email: "vendeur@komi.ci",
      passwordHash: sellerPassword,
      firstName: "Awa",
      lastName: "Kouassi",
      roles: [Role.CLIENT, Role.SELLER],
      emailVerifiedAt: new Date(),
      city: "Abidjan",
      quartier: "Yopougon",
      cart: { create: {} }
    }
  });

  const store = await db.store.upsert({
    where: { ownerId: seller.id },
    update: {},
    create: {
      ownerId: seller.id,
      name: "Awa Boutique",
      slug: "awa-boutique",
      description: "Mode et accessoires pour toute la famille.",
      city: "Abidjan",
      quartier: "Yopougon",
      verification: "VERIFIED"
    }
  });

  await db.product.upsert({
    where: { slug: "robe-wax-elegante" },
    update: {},
    create: {
      storeId: store.id,
      categoryId: categories.find((c) => c.name === "Mode")!.id,
      name: "Robe wax élégante",
      slug: "robe-wax-elegante",
      description: "Robe en tissu wax authentique, coupe ajustée, disponible en plusieurs tailles.",
      price: 15000,
      promoPrice: 12000,
      stock: 25,
      condition: "neuf",
      images: { create: [{ url: "https://images.unsplash.com/photo-1595777457583-95e059d581b8", position: 0 }] },
      variants: { create: [{ size: "S", stock: 8 }, { size: "M", stock: 10 }, { size: "L", stock: 7 }] }
    }
  });

  // --- Sample professional -----------------------------------------------
  const proPassword = await bcrypt.hash("Password123!", 12);
  const pro = await db.user.upsert({
    where: { email: "plombier@komi.ci" },
    update: {},
    create: {
      email: "plombier@komi.ci",
      passwordHash: proPassword,
      firstName: "Jean",
      lastName: "Yao",
      roles: [Role.CLIENT, Role.PROFESSIONAL],
      emailVerifiedAt: new Date(),
      city: "Abidjan",
      quartier: "Yopougon",
      cart: { create: {} }
    }
  });

  const professional = await db.professionalProfile.upsert({
    where: { userId: pro.id },
    update: {},
    create: {
      userId: pro.id,
      jobTitle: "Plombier",
      description: "10 ans d'expérience en réparation de fuites, installation sanitaire et débouchage.",
      experienceYears: 10,
      zone: "Yopougon et environs",
      city: "Abidjan",
      quartier: "Yopougon",
      verification: "VERIFIED",
      ratingAvg: 4.8,
      ratingCount: 12
    }
  });

  await db.service.upsert({
    where: { id: "seed-service-plumbing" },
    update: {},
    create: {
      id: "seed-service-plumbing",
      professionalId: professional.id,
      categoryId: categories.find((c) => c.name === "Services")!.id,
      name: "Réparation de fuite",
      description: "Diagnostic et réparation rapide de fuites d'eau.",
      priceFrom: 5000,
      priceTo: 25000
    }
  });

  // --- Sample client -------------------------------------------------------
  const clientPassword = await bcrypt.hash("Password123!", 12);
  await db.user.upsert({
    where: { email: "client@komi.ci" },
    update: {},
    create: {
      email: "client@komi.ci",
      passwordHash: clientPassword,
      firstName: "Fatou",
      lastName: "Diabaté",
      roles: [Role.CLIENT],
      emailVerifiedAt: new Date(),
      city: "Abidjan",
      quartier: "Cocody",
      cart: { create: {} }
    }
  });

  // --- Sample property & vehicle --------------------------------------------
  await db.property.upsert({
    where: { id: "seed-property-1" },
    update: {},
    create: {
      id: "seed-property-1",
      ownerId: seller.id,
      type: "APARTMENT",
      transactionType: "RENT",
      title: "Bel appartement 3 chambres à Cocody",
      description: "Appartement moderne et sécurisé, proche des commodités.",
      price: 250000,
      city: "Abidjan",
      quartier: "Cocody",
      surfaceM2: 120,
      bedrooms: 3,
      bathrooms: 2,
      amenities: ["Climatisation", "Parking", "Sécurité 24h/24"],
      images: { create: [{ url: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2", position: 0 }] }
    }
  });

  await db.vehicle.upsert({
    where: { id: "seed-vehicle-1" },
    update: {},
    create: {
      id: "seed-vehicle-1",
      sellerId: seller.id,
      type: "CAR",
      brand: "Toyota",
      model: "Corolla",
      year: 2019,
      mileageKm: 45000,
      price: 8500000,
      condition: "USED",
      city: "Abidjan",
      quartier: "Marcory",
      description: "Véhicule bien entretenu, un seul propriétaire, visite technique à jour.",
      images: { create: [{ url: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d", position: 0 }] }
    }
  });

  console.log("Seed terminé.");
  console.log("Comptes de test (mot de passe entre parenthèses) :");
  console.log("  admin@komi.ci (KomiAdmin2026!)");
  console.log("  vendeur@komi.ci (Password123!)");
  console.log("  plombier@komi.ci (Password123!)");
  console.log("  client@komi.ci (Password123!)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
