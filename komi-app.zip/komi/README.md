# Komi — Tout commence ici.

Komi est une super-marketplace : produits, services, professionnels, entreprises et immobilier, réunis au même endroit.

Ce dépôt est une **application réelle**, pas une maquette : base de données relationnelle, authentification par mot de passe hashé, panier et commandes persistants, messagerie, notifications, devis, rendez-vous, etc. Rien n'est simulé en mémoire côté navigateur.

## Stack technique

- **Next.js 14** (App Router, TypeScript) — frontend + backend (API routes) dans un seul projet
- **PostgreSQL** + **Prisma ORM** — base de données réelle
- **JWT + bcrypt** — authentification, sessions stockées et révocables en base
- **Tailwind CSS** — interface

## 1. Installer les dépendances

```bash
npm install
```

## 2. Créer une vraie base de données PostgreSQL

Le plus rapide : un compte gratuit sur **[Neon](https://neon.tech)** ou **[Supabase](https://supabase.com)**. Copie l'URL de connexion fournie.

Copie ensuite `.env.example` vers `.env` et renseigne :

```bash
cp .env.example .env
```

```
DATABASE_URL="postgresql://..."   # ton URL Neon/Supabase
JWT_SECRET="..."                  # une chaîne aléatoire longue (ex: openssl rand -base64 48)
```

## 3. Créer les tables

```bash
npm run db:migrate
```

## 4. (Optionnel) Charger des données de démonstration

```bash
npm run db:seed
```

Crée un admin, un vendeur avec une boutique/produit, un professionnel (plombier), un client, une annonce immobilière et un véhicule. Identifiants affichés dans le terminal après exécution.

## 5. Lancer en local

```bash
npm run dev
```

Ouvre [http://localhost:3000](http://localhost:3000).

## Déployer en production

1. Pousse ce projet sur GitHub.
2. Connecte le dépôt à **[Vercel](https://vercel.com)** (gratuit pour démarrer).
3. Renseigne les mêmes variables d'environnement (`DATABASE_URL`, `JWT_SECRET`) dans les réglages du projet Vercel.
4. Vercel build et déploie automatiquement à chaque push.

⚠️ **Stockage des images** : `/api/upload` écrit aujourd'hui sur le disque local (`public/uploads`), ce qui fonctionne en local et sur un serveur avec disque persistant, mais **pas sur Vercel** (système de fichiers éphémère en production serverless). Avant de lancer en production, remplace le contenu de `src/app/api/upload/route.ts` par un vrai fournisseur de stockage d'objets (S3, Cloudinary, Supabase Storage) — un seul fichier à modifier, aucun appelant à toucher.

## Brancher les paiements réels

L'architecture (modèle `Payment`, statuts, méthode) est prête à recevoir un vrai fournisseur. Aujourd'hui seul le **paiement à la livraison** est pleinement fonctionnel. Pour Mobile Money / carte bancaire :

1. Crée un compte chez le fournisseur (ex : CinetPay, PayDunya, Stripe).
2. Renseigne ses clés API dans `.env` (`MOBILE_MONEY_API_KEY`, etc.).
3. Dans `src/app/api/orders/route.ts`, après la création de la commande, appelle l'API du fournisseur pour initier le paiement, et mets à jour `Payment.status` via son webhook de confirmation.

## Vérification d'email et envoi d'emails réels

À l'inscription, un vrai code à 6 chiffres est généré, haché et stocké en base (expire après 15 minutes, verrouillage après 5 tentatives). Tant que l'email n'est pas vérifié, une bannière le rappelle et certaines actions sont bloquées côté serveur : créer une boutique, un profil professionnel, une page entreprise, publier un bien immobilier ou un véhicule, et passer une commande.

Sans clé configurée, le code est simplement affiché dans les logs du serveur (pratique pour tester en local). Pour de vrais emails :

1. Crée un compte gratuit sur [Resend](https://resend.com).
2. Renseigne `RESEND_API_KEY` (et `EMAIL_FROM`) dans `.env`.

`/api/auth/forgot-password` utilise le même mécanisme d'envoi (`src/lib/email.ts`) : dès que `RESEND_API_KEY` est renseigné, les emails de réinitialisation de mot de passe deviennent réels aussi, sans rien changer d'autre.

## Rendre Komi AI plus intelligent

`/api/komi-ai` fonctionne aujourd'hui par extraction de mots-clés (ville, prix, texte) — aucune clé API requise. Pour une vraie compréhension du langage naturel (fautes de frappe, synonymes, demandes complexes), remplace l'étape d'analyse par un appel à l'API Anthropic (voir [docs.claude.com](https://docs.claude.com)) qui renvoie la même structure `{ city, maxPrice, text }`, puis laisse les requêtes Prisma inchangées.

## Structure du projet

```
prisma/schema.prisma       Schéma complet de la base de données
src/lib/                   Authentification, base de données, helpers API
src/app/api/               Toutes les routes backend (REST)
src/app/                   Pages du frontend (App Router)
src/components/            Composants réutilisables
```

## Comptes de test (après `npm run db:seed`)

| Rôle | Email | Mot de passe |
|---|---|---|
| Admin | admin@komi.ci | KomiAdmin2026! |
| Vendeur | vendeur@komi.ci | Password123! |
| Professionnel | plombier@komi.ci | Password123! |
| Client | client@komi.ci | Password123! |
